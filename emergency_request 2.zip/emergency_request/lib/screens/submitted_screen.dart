import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SubmittedScreen extends StatefulWidget {
  final String requestId;

  const SubmittedScreen({
    super.key,
    required this.requestId,
  });

  @override
  State<SubmittedScreen> createState() => _SubmittedScreenState();
}

class _SubmittedScreenState extends State<SubmittedScreen> {
  final SupabaseClient _supabase = Supabase.instance.client;

  bool _isCancelling = false;
  bool _isCancelled = false;
  String _currentStatus = 'Requested';

  /// Prompts confirmation dialog before initiating cancellation.
  Future<void> _confirmAndCancelRequest() async {
    final bool? shouldCancel = await showDialog<bool>(
      context: context,
      barrierDismissible: !_isCancelling,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
              SizedBox(width: 8),
              Text('Cancel Request?'),
            ],
          ),
          content: const Text(
            'Are you sure you want to cancel this emergency request? '
            'This will stop hospital notification and dispatch coordination.',
            style: TextStyle(fontSize: 14, height: 1.4),
          ),
          actionsPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Keep Active'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                foregroundColor: Colors.white,
              ),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Yes, Cancel Request'),
            ),
          ],
        );
      },
    );

    if (shouldCancel == true && mounted) {
      await _executeCancelRpc();
    }
  }

  /// Calls the Supabase RPC transition_emergency_state adhering to the security model.
  Future<void> _executeCancelRpc() async {
    setState(() {
      _isCancelling = true;
    });

    try {
      // Primary call using p_ prefixed parameter names
      try {
        await _supabase.rpc('transition_emergency_state', params: {
          'p_request_id': widget.requestId,
          'p_new_state': 'Cancelled',
          'p_actor_role': 'client',
        });
      } on PostgrestException catch (rpcError) {
        // Safe fallback in case Postgres function was defined without p_ prefixes
        final message = rpcError.message.toLowerCase();
        if (message.contains('parameter') ||
            message.contains('could not find the function') ||
            rpcError.code == '42883') {
          await _supabase.rpc('transition_emergency_state', params: {
            'request_id': widget.requestId,
            'new_state': 'Cancelled',
            'actor_role': 'client',
          });
        } else {
          rethrow;
        }
      }

      if (!mounted) return;

      setState(() {
        _isCancelled = true;
        _currentStatus = 'Cancelled';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Emergency request has been cancelled.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } on PostgrestException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to cancel: ${e.message}'),
          backgroundColor: Colors.red.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Unexpected error: $e'),
          backgroundColor: Colors.red.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isCancelling = false;
        });
      }
    }
  }

  void _returnHome() {
    Navigator.of(context).popUntil((route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final shortId = widget.requestId.length > 8
        ? widget.requestId.substring(0, 8).toUpperCase()
        : widget.requestId.toUpperCase();

    return WillPopScope(
      onWillPop: () async {
        // Prevent accidental back navigation during active dispatch
        if (!_isCancelled) {
          final confirmExit = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('Leave Screen?'),
              content: const Text(
                'Your request is active. You can still monitor or return here, but leaving this view will not cancel your emergency.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(false),
                  child: const Text('Stay'),
                ),
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(true),
                  child: const Text('Leave'),
                ),
              ],
            ),
          );
          return confirmExit ?? false;
        }
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Emergency Status'),
          centerTitle: true,
          automaticallyImplyLeading: _isCancelled,
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Spacer(flex: 1),

                // Status Icon Indicator
                Center(
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    padding: const EdgeInsets.all(28),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _isCancelled
                          ? Colors.grey.shade100
                          : Colors.amber.shade50,
                      border: Border.all(
                        color: _isCancelled
                            ? Colors.grey.shade300
                            : Colors.amber.shade400,
                        width: 2.5,
                      ),
                    ),
                    child: Icon(
                      _isCancelled
                          ? Icons.cancel_outlined
                          : Icons.notifications_active_outlined,
                      size: 56,
                      color: _isCancelled
                          ? Colors.grey.shade600
                          : Colors.amber.shade800,
                    ),
                  ),
                ),

                const SizedBox(height: 28),

                // Title Status
                Text(
                  _isCancelled
                      ? 'Request Cancelled'
                      : 'Help is being notified',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: _isCancelled ? Colors.grey.shade800 : Colors.black87,
                  ),
                ),

                const SizedBox(height: 10),

                // Description Subtitle
                Text(
                  _isCancelled
                      ? 'This emergency request has been marked cancelled. No further dispatch actions will be taken.'
                      : 'Your dispatch request is being broadcast to nearby verified hospitals and response teams.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.grey.shade600,
                    height: 1.4,
                  ),
                ),

                const SizedBox(height: 32),

                // Request Information Card
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Request Reference',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey.shade600,
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              Clipboard.setData(
                                ClipboardData(text: widget.requestId),
                              );
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Request ID copied to clipboard'),
                                  duration: Duration(seconds: 2),
                                ),
                              );
                            },
                            child: Row(
                              children: [
                                Text(
                                  '#$shortId',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Icon(
                                  Icons.copy_rounded,
                                  size: 14,
                                  color: Colors.grey.shade600,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Current Lifecycle State',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey.shade600,
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: _isCancelled
                                  ? Colors.red.shade50
                                  : Colors.blue.shade50,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: _isCancelled
                                    ? Colors.red.shade200
                                    : Colors.blue.shade200,
                              ),
                            ),
                            child: Text(
                              _currentStatus,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: _isCancelled
                                    ? Colors.red.shade800
                                    : Colors.blue.shade800,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const Spacer(flex: 2),

                // Action Area
                if (_isCancelled) ...[
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      backgroundColor: Colors.black87,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: _returnHome,
                    icon: const Icon(Icons.home_outlined),
                    label: const Text(
                      'Return to Home',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                ] else ...[
                  // Cancel Button with Alert / Red tint
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      foregroundColor: Colors.red.shade700,
                      side: BorderSide(color: Colors.red.shade300, width: 1.5),
                      backgroundColor: Colors.red.shade50,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: _isCancelling ? null : _confirmAndCancelRequest,
                    icon: _isCancelling
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.red,
                            ),
                          )
                        : const Icon(Icons.close_rounded, size: 20),
                    label: Text(
                      _isCancelling
                          ? 'Cancelling...'
                          : 'Cancel Emergency Request',
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}