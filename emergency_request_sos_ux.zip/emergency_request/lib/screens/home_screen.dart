import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'request_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const RequestScreen();
  }
}
