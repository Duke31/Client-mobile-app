import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config/env.dart';

class EmergencySmsFallback {
  const EmergencySmsFallback._();

  static String buildBody({
    required String emergencyType,
    required double latitude,
    required double longitude,
    String? address,
    String? callerPhone,
  }) {
    final loc = (address != null && address.trim().isNotEmpty)
        ? address.trim()
        : '${latitude.toStringAsFixed(5)}, ${longitude.toStringAsFixed(5)}';
    final caller = (callerPhone != null && callerPhone.trim().isNotEmpty)
        ? callerPhone.trim()
        : 'unknown';
    final time = DateTime.now().toIso8601String();
    return 'EMERGENCY SOS: $emergencyType | Loc: $loc | Caller: $caller | Time: $time | Map: https://maps.google.com/?q=$latitude,$longitude';
  }

  static Future<bool> openNativeSms({
    required String body,
    String? hotline,
  }) async {
    final number = (hotline ?? AppConfig.emergencySmsHotline).trim();
    if (number.isEmpty) {
      debugPrint('EMERGENCY_SMS_HOTLINE is not configured');
      return false;
    }

    final encodedBody = Uri.encodeComponent(body);
    final candidates = <Uri>[
      if (!kIsWeb && Platform.isIOS)
        Uri.parse('sms:$number&body=$encodedBody')
      else
        Uri.parse('sms:$number?body=$encodedBody'),
      Uri.parse('sms:$number?body=$encodedBody'),
      Uri(scheme: 'sms', path: number, queryParameters: {'body': body}),
      Uri(scheme: 'sms', path: number),
    ];

    for (final uri in candidates) {
      try {
        final ok = await launchUrl(
          uri,
          mode: LaunchMode.externalApplication,
        );
        if (ok) return true;
      } catch (e) {
        debugPrint('SMS launch failed for $uri: $e');
      }
    }
    return false;
  }
}
