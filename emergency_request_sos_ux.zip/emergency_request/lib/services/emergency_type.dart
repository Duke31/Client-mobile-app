/// Maps UI labels to DB CHECK-allowed emergency_type values.
/// Allowed: Trauma, Cardiac, Stroke, Respiratory, Obstetric, Pediatric, Psychiatric, Other
class EmergencyTypeNormalizer {
  const EmergencyTypeNormalizer._();

  static const allowed = <String>{
    'Trauma',
    'Cardiac',
    'Stroke',
    'Respiratory',
    'Obstetric',
    'Pediatric',
    'Psychiatric',
    'Other',
  };

  /// Returns (dbType, extraNote).
  static (String type, String? note) normalize(String raw) {
    final t = raw.trim();
    if (allowed.contains(t)) return (t, null);

    switch (t.toLowerCase()) {
      case 'accident':
      case 'road crash':
      case 'road crash / fall':
      case 'trauma / bleeding':
        return ('Trauma', 'UI: Accident / road crash / fall');
      case 'allergy':
      case 'severe anaphylaxis':
        return ('Other', 'UI: Severe anaphylaxis / allergy');
      case 'cardiac / heart':
        return ('Cardiac', null);
      case 'breathing / lungs':
        return ('Respiratory', null);
      case 'stroke / neuro':
        return ('Stroke', null);
      case 'maternity / labor':
        return ('Obstetric', null);
      case 'general emergency':
        return ('Other', null);
      default:
        return ('Other', 'UI category: $t');
    }
  }
}
