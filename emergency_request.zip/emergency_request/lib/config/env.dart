/// Compile-time environment. Values are injected with
/// `--dart-define=NAME=value` or `--dart-define-from-file=dart_defines.json`.
///
/// Never hardcode secrets in this file.
class Env {
  const Env._();

  static const supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: '',
  );

  static const supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: '',
  );

  static const mapboxAccessToken = String.fromEnvironment(
    'MAPBOX_ACCESS_TOKEN',
    defaultValue: 'YOUR_TOKEN',
  );

  /// Dispatch SMS hotline in E.164, e.g. +2348012345678
  static const emergencySmsHotline = String.fromEnvironment(
    'EMERGENCY_SMS_HOTLINE',
    defaultValue: '',
  );

  static bool get hasSupabase =>
      supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

  static bool get hasMapboxToken =>
      mapboxAccessToken.isNotEmpty && mapboxAccessToken != 'YOUR_TOKEN';

  static bool get hasEmergencySmsHotline =>
      emergencySmsHotline.trim().isNotEmpty;
}

/// App-facing config aliases.
class AppConfig {
  const AppConfig._();

  static String get emergencySmsHotline => Env.emergencySmsHotline;
}
