/// Compile-time environment. Values are injected with
/// `--dart-define=NAME=value` or `--dart-define-from-file=dart_defines.json`.
///
/// Never hardcode tokens in this file.
class Env {
  const Env._();

  static const supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: '',
  );

  static const supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: '',
  );

  static const mapboxAccessToken = String.fromEnvironment(
    'MAPBOX_ACCESS_TOKEN',
    defaultValue: 'YOUR_TOKEN',
  );

  static bool get hasSupabase =>
      supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

  static bool get hasMapboxToken =>
      mapboxAccessToken.isNotEmpty && mapboxAccessToken != 'YOUR_TOKEN';
}
