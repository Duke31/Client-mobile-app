import 'package:geolocator/geolocator.dart';

class LocationFix {
  const LocationFix({
    required this.latitude,
    required this.longitude,
    this.fromCache = false,
  });

  final double latitude;
  final double longitude;
  final bool fromCache;
}

class LocationService {
  const LocationService();

  Future<LocationFix> current() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw const LocationException(
        'Location is turned off. Turn it on and tap Refresh GPS.',
      );
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw const LocationException('Location permission was denied.');
    }
    if (permission == LocationPermission.deniedForever) {
      throw const LocationException(
        'Location permission is blocked. Enable it in Settings.',
      );
    }

    final last = await Geolocator.getLastKnownPosition();

    final attempts = <LocationSettings>[
      const LocationSettings(
        accuracy: LocationAccuracy.low,
        timeLimit: Duration(seconds: 12),
      ),
      const LocationSettings(
        accuracy: LocationAccuracy.medium,
        timeLimit: Duration(seconds: 20),
      ),
      AndroidSettings(
        accuracy: LocationAccuracy.low,
        timeLimit: const Duration(seconds: 20),
        forceLocationManager: true,
      ),
    ];

    for (final settings in attempts) {
      try {
        final position = await Geolocator.getCurrentPosition(
          locationSettings: settings,
        );
        return LocationFix(
          latitude: position.latitude,
          longitude: position.longitude,
        );
      } on Object {
        continue;
      }
    }

    if (last != null) {
      return LocationFix(
        latitude: last.latitude,
        longitude: last.longitude,
        fromCache: true,
      );
    }

    throw const LocationException(
      'Could not get a GPS fix. Turn on Location, step outside if you can, then tap Refresh GPS.',
    );
  }
}

class LocationException implements Exception {
  const LocationException(this.message);
  final String message;

  @override
  String toString() => message;
}
