import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

class LocationFix {
  const LocationFix({
    required this.latitude,
    required this.longitude,
    this.accuracyMeters,
    this.fromCache = false,
  });

  final double latitude;
  final double longitude;
  final double? accuracyMeters;
  final bool fromCache;
}

class LocationService {
  const LocationService();

  Future<LocationFix> current() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw const LocationException(
        'Location is turned off. Turn it on and tap Refresh GPS.',
      );
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw const LocationException('Location permission was denied.');
    }
    if (permission == LocationPermission.deniedForever) {
      throw const LocationException(
        'Location permission is blocked. Enable it in Settings.',
      );
    }

    // Try high accuracy satellite GPS first (accurate down to 3-10 meters)
    LocationSettings highAccuracySettings;
    if (defaultTargetPlatform == TargetPlatform.android) {
      highAccuracySettings = AndroidSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 15),
        forceLocationManager: true, // Direct hardware GPS on Android
      );
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      highAccuracySettings = AppleSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        timeLimit: const Duration(seconds: 15),
        activityType: ActivityType.otherNavigation,
      );
    } else {
      highAccuracySettings = const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 15),
      );
    }

    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: highAccuracySettings,
      );
      return LocationFix(
        latitude: position.latitude,
        longitude: position.longitude,
        accuracyMeters: position.accuracy,
      );
    } on Object {
      // If satellite fix took too long (e.g. deep indoors), try medium accuracy
    }

    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.medium,
          timeLimit: Duration(seconds: 10),
        ),
      );
      return LocationFix(
        latitude: position.latitude,
        longitude: position.longitude,
        accuracyMeters: position.accuracy,
      );
    } on Object {
      // Continue to last known fallback
    }

    final last = await Geolocator.getLastKnownPosition();
    if (last != null) {
      return LocationFix(
        latitude: last.latitude,
        longitude: last.longitude,
        accuracyMeters: last.accuracy,
        fromCache: true,
      );
    }

    throw const LocationException(
      'Could not get a GPS fix. Please ensure Location is enabled, step near a window if indoors, and try again.',
    );
  }
}

class LocationException implements Exception {
  const LocationException(this.message);
  final String message;

  @override
  String toString() => message;
}