import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

class LocationFix {
  const LocationFix({
    required this.latitude,
    required this.longitude,
    this.accuracyMeters,
    this.fromCache = false,
  });

  final double latitude;
  final double longitude;
  final double? accuracyMeters;
  final bool fromCache;
}

class LocationService {
  const LocationService();

  Future<LocationFix> current() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw const LocationException(
        'Location service is turned off. Please turn on GPS in your phone settings.',
      );
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw const LocationException('Location permission was denied.');
    }
    if (permission == LocationPermission.deniedForever) {
      throw const LocationException(
        'Location permission is permanently blocked. Enable it in App Settings.',
      );
    }

    // Use position stream to sample the best accurate GPS fix over 4 seconds
    LocationSettings streamSettings;
    if (defaultTargetPlatform == TargetPlatform.android) {
      streamSettings = AndroidSettings(
        accuracy: LocationAccuracy.best,
        intervalDuration: const Duration(milliseconds: 500),
        forceLocationManager: false, // Allows fused location provider (GPS + WiFi + Cell) for fastest indoor lock
      );
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      streamSettings = AppleSettings(
        accuracy: LocationAccuracy.best,
        activityType: ActivityType.fitness,
        pauseLocationUpdatesAutomatically: false,
      );
    } else {
      streamSettings = const LocationSettings(
        accuracy: LocationAccuracy.best,
      );
    }

    Position? bestPosition;
    final completer = Completer<Position?>();

    final subscription = Geolocator.getPositionStream(
      locationSettings: streamSettings,
    ).listen((pos) {
      if (bestPosition == null || pos.accuracy < bestPosition!.accuracy) {
        bestPosition = pos;
      }
      // If we got an accuracy under 15 meters, that is pinpoint room accuracy! Complete immediately.
      if (pos.accuracy <= 15.0 && !completer.isCompleted) {
        completer.complete(pos);
      }
    }, onError: (_) {});

    // Allow up to 5 seconds to get the most accurate fix possible
    Timer(const Duration(seconds: 5), () {
      if (!completer.isCompleted) {
        completer.complete(bestPosition);
      }
    });

    final accuratePos = await completer.future;
    await subscription.cancel();

    if (accuratePos != null) {
      return LocationFix(
        latitude: accuratePos.latitude,
        longitude: accuratePos.longitude,
        accuracyMeters: accuratePos.accuracy,
      );
    }

    // Direct fallback if stream had zero events
    try {
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 6),
        ),
      );
      return LocationFix(
        latitude: pos.latitude,
        longitude: pos.longitude,
        accuracyMeters: pos.accuracy,
      );
    } catch (_) {}

    // Final fallback: check last known position if recent
    final last = await Geolocator.getLastKnownPosition();
    if (last != null) {
      return LocationFix(
        latitude: last.latitude,
        longitude: last.longitude,
        accuracyMeters: last.accuracy,
        fromCache: true,
      );
    }

    throw const LocationException(
      'Could not acquire GPS fix. Please ensure Location is enabled, tap Refresh GPS, or tap the map to pin manually.',
    );
  }
}

class LocationException implements Exception {
  const LocationException(this.message);
  final String message;

  @override
  String toString() => message;
}