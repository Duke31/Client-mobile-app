import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

class LocationFix {
  const LocationFix({
    required this.latitude,
    required this.longitude,
    this.accuracyMeters,
    this.fromCache = false,
  });

  final double latitude;
  final double longitude;
  final double? accuracyMeters;
  final bool fromCache;
}

class LocationService {
  const LocationService();

  Future<LocationFix> current() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw const LocationException(
        'Location service is turned off. Please turn on GPS in your phone settings.',
      );
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw const LocationException('Location permission was denied.');
    }
    if (permission == LocationPermission.deniedForever) {
      throw const LocationException(
        'Location permission is permanently blocked. Enable it in App Settings.',
      );
    }

    // High accuracy satellite GPS settings (Android & iOS)
    LocationSettings highSettings;
    if (defaultTargetPlatform == TargetPlatform.android) {
      highSettings = AndroidSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        timeLimit: const Duration(seconds: 12),
        forceLocationManager: true, // Forces hardware satellite GPS instead of cell tower cache
      );
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      highSettings = AppleSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        timeLimit: const Duration(seconds: 12),
        activityType: ActivityType.otherNavigation,
      );
    } else {
      highSettings = const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 12),
      );
    }

    // 1. First attempt: Direct satellite GPS lock
    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: highSettings,
      );
      return LocationFix(
        latitude: position.latitude,
        longitude: position.longitude,
        accuracyMeters: position.accuracy,
      );
    } catch (_) {}

    // 2. Second attempt: High accuracy fallback with slightly longer window
    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 10),
        ),
      );
      return LocationFix(
        latitude: position.latitude,
        longitude: position.longitude,
        accuracyMeters: position.accuracy,
      );
    } catch (_) {}

    // 3. Last Known Position check: ONLY accept if it was recorded within the last 60 seconds
    final last = await Geolocator.getLastKnownPosition();
    if (last != null) {
      final age = DateTime.now().difference(last.timestamp);
      // Discard stale cached locations older than 60 seconds (prevents the 600m jump back bug)
      if (age.inSeconds < 60) {
        return LocationFix(
          latitude: last.latitude,
          longitude: last.longitude,
          accuracyMeters: last.accuracy,
          fromCache: true,
        );
      }
    }

    throw const LocationException(
      'Could not acquire live GPS lock. Please ensure you are not in deep cover, tap Refresh GPS, or tap the map to pin manually.',
    );
  }
}

class LocationException implements Exception {
  const LocationException(this.message);
  final String message;

  @override
  String toString() => message;
}