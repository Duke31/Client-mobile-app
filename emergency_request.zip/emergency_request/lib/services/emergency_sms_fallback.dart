import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config/env.dart';

class EmergencySmsFallback {
  const EmergencySmsFallback._();

  static String buildBody({
    required String emergencyType,
    required double latitude,
    required double longitude,
    String? address,
    String? callerPhone,
  }) {
    final loc = (address != null && address.trim().isNotEmpty)
        ? address.trim()
        : '${latitude.toStringAsFixed(5)}, ${longitude.toStringAsFixed(5)}';
    final caller = (callerPhone != null && callerPhone.trim().isNotEmpty)
        ? callerPhone.trim()
        : 'unknown';
    final time = DateTime.now().toIso8601String();
    return 'EMERGENCY SOS: $emergencyType | Loc: $loc | Caller: $caller | Time: $time';
  }

  /// Opens the native SMS app. Returns false if hotline missing or launch fails.
  static Future<bool> openNativeSms({
    required String body,
    String? hotline,
  }) async {
    final number = (hotline ?? AppConfig.emergencySmsHotline).trim();
    if (number.isEmpty) {
      debugPrint('EMERGENCY_SMS_HOTLINE is not configured');
      return false;
    }

    final encodedBody = Uri.encodeComponent(body);
    // iOS prefers &body=, Android prefers ?body=
    final uriString = !kIsWeb && Platform.isIOS
        ? 'sms:$number&body=$encodedBody'
        : 'sms:$number?body=$encodedBody';

    final uri = Uri.parse(uriString);
    if (!await canLaunchUrl(uri)) {
      // Fallback without prefilled body
      final bare = Uri(scheme: 'sms', path: number);
      if (await canLaunchUrl(bare)) {
        return launchUrl(bare);
      }
      return false;
    }
    return launchUrl(uri);
  }
}
