import 'package:supabase_flutter/supabase_flutter.dart';

import '../maps/mapbox_geocoding.dart';

/// Submits a patient emergency via the `create_emergency_request` RPC.
///
/// Address is Mapbox `place_name`, or `"lat, lng"` if geocoding fails.
class EmergencyService {
  EmergencyService({
    required this.supabase,
    MapboxGeocoding? geocoding,
  }) : geocoding = geocoding ?? MapboxGeocoding();

  final SupabaseClient supabase;
  final MapboxGeocoding geocoding;

  /// Align these RPC argument names with the live Postgres function.
  /// Current assumed signature:
  ///   create_emergency_request(p_lat float, p_lng float, p_address text)
  Future<dynamic> createRequest({
    required double latitude,
    required double longitude,
    Map<String, dynamic> extraParams = const <String, dynamic>{},
  }) async {
    final address = await geocoding.reverseGeocode(
      latitude: latitude,
      longitude: longitude,
    );

    return supabase.rpc(
      'create_emergency_request',
      params: <String, dynamic>{
        'p_lat': latitude,
        'p_lng': longitude,
        'p_address': address,
        ...extraParams,
      },
    );
  }
}
