import 'dart:math';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../maps/mapbox_geocoding.dart';

class EmergencyService {
  EmergencyService({
    required this.supabase,
    MapboxGeocoding? geocoding,
  }) : geocoding = geocoding ?? MapboxGeocoding();

  final SupabaseClient supabase;
  final MapboxGeocoding geocoding;

  Future<dynamic> createRequest({
    required double latitude,
    required double longitude,
    String? address,
    String emergencyType = 'Other',
    int priority = 2,
    String notes = '',
    String contactPhone = '',
    String ageBand = 'unknown',
    String? idempotencyKey,
    Map<String, dynamic> extraParams = const <String, dynamic>{},
  }) async {
    // Uses the app's existing authenticated user session
    final session = supabase.auth.currentSession;
    if (session == null) {
      throw Exception('User is not signed in. Please log in to dispatch an emergency.');
    }

    final resolvedAddress = (address != null && address.trim().isNotEmpty)
        ? address
        : await geocoding.reverseGeocode(
            latitude: latitude,
            longitude: longitude,
          );

    final params = <String, dynamic>{
      'p_patient_lat': latitude,
      'p_patient_lng': longitude,
      'p_patient_address': resolvedAddress.isNotEmpty ? resolvedAddress : 'Current GPS location',
      'p_emergency_type': emergencyType,
      'p_priority': priority,
      'p_notes': notes.trim().isNotEmpty ? notes.trim() : null,
      'p_contact_phone': contactPhone.trim().isNotEmpty ? contactPhone.trim() : null,
      'p_patient_age_band': ageBand,
      'p_idempotency_key': idempotencyKey ?? _uuidV4(),
      ...extraParams,
    };

    return supabase.rpc('create_emergency_request', params: params);
  }

  static String _uuidV4() {
    final r = Random.secure();
    final bytes = List<int>.generate(16, (_) => r.nextInt(256));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    String h(int i) => bytes[i].toRadixString(16).padLeft(2, '0');
    return '${h(0)}${h(1)}${h(2)}${h(3)}-${h(4)}${h(5)}-${h(6)}${h(7)}-${h(8)}${h(9)}-${h(10)}${h(11)}${h(12)}${h(13)}${h(14)}${h(15)}';
  }
}