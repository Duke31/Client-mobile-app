
import 'dart:math';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../maps/mapbox_geocoding.dart';

/// Submits a patient emergency via create_emergency_request.
///
/// Live signature:
///   p_patient_lat numeric
///   p_patient_lng numeric
///   p_patient_address text
///   p_emergency_type text
///   p_priority smallint
///   p_notes text
///   p_contact_phone text
///   p_patient_age_band text
///   p_idempotency_key uuid
class EmergencyService {
  EmergencyService({
    required this.supabase,
    MapboxGeocoding? geocoding,
  }) : geocoding = geocoding ?? MapboxGeocoding();

  final SupabaseClient supabase;
  final MapboxGeocoding geocoding;

  Future<dynamic> createRequest({
    required double latitude,
    required double longitude,
    String emergencyType = 'medical',
    int priority = 1,
    String notes = '',
    String contactPhone = '',
    String ageBand = 'unknown',
    String? idempotencyKey,
    Map<String, dynamic> extraParams = const <String, dynamic>{},
  }) async {
    final address = await geocoding.reverseGeocode(
      latitude: latitude,
      longitude: longitude,
    );

    return supabase.rpc(
      'create_emergency_request',
      params: <String, dynamic>{
        'p_patient_lat': latitude,
        'p_patient_lng': longitude,
        'p_patient_address': address,
        'p_emergency_type': emergencyType,
        'p_priority': priority,
        'p_notes': notes,
        'p_contact_phone': contactPhone,
        'p_patient_age_band': ageBand,
        'p_idempotency_key': idempotencyKey ?? _uuidV4(),
        ...extraParams,
      },
    );
  }

  static String _uuidV4() {
    final r = Random.secure();
    final bytes = List<int>.generate(16, (_) => r.nextInt(256));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    String h(int i) => bytes[i].toRadixString(16).padLeft(2, '0');
    return '${h(0)}${h(1)}${h(2)}${h(3)}-${h(4)}${h(5)}-${h(6)}${h(7)}-${h(8)}${h(9)}-${h(10)}${h(11)}${h(12)}${h(13)}${h(14)}${h(15)}';
  }
}
