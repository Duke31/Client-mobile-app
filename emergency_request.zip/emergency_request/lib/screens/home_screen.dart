import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'request_screen.dart';
import 'submitted_screen.dart';
import 'history_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  final int initialIndex;

  const HomeScreen({super.key, this.initialIndex = 0});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final SupabaseClient _supabase = Supabase.instance.client;
  int _currentIndex = 0;

  Map<String, dynamic>? _activeEmergency;
  Timer? _activeCheckTimer;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _checkActiveEmergency();
    _activeCheckTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      _checkActiveEmergency();
    });
  }

  @override
  void dispose() {
    _activeCheckTimer?.cancel();
    super.dispose();
  }

  Future<void> _checkActiveEmergency() async {
    final uid = _supabase.auth.currentUser?.id;
    if (uid == null || !mounted) return;
    try {
      final res = await _supabase
          .from('emergency_requests')
          .select('*, hospital:hospitals(name), driver:drivers(display_name, full_name, vehicle_label)')
          .eq('patient_id', uid)
          .not('status', 'in', '(completed,cancelled,failed,Completed,Cancelled / failed)')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (mounted) {
        setState(() {
          _activeEmergency = res;
        });
      }
    } catch (_) {}
  }

  void _onTabSelected(int idx) {
    HapticFeedback.selectionClick();
    setState(() => _currentIndex = idx);
  }

  @override
  Widget build(BuildContext context) {
    final hasActive = _activeEmergency != null;

    final pages = [
      // 0: SOS Screen
      RequestScreen(
        onEmergencyCreated: (requestId, address) {
          _checkActiveEmergency();
          setState(() => _currentIndex = 1);
        },
      ),

      // 1: Active Mission Tracker
      hasActive
          ? SubmittedScreen(
              key: ValueKey(_activeEmergency!['id']),
              requestId: _activeEmergency!['id']?.toString(),
              address: _activeEmergency!['patient_address']?.toString(),
            )
          : _NoActiveMissionView(
              onTriggerSos: () => setState(() => _currentIndex = 0),
            ),

      // 2: History & Feedback
      HistoryScreen(
        onSwitchToSos: () => setState(() => _currentIndex = 0),
      ),

      // 3: Medical ID & Profile
      const ProfileScreen(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF061536),
      body: IndexedStack(
        index: _currentIndex,
        children: pages,
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF07193F),
          border: Border(
            top: BorderSide(color: Color(0xFF1E3A8A), width: 1.0),
          ),
        ),
        child: NavigationBar(
          selectedIndex: _currentIndex,
          onDestinationSelected: _onTabSelected,
          backgroundColor: const Color(0xFF07193F),
          indicatorColor: const Color(0xFF00D4FF).withValues(alpha: 0.2),
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          destinations: [
            const NavigationDestination(
              icon: Icon(Icons.emergency_outlined, color: Colors.white70),
              selectedIcon: Icon(Icons.emergency_rounded, color: Color(0xFFFF334B)),
              label: 'SOS Dispatch',
            ),
            NavigationDestination(
              icon: Badge(
                isLabelVisible: hasActive,
                backgroundColor: const Color(0xFFFF334B),
                smallSize: 8,
                child: const Icon(Icons.radar_outlined, color: Colors.white70),
              ),
              selectedIcon: Badge(
                isLabelVisible: hasActive,
                backgroundColor: const Color(0xFFFF334B),
                smallSize: 8,
                child: const Icon(Icons.radar_rounded, color: Color(0xFF00D4FF)),
              ),
              label: hasActive ? 'Active Mission' : 'Live Tracker',
            ),
            const NavigationDestination(
              icon: Icon(Icons.history_rounded, color: Colors.white70),
              selectedIcon: Icon(Icons.history_rounded, color: Color(0xFF00D4FF)),
              label: 'History & Review',
            ),
            const NavigationDestination(
              icon: Icon(Icons.person_outline_rounded, color: Colors.white70),
              selectedIcon: Icon(Icons.person_rounded, color: Color(0xFF00D4FF)),
              label: 'Medical ID',
            ),
          ],
        ),
      ),
    );
  }
}

class _NoActiveMissionView extends StatelessWidget {
  final VoidCallback onTriggerSos;

  const _NoActiveMissionView({required this.onTriggerSos});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF061536),
      appBar: AppBar(
        backgroundColor: const Color(0xFF07193F),
        elevation: 0,
        title: const Text(
          'ACTIVE MISSION TRACKER',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            fontSize: 14.5,
            letterSpacing: 1.0,
          ),
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: const Color(0xFF07193F),
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFF1E3A8A), width: 1.5),
                ),
                child: const Icon(
                  Icons.sensors_off_rounded,
                  size: 48,
                  color: Color(0xFF81D4FA),
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'No Active Emergency Request',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'When you request an ambulance, live telemetry, hospital bed reservation, and responder routing will update here in real time.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 12.5,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: onTriggerSos,
                icon: const Icon(Icons.emergency_rounded, size: 22),
                label: const Text(
                  'TRIGGER EMERGENCY SOS',
                  style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.8),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
