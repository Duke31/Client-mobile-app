import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'submitted_screen.dart';

class HistoryScreen extends StatefulWidget {
  final VoidCallback? onSwitchToSos;

  const HistoryScreen({super.key, this.onSwitchToSos});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final SupabaseClient _supabase = Supabase.instance.client;
  bool _loading = true;
  List<Map<String, dynamic>> _history = [];
  final Map<String, int> _ratedRequests = {};

  @override
  void initState() {
    super.initState();
    _fetchHistory();
  }

  Future<void> _fetchHistory() async {
    setState(() => _loading = true);
    final uid = _supabase.auth.currentUser?.id;
    if (uid == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }

    try {
      final res = await _supabase
          .from('emergency_requests')
          .select('*, hospital:hospitals(name, address), driver:drivers(display_name, full_name, vehicle_label, phone, phone_number)')
          .eq('patient_id', uid)
          .order('created_at', ascending: false)
          .limit(30);

      if (mounted) {
        setState(() {
          _history = List<Map<String, dynamic>>.from(res);
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  void _openFeedbackModal(Map<String, dynamic> req) {
    HapticFeedback.lightImpact();
    final reqId = req['id']?.toString() ?? '';
    final existingRating = _ratedRequests[reqId] ?? 5;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _FeedbackBottomSheet(
        request: req,
        initialRating: existingRating,
        onSubmit: (rating, tags, comment) async {
          setState(() {
            _ratedRequests[reqId] = rating;
          });

          // Save feedback to request notes or table
          try {
            final oldNotes = req['notes']?.toString() ?? '';
            final feedbackPayload = '[PATIENT FEEDBACK: $rating★ | Tags: ${tags.join(', ')} | Note: $comment]';
            final newNotes = oldNotes.isNotEmpty ? '$oldNotes\n$feedbackPayload' : feedbackPayload;

            await _supabase.from('emergency_requests').update({
              'notes': newNotes,
            }).eq('id', reqId);
          } catch (_) {}

          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Thank you! Your feedback helps optimize our emergency fleet.'),
                backgroundColor: Color(0xFF00E676),
              ),
            );
          }
        },
      ),
    );
  }

  String _formatDate(String? iso) {
    if (iso == null || iso.isEmpty) return 'Recent';
    try {
      final dt = DateTime.parse(iso).toLocal();
      final month = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ][dt.month - 1];
      final hour = dt.hour.toString().padLeft(2, '0');
      final min = dt.minute.toString().padLeft(2, '0');
      return '$month ${dt.day}, ${dt.year} • $hour:$min';
    } catch (_) {
      return iso;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF061536),
      appBar: AppBar(
        backgroundColor: const Color(0xFF07193F),
        elevation: 0,
        centerTitle: false,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              'EMERGENCY HISTORY',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 15,
                letterSpacing: 1.0,
              ),
            ),
            Text(
              'Previous Missions & Service Ratings',
              style: TextStyle(
                color: Color(0xFF81D4FA),
                fontSize: 10,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Color(0xFF00D4FF)),
            onPressed: _fetchHistory,
            tooltip: 'Refresh History',
          ),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF00D4FF)),
            )
          : _history.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(28.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: const Color(0xFF07193F),
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xFF1E3A8A)),
                          ),
                          child: const Icon(
                            Icons.history_rounded,
                            size: 44,
                            color: Color(0xFF81D4FA),
                          ),
                        ),
                        const SizedBox(height: 18),
                        const Text(
                          'No Emergency History',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Your completed emergency dispatches and feedback reviews will appear here.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white60,
                            fontSize: 12.5,
                            height: 1.4,
                          ),
                        ),
                        if (widget.onSwitchToSos != null) ...[
                          const SizedBox(height: 20),
                          FilledButton.icon(
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFFD32F2F),
                              foregroundColor: Colors.white,
                            ),
                            onPressed: widget.onSwitchToSos,
                            icon: const Icon(Icons.emergency_rounded),
                            label: const Text('Go to Emergency SOS'),
                          ),
                        ],
                      ],
                    ),
                  ),
                )
              : RefreshIndicator(
                  color: const Color(0xFF00D4FF),
                  backgroundColor: const Color(0xFF07193F),
                  onRefresh: _fetchHistory,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _history.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, idx) {
                      final item = _history[idx];
                      final id = item['id']?.toString() ?? '';
                      final status = item['status']?.toString() ?? 'Unknown';
                      final type = item['emergency_type']?.toString() ?? 'Emergency';
                      final dateStr = _formatDate(item['created_at']?.toString());
                      final address = item['patient_address']?.toString() ?? 'GPS Location';
                      final hospital = item['hospital']?['name']?.toString();
                      final driver = item['driver']?['display_name']?.toString() ??
                          item['driver']?['full_name']?.toString();
                      final vehicle = item['driver']?['vehicle_label']?.toString();
                      final isRated = _ratedRequests.containsKey(id);
                      final rating = _ratedRequests[id] ?? 5;

                      final isCompleted = status.toLowerCase().contains('complete');
                      final isCancelled = status.toLowerCase().contains('cancel') ||
                          status.toLowerCase().contains('fail');
                      final isActive = !isCompleted && !isCancelled;

                      return Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: const Color(0xFF07193F),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isActive
                                ? const Color(0xFFFF334B)
                                : (isCompleted
                                    ? const Color(0xFF00E676).withValues(alpha: 0.5)
                                    : const Color(0xFF1E3A8A)),
                            width: isActive ? 1.5 : 1.0,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Header row
                            Row(
                              children: [
                                Text(
                                  dateStr,
                                  style: const TextStyle(
                                    color: Colors.white60,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                const Spacer(),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: isActive
                                        ? Colors.red.shade900.withValues(alpha: 0.5)
                                        : (isCompleted
                                            ? Colors.green.shade900.withValues(alpha: 0.4)
                                            : Colors.grey.shade800),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    status.toUpperCase(),
                                    style: TextStyle(
                                      color: isActive
                                          ? const Color(0xFFFF8A80)
                                          : (isCompleted
                                              ? const Color(0xFF00E676)
                                              : Colors.white70),
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),

                            // Emergency type
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(6),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF00D4FF).withValues(alpha: 0.15),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.emergency_rounded,
                                    color: Color(0xFF00D4FF),
                                    size: 16,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    type,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.5,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),

                            // Address
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(Icons.location_on_rounded, size: 14, color: Colors.white38),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    address,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: Colors.white70, fontSize: 11.5),
                                  ),
                                ),
                              ],
                            ),

                            if (hospital != null) ...[
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  const Icon(Icons.local_hospital_rounded, size: 14, color: Color(0xFF00ACC1)),
                                  const SizedBox(width: 6),
                                  Expanded(
                                    child: Text(
                                      'Hospital: $hospital',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(color: Color(0xFF80DEEA), fontSize: 11.5),
                                    ),
                                  ),
                                ],
                              ),
                            ],

                            if (driver != null) ...[
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  const Icon(Icons.directions_car_rounded, size: 14, color: Color(0xFF81D4FA)),
                                  const SizedBox(width: 6),
                                  Expanded(
                                    child: Text(
                                      'Ambulance Crew: $driver ${vehicle != null ? "($vehicle)" : ""}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(color: Color(0xFF81D4FA), fontSize: 11.5),
                                    ),
                                  ),
                                ],
                              ),
                            ],

                            const SizedBox(height: 12),
                            const Divider(color: Colors.white12, height: 1),
                            const SizedBox(height: 10),

                            // Action buttons
                            Row(
                              children: [
                                if (isActive)
                                  Expanded(
                                    child: FilledButton.icon(
                                      style: FilledButton.styleFrom(
                                        backgroundColor: const Color(0xFFD32F2F),
                                        foregroundColor: Colors.white,
                                        padding: const EdgeInsets.symmetric(vertical: 8),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                      ),
                                      onPressed: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) => SubmittedScreen(
                                              requestId: id,
                                              address: address,
                                            ),
                                          ),
                                        );
                                      },
                                      icon: const Icon(Icons.radar_rounded, size: 16),
                                      label: const Text('View Live Mission', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                                    ),
                                  )
                                else ...[
                                  Expanded(
                                    child: isRated
                                        ? Row(
                                            children: [
                                              Row(
                                                children: List.generate(
                                                  5,
                                                  (i) => Icon(
                                                    i < rating ? Icons.star_rounded : Icons.star_border_rounded,
                                                    color: Colors.amber,
                                                    size: 16,
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              const Text(
                                                'Reviewed',
                                                style: TextStyle(color: Colors.white70, fontSize: 11),
                                              ),
                                            ],
                                          )
                                        : OutlinedButton.icon(
                                            style: OutlinedButton.styleFrom(
                                              foregroundColor: const Color(0xFF00D4FF),
                                              side: const BorderSide(color: Color(0xFF00D4FF)),
                                              padding: const EdgeInsets.symmetric(vertical: 8),
                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                            ),
                                            onPressed: () => _openFeedbackModal(item),
                                            icon: const Icon(Icons.star_outline_rounded, size: 16),
                                            label: const Text('Rate Service Experience', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                                          ),
                                  ),
                                ],
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}

class _FeedbackBottomSheet extends StatefulWidget {
  final Map<String, dynamic> request;
  final int initialRating;
  final Function(int rating, List<String> tags, String comment) onSubmit;

  const _FeedbackBottomSheet({
    required this.request,
    required this.initialRating,
    required this.onSubmit,
  });

  @override
  State<_FeedbackBottomSheet> createState() => _FeedbackBottomSheetState();
}

class _FeedbackBottomSheetState extends State<_FeedbackBottomSheet> {
  late int _rating;
  final _commentController = TextEditingController();
  final Set<String> _selectedTags = {};

  final List<String> _availableTags = [
    '⚡ Fast Response',
    '🩺 Skilled Paramedics',
    '🚑 Clean Ambulance',
    '🏥 Smooth ER Handover',
    '📞 Clear Dispatch Updates',
    '🤝 Compassionate Care',
  ];

  @override
  void initState() {
    super.initState();
    _rating = widget.initialRating;
  }

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF07193F),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(top: BorderSide(color: Color(0xFF00D4FF), width: 1.5)),
      ),
      padding: EdgeInsets.fromLTRB(20, 16, 20, 20 + bottomInset),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Solace Service Feedback',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 17,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'How was your emergency response and hospital triage experience?',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60, fontSize: 12),
            ),
            const SizedBox(height: 18),

            // Star Rating Bar
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (index) {
                final starNum = index + 1;
                return IconButton(
                  iconSize: 36,
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  icon: Icon(
                    starNum <= _rating ? Icons.star_rounded : Icons.star_border_rounded,
                    color: Colors.amber,
                  ),
                  onPressed: () {
                    HapticFeedback.selectionClick();
                    setState(() => _rating = starNum);
                  },
                );
              }),
            ),
            const SizedBox(height: 14),

            // Quick Feedback Chips
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: _availableTags.map((tag) {
                final isSelected = _selectedTags.contains(tag);
                return FilterChip(
                  label: Text(tag, style: TextStyle(fontSize: 11, color: isSelected ? Colors.black : Colors.white)),
                  selected: isSelected,
                  selectedColor: const Color(0xFF00D4FF),
                  backgroundColor: const Color(0xFF0D2559),
                  checkmarkColor: Colors.black,
                  onSelected: (val) {
                    setState(() {
                      if (val) {
                        _selectedTags.add(tag);
                      } else {
                        _selectedTags.remove(tag);
                      }
                    });
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 14),

            // Comments
            TextField(
              controller: _commentController,
              maxLines: 3,
              style: const TextStyle(color: Colors.white, fontSize: 12.5),
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF0D2559),
                hintText: 'Share any details or suggestions for the Solace operations desk...',
                hintStyle: const TextStyle(color: Colors.white30, fontSize: 11.5),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Submit Button
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF00D4FF),
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () {
                Navigator.pop(context);
                widget.onSubmit(_rating, _selectedTags.toList(), _commentController.text.trim());
              },
              child: const Text('Submit Service Feedback', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5)),
            ),
          ],
        ),
      ),
    );
  }
}
