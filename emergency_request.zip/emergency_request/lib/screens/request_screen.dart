
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../maps/mapbox_geocoding.dart';
import '../maps/mapbox_map_view.dart';
import '../services/emergency_service.dart';
import '../services/location_service.dart';
import 'submitted_screen.dart';

const LatLng kDefaultCenter = LatLng(6.5244, 3.3792);

class RequestScreen extends StatefulWidget {
  const RequestScreen({super.key});

  @override
  State<RequestScreen> createState() => _RequestScreenState();
}

class _RequestScreenState extends State<RequestScreen> {
  final _location = const LocationService();
  final _geocoding = MapboxGeocoding();
  final _mapController = MapController();

  bool _loadingLocation = true;
  bool _submitting = false;
  String? _error;
  LocationFix? _fix;
  String _address = '';

  @override
  void initState() {
    super.initState();
    _loadLocation();
  }

  @override
  void dispose() {
    _geocoding.dispose();
    super.dispose();
  }

  Future<void> _applyFix(LocationFix fix, {String? notice}) async {
    final address = await _geocoding.reverseGeocode(
      latitude: fix.latitude,
      longitude: fix.longitude,
    );
    if (!mounted) return;
    setState(() {
      _fix = fix;
      _address = address;
      _loadingLocation = false;
      _error = notice;
    });
    try {
      _mapController.move(LatLng(fix.latitude, fix.longitude), 15);
    } catch (_) {}
  }

  Future<void> _loadLocation() async {
    setState(() {
      _loadingLocation = true;
      _error = null;
    });
    try {
      final fix = await _location.current();
      await _applyFix(
        fix,
        notice: fix.fromCache
            ? 'Using last known location. Tap the map if this is wrong.'
            : null,
      );
    } on LocationException catch (e) {
      if (!mounted) return;
      setState(() {
        _loadingLocation = false;
        _error = '${e.message} Tap the map to drop a pin.';
        _fix ??= LocationFix(
          latitude: kDefaultCenter.latitude,
          longitude: kDefaultCenter.longitude,
        );
        if (_address.isEmpty) {
          _address = 'Tap the map to set the location';
        }
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loadingLocation = false;
        _error = '$e  Tap the map to drop a pin.';
        _fix ??= LocationFix(
          latitude: kDefaultCenter.latitude,
          longitude: kDefaultCenter.longitude,
        );
      });
    }
  }

  Future<void> _onMapTap(TapPosition _, LatLng point) async {
    await _applyFix(
      LocationFix(latitude: point.latitude, longitude: point.longitude),
      notice: 'Pinned location. Move the pin if needed.',
    );
  }

  Future<void> _submit() async {
    final fix = _fix;
    if (fix == null || _submitting) return;
    setState(() => _submitting = true);
    try {
      final service = EmergencyService(
        supabase: Supabase.instance.client,
        geocoding: _geocoding,
      );
      await service.createRequest(
        latitude: fix.latitude,
        longitude: fix.longitude,
      );
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => SubmittedScreen(
            latitude: fix.latitude,
            longitude: fix.longitude,
            address: _address,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _submitting = false;
        _error = 'Could not submit request: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Confirm location')),
      body: Column(
        children: <Widget>[
          Expanded(child: _buildMap()),
          _buildSheet(context),
        ],
      ),
    );
  }

  Widget _buildMap() {
    if (_loadingLocation && _fix == null) {
      return const Center(child: CircularProgressIndicator());
    }
    final fix = _fix;
    final center = fix == null
        ? kDefaultCenter
        : LatLng(fix.latitude, fix.longitude);
    return MapboxMapView(
      center: center,
      zoom: 14,
      mapController: _mapController,
      onTap: _onMapTap,
      markers: <Marker>[
        Marker(
          point: center,
          width: 44,
          height: 44,
          alignment: Alignment.topCenter,
          child: const Icon(Icons.location_on, color: Color(0xFFC62828), size: 40),
        ),
      ],
    );
  }

  Widget _buildSheet(BuildContext context) {
    return Material(
      elevation: 8,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text('Dispatch address', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 6),
              Text(_address.isEmpty ? 'Tap the map to set a location' : _address),
              if (_error != null) ...[
                const SizedBox(height: 8),
                Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ],
              const SizedBox(height: 16),
              Row(
                children: <Widget>[
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _loadingLocation ? null : _loadLocation,
                      child: const Text('Refresh GPS'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: FilledButton(
                      onPressed: _fix == null || _submitting ? null : _submit,
                      child: _submitting
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text('Send emergency request'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
