import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../maps/mapbox_geocoding.dart';
import '../maps/mapbox_map_view.dart';
import '../services/emergency_service.dart';
import '../services/emergency_type.dart';
import '../services/emergency_sms_fallback.dart';
import '../config/env.dart';
import '../services/location_service.dart';
import 'profile_screen.dart';
import 'submitted_screen.dart';
import 'live_ambulance_tracking_screen.dart';

const LatLng kDefaultCenter = LatLng(6.5244, 3.3792);

class RequestScreen extends StatefulWidget {
  const RequestScreen({super.key});

  @override
  State<RequestScreen> createState() => _RequestScreenState();
}

class _RequestScreenState extends State<RequestScreen>
    with SingleTickerProviderStateMixin {
  final _location = const LocationService();
  final _geocoding = MapboxGeocoding();
  final _mapController = MapController();

  late final AnimationController _pulseController;
  late final Animation<double> _pulseScale;
  late final Animation<double> _pulseOpacity;

  bool _loadingLocation = true;
  bool _submitting = false;
  bool _fallbackTriggered = false;
  LocationFix? _fix;
  String _address = '';

  // Active mission tracking state
  Map<String, dynamic>? _activeMission;
  Timer? _activeMissionTimer;

  // Selected quick condition
  String _selectedCondition = 'Cardiac';
  int _selectedPriority = 1;

  // Cached profile data
  String? _profileName;
  String? _profilePhone;
  String? _profileAgeBand;
  String? _profileBloodGroup;
  String? _profileAllergies;
  String? _profileConditions;

  static const List<Map<String, dynamic>> _conditions = [
    {
      'label': 'Cardiac',
      'icon': Icons.favorite_rounded,
      'color': Color(0xFFE53935),
      'priority': 1,
      'hint': 'Chest pain, heart attack symptoms',
    },
    {
      'label': 'Accident',
      'icon': Icons.car_crash_rounded,
      'color': Color(0xFFFB8C00),
      'priority': 1,
      'hint': 'Vehicle crash, collision, severe fall',
    },
    {
      'label': 'Trauma',
      'icon': Icons.healing_rounded,
      'color': Color(0xFFD81B60),
      'priority': 1,
      'hint': 'Severe bleeding, deep injury, fracture',
    },
    {
      'label': 'Respiratory',
      'icon': Icons.air_rounded,
      'color': Color(0xFF00ACC1),
      'priority': 1,
      'hint': 'Severe breathing difficulty, choking',
    },
    {
      'label': 'Stroke',
      'icon': Icons.psychology_rounded,
      'color': Color(0xFF8E24AA),
      'priority': 1,
      'hint': 'Facial numbness, slurred speech, paralysis',
    },
    {
      'label': 'Allergy',
      'icon': Icons.vaccines_rounded,
      'color': Color(0xFFFFB300),
      'priority': 1,
      'hint': 'Severe anaphylaxis, throat swelling, allergic reaction',
    },
    {
      'label': 'Obstetric',
      'icon': Icons.pregnant_woman_rounded,
      'color': Color(0xFFEC407A),
      'priority': 2,
      'hint': 'Active labor, pregnancy crisis',
    },
    {
      'label': 'Other',
      'icon': Icons.medical_services_rounded,
      'color': Color(0xFF1E88E5),
      'priority': 2,
      'hint': 'Unresponsive patient, poisoning, general emergency',
    },
  ];

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();

    _pulseScale = Tween<double>(begin: 1.0, end: 1.4).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeOutQuad),
    );

    _pulseOpacity = Tween<double>(begin: 0.6, end: 0.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeOutQuad),
    );

    _loadLocation();
    _fetchProfileDefaults();
    _checkActiveMission();

    _activeMissionTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      _checkActiveMission();
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _activeMissionTimer?.cancel();
    _geocoding.dispose();
    super.dispose();
  }

  Future<void> _checkActiveMission() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null || !mounted) return;
    try {
      final res = await Supabase.instance.client
          .from('emergency_requests')
          .select('id, status, emergency_type, patient_address, patient_lat, patient_lng, created_at, driver_id, drivers(full_name, phone_number, vehicle_label)')
          .eq('patient_id', uid)
          .not('status', 'in', '(completed,cancelled,failed)')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (mounted) {
        setState(() {
          _activeMission = res;
        });
      }
    } catch (_) {}
  }

  Future<void> _fetchProfileDefaults() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      final res = await Supabase.instance.client
          .from('profiles')
          .select('full_name, phone, age_band, blood_group, allergies, chronic_conditions')
          .eq('user_id', userId)
          .maybeSingle();
      if (res != null && mounted) {
        setState(() {
          _profileName = res['full_name']?.toString();
          _profilePhone = res['phone']?.toString();
          _profileAgeBand = res['age_band']?.toString();
          _profileBloodGroup = res['blood_group']?.toString();
          _profileAllergies = res['allergies']?.toString();
          _profileConditions = res['chronic_conditions']?.toString();
        });
      }
    } catch (_) {}
  }

  Future<void> _applyFix(LocationFix fix) async {
    if (!mounted) return;
    setState(() {
      _fix = fix;
      _loadingLocation = false;
    });
    try {
      _mapController.move(LatLng(fix.latitude, fix.longitude), 16.5);
    } catch (_) {}

    // Reverse geocode asynchronously in background without blocking
    _geocoding.reverseGeocode(
      latitude: fix.latitude,
      longitude: fix.longitude,
    ).then((addr) {
      if (mounted && addr.isNotEmpty) {
        setState(() => _address = addr);
      }
    });
  }

  Future<void> _loadLocation() async {
    // 1. FAST PATH: Apply last-known position immediately (<50ms)
    final estimate = await _location.quickEstimate();
    if (estimate != null && mounted) {
      await _applyFix(estimate);
    }

    // 2. HIGH ACCURACY: Acquire precision satellite fix
    try {
      final fix = await _location.current();
      if (mounted) {
        await _applyFix(fix);
      }
    } on LocationException catch (e) {
      if (!mounted) return;
      if (_fix == null) {
        final fallback = LocationFix(
          latitude: kDefaultCenter.latitude,
          longitude: kDefaultCenter.longitude,
          fromCache: true,
        );
        await _applyFix(fallback);
      }
    } catch (e) {
      if (!mounted) return;
      if (_fix == null) {
        final fallback = LocationFix(
          latitude: kDefaultCenter.latitude,
          longitude: kDefaultCenter.longitude,
          fromCache: true,
        );
        await _applyFix(fallback);
      }
    }
  }

  Future<void> _onMapTap(TapPosition _, LatLng point) async {
    HapticFeedback.lightImpact();
    await _applyFix(
      LocationFix(latitude: point.latitude, longitude: point.longitude),
    );
  }

  Future<void> _shareLocationViaSms() async {
    if (_fix == null) return;
    final body = EmergencySmsFallback.buildBody(
      emergencyType: _selectedCondition,
      latitude: _fix!.latitude,
      longitude: _fix!.longitude,
      address: _address,
      callerPhone: _profilePhone,
    );
    final launched = await EmergencySmsFallback.openNativeSms(body: body);
    if (!launched && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Could not launch SMS app. Please check device messaging permissions.'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  Future<void> _openSosDispatchSheet() async {
    if (_fix == null || _submitting) return;

    HapticFeedback.heavyImpact();

    final intake = await showModalBottomSheet<_IntakeData>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _EmergencyConfirmSheet(
        defaultPhone: _profilePhone,
        defaultAgeBand: _profileAgeBand,
        bloodGroup: _profileBloodGroup,
        allergies: _profileAllergies,
        conditions: _profileConditions,
        initialCondition: _selectedCondition,
        initialPriority: _selectedPriority,
        currentAddress: _address,
        latitude: _fix!.latitude,
        longitude: _fix!.longitude,
      ),
    );

    if (intake == null) return;
    await _executeEmergencyRequest(_fix!, intake);
  }

  Future<void> _executeEmergencyRequest(LocationFix fix, _IntakeData intake) async {
    setState(() => _submitting = true);
    final supabase = Supabase.instance.client;

    try {
      String? createdRequestId;
      final service = EmergencyService(
        supabase: supabase,
        geocoding: _geocoding,
      );

      final finalAddress = (intake.manualAddress != null && intake.manualAddress!.trim().isNotEmpty)
          ? intake.manualAddress!.trim()
          : (_address.isNotEmpty ? _address : 'GPS: ${fix.latitude}, ${fix.longitude}');

      final notesList = <String>[];
      if (intake.manualAddress != null && intake.manualAddress!.trim().isNotEmpty) {
        notesList.add('📍 Entrance/Room: ${intake.manualAddress!.trim()}');
      }
      if (intake.notes != null && intake.notes!.trim().isNotEmpty) {
        notesList.add(intake.notes!.trim());
      }
      if (_profileBloodGroup != null && _profileBloodGroup != 'Unknown') {
        notesList.add('Blood: $_profileBloodGroup');
      }
      if (_profileAllergies != null && _profileAllergies!.trim().isNotEmpty) {
        notesList.add('Allergies: $_profileAllergies');
      }
      if (_profileConditions != null && _profileConditions!.trim().isNotEmpty) {
        notesList.add('Conditions: $_profileConditions');
      }

      // Add condition specific context note
      for (final c in _conditions) {
        if (c['label'] == intake.condition && c['hint'] is String) {
          notesList.add('Note: ${c['hint']}');
          break;
        }
      }

      final assembledNotes = notesList.isNotEmpty ? notesList.join(' | ') : '';

      final rpcResult = await service.createRequest(
        latitude: fix.latitude,
        longitude: fix.longitude,
        address: finalAddress,
        emergencyType: intake.condition,
        ageBand: intake.ageBand,
        contactPhone: intake.contactPhone ?? '',
        notes: assembledNotes,
        priority: intake.priority,
      );

      if (rpcResult is Map && rpcResult['id'] != null) {
        createdRequestId = rpcResult['id'] as String;
      }

      if (!mounted) return;

      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => SubmittedScreen(
            requestId: createdRequestId,
            latitude: fix.latitude,
            longitude: fix.longitude,
            address: finalAddress,
          ),
        ),
      );
    } on EmergencyNetworkException {
      if (!mounted) return;
      setState(() {
        _submitting = false;
        _fallbackTriggered = true;
      });
      await _showOfflineFallbackSheet(fix, intake);
    } catch (e) {
      if (!mounted) return;
      final msg = e.toString();
      final looksNetwork = msg.contains('SocketException') ||
          msg.contains('Failed host lookup') ||
          msg.contains('Network') ||
          msg.contains('timed out') ||
          msg.contains('Timeout');
      setState(() {
        _submitting = false;
        if (looksNetwork) {
          _fallbackTriggered = true;
        }
      });
      if (looksNetwork) {
        await _showOfflineFallbackSheet(fix, intake);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not submit request: $e'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  Future<void> _showOfflineFallbackSheet(
    LocationFix fix,
    _IntakeData intake,
  ) async {
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return Container(
          decoration: const BoxDecoration(
            color: Color(0xFF07193F),
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            border: Border(
              top: BorderSide(color: Color(0xFF00D4FF), width: 1.5),
            ),
          ),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Row(
                children: [
                  Icon(Icons.wifi_off_rounded, color: Colors.amber, size: 28),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Dispatch Server Offline',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Text(
                'Data connection failed. Switch to SMS dispatch immediately so our dispatch center receives your exact GPS coordinates.',
                style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.4),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF00D4FF),
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () async {
                  Navigator.pop(ctx);
                  final smsBody = EmergencySmsFallback.buildBody(
                    emergencyType: intake.condition,
                    latitude: fix.latitude,
                    longitude: fix.longitude,
                    address: _address,
                    callerPhone: intake.contactPhone,
                  );
                  await EmergencySmsFallback.openNativeSms(body: smsBody);
                },
                icon: const Icon(Icons.sms_outlined),
                label: const Text(
                  'Transmit Emergency Via SMS',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasActiveMission = _activeMission != null;
    final accuracy = _fix?.accuracyMeters;

    return Scaffold(
      backgroundColor: const Color(0xFF061536),
      appBar: AppBar(
        backgroundColor: const Color(0xFF07193F),
        elevation: 0,
        centerTitle: false,
        leadingWidth: 44,
        leading: Padding(
          padding: const EdgeInsets.only(left: 12.0),
          child: Image.asset(
            'assets/images/solace_icon.png',
            height: 28,
            width: 28,
            errorBuilder: (_, __, ___) => const Icon(
              Icons.emergency_rounded,
              color: Color(0xFF00D4FF),
              size: 26,
            ),
          ),
        ),
        title: const Text(
          'SOLACE EMERGENCY',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            fontSize: 15.5,
            letterSpacing: 1.1,
          ),
        ),
        actions: [
          // Medical ID Button (Clean, no overlap with title)
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: ActionChip(
              avatar: const Icon(
                Icons.medical_information_rounded,
                size: 15,
                color: Color(0xFF00D4FF),
              ),
              label: Text(
                _profileBloodGroup != null &&
                        _profileBloodGroup != 'Unknown' &&
                        _profileBloodGroup!.isNotEmpty
                    ? '🩸 $_profileBloodGroup'
                    : 'Medical ID',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
              backgroundColor: const Color(0xFF0D2559),
              side: const BorderSide(color: Color(0xFF00D4FF), width: 0.8),
              onPressed: () async {
                await Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const ProfileScreen()),
                );
                _fetchProfileDefaults();
              },
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              // 1. ACTIVE MISSION BANNER (If an ambulance is currently dispatched)
              if (hasActiveMission)
                InkWell(
                  onTap: () {
                    final reqId = _activeMission!['id'] as String;
                    final lat = (_activeMission!['patient_lat'] as num?)?.toDouble() ??
                        _fix?.latitude ??
                        kDefaultCenter.latitude;
                    final lng = (_activeMission!['patient_lng'] as num?)?.toDouble() ??
                        _fix?.longitude ??
                        kDefaultCenter.longitude;
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => LiveAmbulanceTrackingScreen(
                          requestId: reqId,
                          patientLocation: LatLng(lat, lng),
                          patientAddress: _activeMission!['patient_address'] as String?,
                        ),
                      ),
                    );
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.red.shade900,
                          const Color(0xFF07193F),
                        ],
                      ),
                      border: const Border(
                        bottom: BorderSide(color: Color(0xFFFF334B), width: 1.5),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.sensors_rounded, color: Color(0xFF00D4FF), size: 22),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '🚨 AMBULANCE EN ROUTE • ${_activeMission!['status']?.toString().toUpperCase()}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 0.8,
                                ),
                              ),
                              Text(
                                'Unit: ${_activeMission!['drivers']?['vehicle_label'] ?? 'Assigned Medic'} • Tap to Track Live',
                                style: const TextStyle(
                                  color: Color(0xFF80D8FF),
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white70, size: 14),
                      ],
                    ),
                  ),
                ),

              // 2. INTERACTIVE MAP SECTION
              Expanded(
                flex: 5,
                child: Stack(
                  children: [
                    MapboxMapView.patientLocation(
                      latitude: _fix?.latitude ?? kDefaultCenter.latitude,
                      longitude: _fix?.longitude ?? kDefaultCenter.longitude,
                      zoom: 16.5,
                      interactive: true,
                      mapController: _mapController,
                      onTap: _onMapTap,
                    ),

                    // Live GPS Accuracy Tag (Top Left)
                    Positioned(
                      top: 12,
                      left: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF07193F).withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: accuracy != null && accuracy <= 25
                                ? const Color(0xFF00E676)
                                : const Color(0xFF00D4FF),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.3),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              accuracy != null && accuracy <= 25
                                  ? Icons.my_location_rounded
                                  : Icons.gps_fixed_rounded,
                              size: 14,
                              color: accuracy != null && accuracy <= 25
                                  ? const Color(0xFF00E676)
                                  : const Color(0xFF00D4FF),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              accuracy != null
                                  ? 'GPS Lock: ±${accuracy.round()}m'
                                  : 'Acquiring GPS...',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Recenter GPS Button (Top Right)
                    Positioned(
                      top: 12,
                      right: 12,
                      child: FloatingActionButton.small(
                        heroTag: 'recenter_gps',
                        backgroundColor: const Color(0xFF07193F),
                        foregroundColor: const Color(0xFF00D4FF),
                        elevation: 4,
                        tooltip: 'Re-acquire GPS',
                        onPressed: _loadLocation,
                        child: _loadingLocation
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Color(0xFF00D4FF),
                                ),
                              )
                            : const Icon(Icons.near_me_rounded, size: 20),
                      ),
                    ),

                    // Address Card over Map (Bottom of Map)
                    Positioned(
                      bottom: 12,
                      left: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: const Color(0xFF07193F).withValues(alpha: 0.95),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: const Color(0xFF1E3A8A), width: 1.2),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.4),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.pin_drop_rounded,
                              color: Color(0xFF00D4FF),
                              size: 20,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Row(
                                    children: const [
                                      Text(
                                        'PICKUP LOCATION',
                                        style: TextStyle(
                                          color: Color(0xFF81D4FA),
                                          fontSize: 9,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 0.8,
                                        ),
                                      ),
                                      Spacer(),
                                      Text(
                                        'Tap map to adjust',
                                        style: TextStyle(
                                          color: Colors.white38,
                                          fontSize: 9,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    _address.isNotEmpty
                                        ? _address
                                        : 'Locating street address...',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // 3. FOCUSED, STRAIGHTFORWARD EMERGENCY SOS CONSOLE
              Container(
                decoration: const BoxDecoration(
                  color: Color(0xFF061536),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
                ),
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Clean Condition Quick Chips (Horizontal Row - Simple & Not Distracting)
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: _conditions.map((c) {
                          final label = c['label'] as String;
                          final isSelected = label == _selectedCondition;
                          final color = c['color'] as Color;

                          return Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: FilterChip(
                              avatar: Icon(
                                c['icon'] as IconData,
                                size: 16,
                                color: isSelected ? Colors.white : color,
                              ),
                              label: Text(label),
                              selected: isSelected,
                              selectedColor: color,
                              backgroundColor: const Color(0xFF0D2559),
                              labelStyle: TextStyle(
                                color: isSelected ? Colors.white : Colors.white70,
                                fontSize: 11,
                                fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                              ),
                              side: BorderSide(
                                color: isSelected ? color : Colors.white12,
                                width: isSelected ? 1.5 : 1,
                              ),
                              onSelected: (val) {
                                if (val) {
                                  HapticFeedback.selectionClick();
                                  setState(() {
                                    _selectedCondition = label;
                                    _selectedPriority = c['priority'] as int;
                                  });
                                }
                              },
                            ),
                          );
                        }).toList(),
                      ),
                    ),

                    const SizedBox(height: 14),

                    // STRAIGHTFORWARD PROMINENT SOS BUTTON
                    SizedBox(
                      height: 80,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Pulsing animated radar ring
                          AnimatedBuilder(
                            animation: _pulseController,
                            builder: (context, child) {
                              return Transform.scale(
                                scale: _pulseScale.value,
                                child: Container(
                                  width: double.infinity,
                                  height: 64,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(32),
                                    color: const Color(0xFFFF334B).withValues(
                                      alpha: _pulseOpacity.value,
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),

                          // Main Action Button
                          SizedBox(
                            width: double.infinity,
                            height: 64,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFD32F2F),
                                foregroundColor: Colors.white,
                                elevation: 8,
                                shadowColor: const Color(0xFFFF334B).withValues(alpha: 0.5),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(32),
                                  side: const BorderSide(
                                    color: Color(0xFFFF8A80),
                                    width: 1.8,
                                  ),
                                ),
                              ),
                              onPressed: _submitting ? null : _openSosDispatchSheet,
                              child: _submitting
                                  ? const SizedBox(
                                      width: 26,
                                      height: 26,
                                      child: CircularProgressIndicator(
                                        color: Colors.white,
                                        strokeWidth: 3,
                                      ),
                                    )
                                  : Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        const Icon(Icons.emergency_rounded, size: 28),
                                        const SizedBox(width: 10),
                                        Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'DISPATCH AMBULANCE • $_selectedCondition.toUpperCase()',
                                              style: const TextStyle(
                                                fontSize: 14.5,
                                                fontWeight: FontWeight.w900,
                                                letterSpacing: 1.2,
                                              ),
                                            ),
                                            Text(
                                              'Tap to confirm emergency dispatch',
                                              style: TextStyle(
                                                color: Colors.white.withValues(alpha: 0.85),
                                                fontSize: 10,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 10),

                    // Simple Safety Options Row
                    Row(
                      children: [
                        Expanded(
                          child: TextButton.icon(
                            style: TextButton.styleFrom(
                              foregroundColor: const Color(0xFF81D4FA),
                              padding: const EdgeInsets.symmetric(vertical: 8),
                            ),
                            onPressed: _shareLocationViaSms,
                            icon: const Icon(Icons.sms_rounded, size: 16),
                            label: const Text(
                              'Share GPS via SMS',
                              style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                        if (_fallbackTriggered) ...[
                          const SizedBox(width: 8),
                          Expanded(
                            child: TextButton.icon(
                              style: TextButton.styleFrom(
                                foregroundColor: Colors.amberAccent,
                                padding: const EdgeInsets.symmetric(vertical: 8),
                              ),
                              onPressed: () {
                                if (_fix != null) {
                                  _showOfflineFallbackSheet(
                                    _fix!,
                                    _IntakeData(
                                      condition: _selectedCondition,
                                      priority: _selectedPriority,
                                    ),
                                  );
                                }
                              },
                              icon: const Icon(Icons.offline_bolt_rounded, size: 16),
                              label: const Text(
                                'Offline SMS Link',
                                style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),

          // Submitting Overlay
          if (_submitting)
            Container(
              color: Colors.black.withValues(alpha: 0.75),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 22),
                  decoration: BoxDecoration(
                    color: const Color(0xFF07193F),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xFF00D4FF), width: 1.5),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      SizedBox(
                        width: 44,
                        height: 44,
                        child: CircularProgressIndicator(
                          strokeWidth: 3.5,
                          color: Color(0xFF00D4FF),
                        ),
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Dispatching Closest Unit...',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Broadcasting your GPS location to Solace EMS network',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 11.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _IntakeData {
  final String condition;
  final String ageBand;
  final String? contactPhone;
  final String? manualAddress;
  final String? notes;
  final int priority;

  const _IntakeData({
    required this.condition,
    this.ageBand = 'unknown',
    this.contactPhone,
    this.manualAddress,
    this.notes,
    this.priority = 2,
  });
}

class _EmergencyConfirmSheet extends StatefulWidget {
  final String? defaultPhone;
  final String? defaultAgeBand;
  final String? bloodGroup;
  final String? allergies;
  final String? conditions;
  final String initialCondition;
  final int initialPriority;
  final String currentAddress;
  final double latitude;
  final double longitude;

  const _EmergencyConfirmSheet({
    this.defaultPhone,
    this.defaultAgeBand,
    this.bloodGroup,
    this.allergies,
    this.conditions,
    required this.initialCondition,
    required this.initialPriority,
    required this.currentAddress,
    required this.latitude,
    required this.longitude,
  });

  @override
  State<_EmergencyConfirmSheet> createState() => _EmergencyConfirmSheetState();
}

class _EmergencyConfirmSheetState extends State<_EmergencyConfirmSheet> {
  late final TextEditingController _phoneController;
  final _addressController = TextEditingController();
  final _notesController = TextEditingController();
  late String _selectedCondition;
  late int _priority;

  static const List<Map<String, dynamic>> _quickConditions = [
    {'label': 'Cardiac', 'icon': Icons.favorite_rounded, 'color': Color(0xFFE53935)},
    {'label': 'Accident', 'icon': Icons.car_crash_rounded, 'color': Color(0xFFFB8C00)},
    {'label': 'Trauma', 'icon': Icons.healing_rounded, 'color': Color(0xFFD81B60)},
    {'label': 'Respiratory', 'icon': Icons.air_rounded, 'color': Color(0xFF00ACC1)},
    {'label': 'Stroke', 'icon': Icons.psychology_rounded, 'color': Color(0xFF8E24AA)},
    {'label': 'Allergy', 'icon': Icons.vaccines_rounded, 'color': Color(0xFFFFB300)},
    {'label': 'Obstetric', 'icon': Icons.pregnant_woman_rounded, 'color': Color(0xFFEC407A)},
    {'label': 'Other', 'icon': Icons.medical_services_rounded, 'color': Color(0xFF1E88E5)},
  ];

  @override
  void initState() {
    super.initState();
    _selectedCondition = widget.initialCondition;
    _priority = widget.initialPriority;
    _phoneController = TextEditingController(text: widget.defaultPhone ?? '');
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _addressController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _confirm() {
    HapticFeedback.heavyImpact();
    Navigator.of(context).pop(
      _IntakeData(
        condition: _selectedCondition,
        contactPhone: _phoneController.text.trim().isNotEmpty ? _phoneController.text.trim() : null,
        manualAddress: _addressController.text.trim().isNotEmpty ? _addressController.text.trim() : null,
        notes: _notesController.text.trim().isNotEmpty ? _notesController.text.trim() : null,
        priority: _priority,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF07193F),
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
        border: Border(
          top: BorderSide(color: Color(0xFF00D4FF), width: 1.5),
        ),
      ),
      padding: EdgeInsets.fromLTRB(20, 14, 20, 20 + bottomInset),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 4.5,
                decoration: BoxDecoration(
                  color: Colors.white30,
                  borderRadius: BorderRadius.circular(2.5),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.red.shade900.withValues(alpha: 0.5),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.emergency_rounded, color: Colors.redAccent, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'Confirm Ambulance Request',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.5,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      Text(
                        'Solace EMS unit will be directed to your exact coordinates',
                        style: TextStyle(color: Colors.white60, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Verified Address Summary
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF0D2559),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF1E3A8A)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.location_on_rounded, color: Color(0xFF00D4FF), size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      widget.currentAddress.isNotEmpty
                          ? widget.currentAddress
                          : 'GPS Coordinates: ${widget.latitude.toStringAsFixed(5)}, ${widget.longitude.toStringAsFixed(5)}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Emergency Condition Chips
            const Text(
              'EMERGENCY CONDITION',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 10,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.8,
              ),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: _quickConditions.map((c) {
                final label = c['label'] as String;
                final isSel = label == _selectedCondition;
                final color = c['color'] as Color;

                return ChoiceChip(
                  avatar: Icon(
                    c['icon'] as IconData,
                    size: 15,
                    color: isSel ? Colors.white : color,
                  ),
                  label: Text(label),
                  selected: isSel,
                  selectedColor: color,
                  backgroundColor: const Color(0xFF0D2559),
                  labelStyle: TextStyle(
                    color: isSel ? Colors.white : Colors.white70,
                    fontWeight: isSel ? FontWeight.bold : FontWeight.normal,
                    fontSize: 11,
                  ),
                  onSelected: (val) {
                    if (val) {
                      HapticFeedback.selectionClick();
                      setState(() => _selectedCondition = label);
                    }
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 12),

            // Entrance / Floor / Room #
            TextField(
              controller: _addressController,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF0D2559),
                labelText: 'Building, Floor, Flat # or Gate Code (Optional)',
                labelStyle: const TextStyle(color: Colors.white60, fontSize: 12),
                hintText: 'e.g. 3rd Floor, Flat 4B, Blue gate',
                hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
                prefixIcon: const Icon(Icons.door_front_door_outlined, color: Color(0xFF00D4FF), size: 18),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 10),

            // Callback Phone Number
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF0D2559),
                labelText: 'Callback Phone Number for Dispatcher',
                labelStyle: const TextStyle(color: Colors.white60, fontSize: 12),
                prefixIcon: const Icon(Icons.phone_outlined, color: Color(0xFF00D4FF), size: 18),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 10),

            // Additional Notes
            TextField(
              controller: _notesController,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              maxLines: 2,
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF0D2559),
                labelText: 'Patient symptoms / instructions (Optional)',
                labelStyle: const TextStyle(color: Colors.white60, fontSize: 12),
                hintText: 'e.g. Difficulty breathing, severe bleeding',
                hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
                prefixIcon: const Icon(Icons.notes_rounded, color: Color(0xFF00D4FF), size: 18),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),

            if (widget.bloodGroup != null || widget.allergies != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.red.shade900.withValues(alpha: 0.25),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.red.shade400.withValues(alpha: 0.5)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.shield_outlined, color: Colors.redAccent, size: 16),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Attached from Medical ID: Blood ${widget.bloodGroup ?? "N/A"}${widget.allergies != null ? " • Allergies: " + widget.allergies! : ""}',
                        style: const TextStyle(color: Colors.white70, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 18),

            // DISPATCH CONFIRMATION ACTION BUTTON
            SizedBox(
              height: 52,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: const BorderSide(color: Color(0xFFFF5252), width: 1.5),
                  ),
                ),
                onPressed: _confirm,
                icon: const Icon(Icons.emergency_rounded, size: 22),
                label: const Text(
                  'CONFIRM & DISPATCH AMBULANCE',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.1,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
