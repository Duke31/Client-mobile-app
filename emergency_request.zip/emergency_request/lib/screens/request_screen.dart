import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../maps/mapbox_geocoding.dart';
import '../maps/mapbox_map_view.dart';
import '../services/emergency_service.dart';
import '../services/emergency_sms_fallback.dart';
import '../config/env.dart';
import '../services/location_service.dart';
import 'profile_screen.dart';
import 'submitted_screen.dart';
import 'live_ambulance_tracking_screen.dart';

const LatLng kDefaultCenter = LatLng(6.5244, 3.3792);

class RequestScreen extends StatefulWidget {
  const RequestScreen({super.key});

  @override
  State<RequestScreen> createState() => _RequestScreenState();
}

class _RequestScreenState extends State<RequestScreen>
    with SingleTickerProviderStateMixin {
  final _location = const LocationService();
  final _geocoding = MapboxGeocoding();
  final _mapController = MapController();

  late final AnimationController _pulseController;
  late final Animation<double> _pulseScale;
  late final Animation<double> _pulseOpacity;

  bool _loadingLocation = true;
  bool _submitting = false;
  bool _fallbackTriggered = false;
  _IntakeData? _lastIntake;
  String? _error;
  LocationFix? _fix;
  String _address = '';

  // Active mission tracking state
  Map<String, dynamic>? _activeMission;
  Timer? _activeMissionTimer;

  // Selected quick category for instant dispatch priming
  String _selectedCategory = 'Cardiac';
  int _selectedPriority = 1;

  // Cached profile data for fast triage prefill
  String? _profileName;
  String? _profilePhone;
  String? _profileAgeBand;
  String? _profileBloodGroup;
  String? _profileAllergies;
  String? _profileConditions;

  static const List<Map<String, dynamic>> _quickCategories = [
    {
      'type': 'Cardiac',
      'label': 'Cardiac / Heart',
      'icon': Icons.favorite_rounded,
      'color': Color(0xFFE53935),
      'priority': 1,
      'hint': 'Severe chest pain, heart attack symptoms',
    },
    {
      'type': 'Respiratory',
      'label': 'Breathing / Lungs',
      'icon': Icons.air_rounded,
      'color': Color(0xFF00ACC1),
      'priority': 1,
      'hint': 'Choking, severe asthma, oxygen deprivation',
    },
    {
      'type': 'Trauma',
      'label': 'Trauma / Bleeding',
      'icon': Icons.healing_rounded,
      'color': Color(0xFFD81B60),
      'priority': 1,
      'hint': 'Severe laceration, deep wound, fracture',
    },
    {
      'type': 'Stroke',
      'label': 'Stroke / Neuro',
      'icon': Icons.psychology_rounded,
      'color': Color(0xFF8E24AA),
      'priority': 1,
      'hint': 'Facial droop, arm weakness, slurred speech',
    },
    {
      'type': 'Accident',
      'label': 'Road Crash / Fall',
      'icon': Icons.car_crash_rounded,
      'color': Color(0xFFFB8C00),
      'priority': 1,
      'hint': 'Vehicle collision, pedestrian hit, high fall',
    },
    {
      'type': 'Obstetric',
      'label': 'Maternity / Labor',
      'icon': Icons.pregnant_woman_rounded,
      'color': Color(0xFFEC407A),
      'priority': 2,
      'hint': 'Active labor, pregnancy crisis, bleeding',
    },
    {
      'type': 'Allergy',
      'label': 'Severe Anaphylaxis',
      'icon': Icons.vaccines_rounded,
      'color': Color(0xFFFFB300),
      'priority': 1,
      'hint': 'Throat swelling, allergic reaction, epi-pen needed',
    },
    {
      'type': 'Other',
      'label': 'General Emergency',
      'icon': Icons.medical_services_rounded,
      'color': Color(0xFF1E88E5),
      'priority': 2,
      'hint': 'Unresponsive patient, high fever, poisoning',
    },
  ];

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat();

    _pulseScale = Tween<double>(begin: 1.0, end: 1.45).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeOutQuad),
    );

    _pulseOpacity = Tween<double>(begin: 0.65, end: 0.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeOutQuad),
    );

    _loadLocation();
    _fetchProfileDefaults();
    _checkActiveMission();

    _activeMissionTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _checkActiveMission();
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _activeMissionTimer?.cancel();
    _geocoding.dispose();
    super.dispose();
  }

  Future<void> _checkActiveMission() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null || !mounted) return;
    try {
      final res = await Supabase.instance.client
          .from('emergency_requests')
          .select('id, status, emergency_type, patient_address, patient_lat, patient_lng, created_at, assigned_driver_id, drivers(full_name, phone_number, vehicle_label)')
          .eq('patient_id', uid)
          .not('status', 'in', '(completed,cancelled,failed)')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (mounted) {
        setState(() {
          _activeMission = res;
        });
      }
    } catch (_) {}
  }

  Future<void> _fetchProfileDefaults() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      final res = await Supabase.instance.client
          .from('profiles')
          .select('full_name, phone, age_band, blood_group, allergies, chronic_conditions')
          .eq('user_id', userId)
          .maybeSingle();
      if (res != null && mounted) {
        setState(() {
          _profileName = res['full_name']?.toString();
          _profilePhone = res['phone']?.toString();
          _profileAgeBand = res['age_band']?.toString();
          _profileBloodGroup = res['blood_group']?.toString();
          _profileAllergies = res['allergies']?.toString();
          _profileConditions = res['chronic_conditions']?.toString();
        });
      }
    } catch (_) {}
  }

  Future<void> _applyFix(LocationFix fix, {String? notice}) async {
    final address = await _geocoding.reverseGeocode(
      latitude: fix.latitude,
      longitude: fix.longitude,
    );
    if (!mounted) return;
    setState(() {
      _fix = fix;
      _address = address;
      _loadingLocation = false;
      _error = notice;
    });
    try {
      _mapController.move(LatLng(fix.latitude, fix.longitude), 16.5);
    } catch (_) {}
  }

  Future<void> _loadLocation() async {
    setState(() {
      _loadingLocation = true;
      _error = null;
    });
    try {
      final fix = await _location.current();
      String? notice;
      if (fix.fromCache) {
        notice = 'Using approximate location. Tap Refresh GPS for precision.';
      }
      await _applyFix(fix, notice: notice);
    } on LocationException catch (e) {
      if (!mounted) return;
      setState(() {
        _loadingLocation = false;
        _error = e.message;
        _fix = LocationFix(
          latitude: kDefaultCenter.latitude,
          longitude: kDefaultCenter.longitude,
          fromCache: true,
        );
      });
      await _applyFix(_fix!, notice: e.message);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loadingLocation = false;
        _error = 'Location acquisition error: $e';
        _fix = LocationFix(
          latitude: kDefaultCenter.latitude,
          longitude: kDefaultCenter.longitude,
          fromCache: true,
        );
      });
    }
  }

  Future<void> _onMapTap(TapPosition _, LatLng point) async {
    HapticFeedback.lightImpact();
    await _applyFix(
      LocationFix(latitude: point.latitude, longitude: point.longitude),
      notice: 'Pinned location manually on map.',
    );
  }

  Future<void> _callEmergencyHotline(String number) async {
    final uri = Uri.parse('tel:$number');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _shareLocationViaSms() async {
    if (_fix == null) return;
    final lat = _fix!.latitude.toStringAsFixed(5);
    final lng = _fix!.longitude.toStringAsFixed(5);
    final msg = Uri.encodeComponent(
      '🚨 EMERGENCY ALERT: I need immediate medical assistance. My exact GPS coordinates: $lat, $lng. Address: ${_address.isNotEmpty ? _address : "Coordinates only"}. Open on Map: https://maps.google.com/?q=$lat,$lng'
    );
    final uri = Uri.parse('sms:?body=$msg');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _showIntakeSheetAndSubmit({String? preselectedType, int? priority}) async {
    if (_fix == null || _submitting) return;

    HapticFeedback.heavyImpact();

    final intake = await showModalBottomSheet<_IntakeData>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _EmergencyIntakeSheet(
        defaultPhone: _profilePhone,
        defaultAgeBand: _profileAgeBand,
        bloodGroup: _profileBloodGroup,
        allergies: _profileAllergies,
        conditions: _profileConditions,
        initialType: preselectedType ?? _selectedCategory,
        initialPriority: priority ?? _selectedPriority,
        currentAddress: _address,
      ),
    );

    if (intake == null) return;
    await _executeEmergencyRequest(_fix!, intake);
  }

  Future<void> _executeEmergencyRequest(LocationFix fix, _IntakeData intake) async {
    setState(() => _submitting = true);
    final supabase = Supabase.instance.client;

    try {
      String? createdRequestId;
      final service = EmergencyService(
        supabase: supabase,
        geocoding: _geocoding,
      );

      final finalAddress = (intake.manualAddress != null && intake.manualAddress!.trim().isNotEmpty)
          ? intake.manualAddress!.trim()
          : (_address.isNotEmpty ? _address : 'GPS: ${fix.latitude}, ${fix.longitude}');

      final notesList = <String>[];
      if (intake.manualAddress != null && intake.manualAddress!.trim().isNotEmpty) {
        notesList.add('📍 Landmark: ${intake.manualAddress!.trim()}');
      }
      if (intake.notes != null && intake.notes!.trim().isNotEmpty) {
        notesList.add(intake.notes!.trim());
      }
      if (_profileBloodGroup != null && _profileBloodGroup != 'Unknown') {
        notesList.add('Blood: $_profileBloodGroup');
      }
      if (_profileAllergies != null && _profileAllergies!.trim().isNotEmpty) {
        notesList.add('Allergies: $_profileAllergies');
      }
      if (_profileConditions != null && _profileConditions!.trim().isNotEmpty) {
        notesList.add('Conditions: $_profileConditions');
      }

      final assembledNotes = notesList.isNotEmpty ? notesList.join(' | ') : '';

      final rpcResult = await service.createRequest(
        latitude: fix.latitude,
        longitude: fix.longitude,
        address: finalAddress,
        emergencyType: intake.emergencyType,
        ageBand: intake.ageBand,
        contactPhone: intake.contactPhone ?? '',
        notes: assembledNotes,
        priority: intake.priority,
      );

      if (rpcResult is Map && rpcResult['id'] != null) {
        createdRequestId = rpcResult['id'] as String;
      }

      if (!mounted) return;

      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => SubmittedScreen(
            requestId: createdRequestId,
            latitude: fix.latitude,
            longitude: fix.longitude,
            address: finalAddress,
          ),
        ),
      );
    } on EmergencyNetworkException catch (e) {
      if (!mounted) return;
      setState(() {
        _submitting = false;
        _fallbackTriggered = true;
        _lastIntake = intake;
        _error = e.message;
      });
      await _showOfflineFallbackSheet(fix, intake);
    } catch (e) {
      if (!mounted) return;
      final msg = e.toString();
      final looksNetwork = msg.contains('SocketException') ||
          msg.contains('Failed host lookup') ||
          msg.contains('Network') ||
          msg.contains('timed out') ||
          msg.contains('Timeout');
      setState(() {
        _submitting = false;
        if (looksNetwork) {
          _fallbackTriggered = true;
          _lastIntake = intake;
        }
        _error = 'Could not submit request: $e';
      });
      if (looksNetwork) {
        await _showOfflineFallbackSheet(fix, intake);
      }
    }
  }

  Future<void> _showOfflineFallbackSheet(
    LocationFix fix,
    _IntakeData intake,
  ) async {
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return Container(
          decoration: const BoxDecoration(
            color: Color(0xFF1E1E2C),
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Row(
                children: [
                  Icon(Icons.wifi_off_rounded, color: Colors.amber, size: 28),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Dispatch Server Offline',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Text(
                'Data connection failed. Switch to SMS dispatch immediately so our regional dispatch center receives your exact GPS coordinates.',
                style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.4),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF00D4FF),
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () async {
                  Navigator.pop(ctx);
                  final smsBody = EmergencySmsFallback.buildBody(
                    emergencyType: intake.emergencyType,
                    latitude: fix.latitude,
                    longitude: fix.longitude,
                    address: _address,
                    callerPhone: intake.contactPhone,
                  );
                  await EmergencySmsFallback.openNativeSms(
                    body: smsBody,
                  );
                },
                icon: const Icon(Icons.sms_outlined),
                label: const Text(
                  'Transmit Emergency Via SMS',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.redAccent,
                  side: const BorderSide(color: Colors.redAccent),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () {
                  Navigator.pop(ctx);
                  _callEmergencyHotline('911');
                },
                icon: const Icon(Icons.phone),
                label: const Text(
                  'Call Emergency Hotline (911)',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hasActiveMission = _activeMission != null;
    final accuracy = _fix?.accuracyMeters;

    return Scaffold(
      backgroundColor: const Color(0xFF061536),
      appBar: AppBar(
        backgroundColor: const Color(0xFF07193F),
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 12.0),
          child: Image.asset(
            'assets/images/solace_icon.png',
            height: 30,
            width: 30,
            errorBuilder: (_, __, ___) => const Icon(
              Icons.emergency_rounded,
              color: Color(0xFF00D4FF),
              size: 26,
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'SOLACE EMERGENCY',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 16,
                letterSpacing: 1.1,
              ),
            ),
            Row(
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: const BoxDecoration(
                    color: Color(0xFF00E676),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 5),
                const Text(
                  '24/7 Priority EMS Network Active',
                  style: TextStyle(
                    color: Color(0xFF81D4FA),
                    fontSize: 10.5,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          // Medical ID Quick Pill
          ActionChip(
            avatar: const Icon(
              Icons.medical_information_rounded,
              size: 16,
              color: Color(0xFF00D4FF),
            ),
            label: Text(
              _profileBloodGroup != null && _profileBloodGroup != 'Unknown'
                  ? '🩸 $_profileBloodGroup'
                  : 'Medical ID',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
            backgroundColor: const Color(0xFF0D2559),
            side: const BorderSide(color: Color(0xFF00D4FF), width: 0.8),
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const ProfileScreen()),
              );
              _fetchProfileDefaults();
            },
          ),
          const SizedBox(width: 6),
          // Direct 911 Hotline Shortcut
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.red.shade900.withValues(alpha: 0.4),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.redAccent, width: 1),
              ),
              child: const Icon(Icons.phone_in_talk, color: Colors.redAccent, size: 18),
            ),
            tooltip: 'Call Emergency (911)',
            onPressed: () => _callEmergencyHotline('911'),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              // 1. ACTIVE MISSION BANNER (If an ambulance is currently dispatched)
              if (hasActiveMission)
                InkWell(
                  onTap: () {
                    final reqId = _activeMission!['id'] as String;
                    final lat = (_activeMission!['patient_lat'] as num?)?.toDouble() ?? _fix?.latitude ?? kDefaultCenter.latitude;
                    final lng = (_activeMission!['patient_lng'] as num?)?.toDouble() ?? _fix?.longitude ?? kDefaultCenter.longitude;
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => LiveAmbulanceTrackingScreen(
                          requestId: reqId,
                          patientLocation: LatLng(lat, lng),
                          patientAddress: _activeMission!['patient_address'] as String?,
                        ),
                      ),
                    );
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.red.shade900,
                          const Color(0xFF07193F),
                        ],
                      ),
                      border: const Border(
                        bottom: BorderSide(color: Color(0xFFFF334B), width: 1.5),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.sensors_rounded, color: Color(0xFF00D4FF), size: 22),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '🚨 AMBULANCE EN ROUTE • ${_activeMission!['status']?.toString().toUpperCase()}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 0.8,
                                ),
                              ),
                              Text(
                                'Unit: ${_activeMission!['drivers']?['vehicle_label'] ?? 'Assigned Medic'} • Tap to Track Live',
                                style: const TextStyle(
                                  color: Color(0xFF80D8FF),
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white70, size: 14),
                      ],
                    ),
                  ),
                ),

              // 2. INTERACTIVE MAP SECTION
              Expanded(
                flex: 4,
                child: Stack(
                  children: [
                    MapboxMapView.patientLocation(
                      latitude: _fix?.latitude ?? kDefaultCenter.latitude,
                      longitude: _fix?.longitude ?? kDefaultCenter.longitude,
                      zoom: 16.5,
                      interactive: true,
                      mapController: _mapController,
                      onTap: _onMapTap,
                    ),

                    // Top Gradient Scrim for Contrast
                    Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      height: 50,
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.black.withValues(alpha: 0.4),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),

                    // Live GPS Precision Tag (Top Left)
                    Positioned(
                      top: 12,
                      left: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF07193F).withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: accuracy != null && accuracy <= 20
                                ? const Color(0xFF00E676)
                                : const Color(0xFF00D4FF),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.3),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              accuracy != null && accuracy <= 20
                                  ? Icons.my_location_rounded
                                  : Icons.gps_fixed_rounded,
                              size: 14,
                              color: accuracy != null && accuracy <= 20
                                  ? const Color(0xFF00E676)
                                  : const Color(0xFF00D4FF),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              accuracy != null
                                  ? 'GPS Lock: ±${accuracy.round()}m'
                                  : 'Acquiring GPS...',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Recenter GPS & Adjust Pin controls (Top Right)
                    Positioned(
                      top: 12,
                      right: 12,
                      child: Column(
                        children: [
                          FloatingActionButton.small(
                            heroTag: 'recenter_gps',
                            backgroundColor: const Color(0xFF07193F),
                            foregroundColor: const Color(0xFF00D4FF),
                            elevation: 4,
                            tooltip: 'Re-acquire Hardware GPS',
                            onPressed: _loadLocation,
                            child: _loadingLocation
                                ? const SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Color(0xFF00D4FF),
                                    ),
                                  )
                                : const Icon(Icons.near_me_rounded, size: 20),
                          ),
                        ],
                      ),
                    ),

                    // Bottom Floating Address Card over Map
                    Positioned(
                      bottom: 12,
                      left: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF07193F).withValues(alpha: 0.95),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFF1E3A8A), width: 1.2),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.4),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: const Color(0xFF00D4FF).withValues(alpha: 0.15),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.pin_drop_rounded,
                                color: Color(0xFF00D4FF),
                                size: 20,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Row(
                                    children: [
                                      const Text(
                                        'PICKUP LOCATION',
                                        style: TextStyle(
                                          color: Color(0xFF81D4FA),
                                          fontSize: 9.5,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 0.8,
                                        ),
                                      ),
                                      const Spacer(),
                                      const Text(
                                        'Tap map to fine-tune',
                                        style: TextStyle(
                                          color: Colors.white38,
                                          fontSize: 9.5,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    _address.isNotEmpty
                                        ? _address
                                        : 'Acquiring satellite street address...',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // 3. TACTICAL SOS COMMAND DECK
              Expanded(
                flex: 5,
                child: Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFF061536),
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                  ),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Category Header
                        Row(
                          children: [
                            const Text(
                              'SELECT EMERGENCY CONDITION',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.8,
                              ),
                            ),
                            const Spacer(),
                            Text(
                              'Selected: $_selectedCategory',
                              style: const TextStyle(
                                color: Color(0xFF00D4FF),
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),

                        // Interactive Emergency Category Grid (8 quick triage cards)
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 4,
                            childAspectRatio: 1.15,
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                          ),
                          itemCount: _quickCategories.length,
                          itemBuilder: (context, idx) {
                            final cat = _quickCategories[idx];
                            final isSelected = cat['type'] == _selectedCategory;
                            final color = cat['color'] as Color;

                            return InkWell(
                              borderRadius: BorderRadius.circular(12),
                              onTap: () {
                                HapticFeedback.selectionClick();
                                setState(() {
                                  _selectedCategory = cat['type'] as String;
                                  _selectedPriority = cat['priority'] as int;
                                });
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 200),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? color.withValues(alpha: 0.25)
                                      : const Color(0xFF0D2559).withValues(alpha: 0.6),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: isSelected ? color : Colors.white12,
                                    width: isSelected ? 2 : 1,
                                  ),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      cat['icon'] as IconData,
                                      color: isSelected ? color : Colors.white70,
                                      size: 24,
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      cat['type'] as String,
                                      style: TextStyle(
                                        color: isSelected ? Colors.white : Colors.white60,
                                        fontSize: 10,
                                        fontWeight: isSelected
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),

                        const SizedBox(height: 16),

                        // CENTRAL INTERACTIVE PULSING SOS BUTTON
                        Center(
                          child: SizedBox(
                            width: 200,
                            height: 120,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                // Animated Radar Pulse Rings
                                AnimatedBuilder(
                                  animation: _pulseController,
                                  builder: (context, child) {
                                    return Transform.scale(
                                      scale: _pulseScale.value,
                                      child: Container(
                                        width: 170,
                                        height: 80,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(40),
                                          color: const Color(0xFFFF334B).withValues(
                                            alpha: _pulseOpacity.value,
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),

                                // Main Tactical Dispatch Button
                                SizedBox(
                                  width: 180,
                                  height: 82,
                                  child: ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFFD32F2F),
                                      foregroundColor: Colors.white,
                                      elevation: 10,
                                      shadowColor: const Color(0xFFFF334B).withValues(alpha: 0.5),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(40),
                                        side: const BorderSide(
                                          color: Color(0xFFFF8A80),
                                          width: 2,
                                        ),
                                      ),
                                      padding: EdgeInsets.zero,
                                    ),
                                    onPressed: _submitting
                                        ? null
                                        : () => _showIntakeSheetAndSubmit(),
                                    child: _submitting
                                        ? const SizedBox(
                                            width: 28,
                                            height: 28,
                                            child: CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 3,
                                            ),
                                          )
                                        : Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: const [
                                                  Icon(Icons.emergency_rounded, size: 22),
                                                  SizedBox(width: 6),
                                                  Text(
                                                    'SOS DISPATCH',
                                                    style: TextStyle(
                                                      fontSize: 16,
                                                      fontWeight: FontWeight.w900,
                                                      letterSpacing: 1.5,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(height: 2),
                                              Text(
                                                'Tap to confirm ambulance dispatch',
                                                style: TextStyle(
                                                  color: Colors.white.withValues(alpha: 0.85),
                                                  fontSize: 9.5,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ],
                                          ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        // Emergency Safety Quick-Action Bar
                        Row(
                          children: [
                            // 1. Hotline Direct 911
                            Expanded(
                              child: OutlinedButton.icon(
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: const Color(0xFF0D2559).withValues(alpha: 0.5),
                                  side: const BorderSide(color: Colors.white12),
                                  padding: const EdgeInsets.symmetric(vertical: 10),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                onPressed: () => _callEmergencyHotline('911'),
                                icon: const Icon(Icons.phone, size: 14, color: Colors.redAccent),
                                label: const Text('Call 911', style: TextStyle(fontSize: 11)),
                              ),
                            ),
                            const SizedBox(width: 8),

                            // 2. Share Live Location via SMS
                            Expanded(
                              child: OutlinedButton.icon(
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: const Color(0xFF0D2559).withValues(alpha: 0.5),
                                  side: const BorderSide(color: Colors.white12),
                                  padding: const EdgeInsets.symmetric(vertical: 10),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                onPressed: _shareLocationViaSms,
                                icon: const Icon(Icons.share_location_rounded, size: 14, color: Color(0xFF00D4FF)),
                                label: const Text('Share GPS', style: TextStyle(fontSize: 11)),
                              ),
                            ),
                            const SizedBox(width: 8),

                            // 3. Offline SMS Fallback
                            Expanded(
                              child: OutlinedButton.icon(
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: const Color(0xFF0D2559).withValues(alpha: 0.5),
                                  side: const BorderSide(color: Colors.white12),
                                  padding: const EdgeInsets.symmetric(vertical: 10),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                onPressed: () {
                                  if (_fix != null) {
                                    _showOfflineFallbackSheet(
                                      _fix!,
                                      _IntakeData(
                                        emergencyType: _selectedCategory,
                                        priority: _selectedPriority,
                                      ),
                                    );
                                  }
                                },
                                icon: const Icon(Icons.sms_outlined, size: 14, color: Colors.amberAccent),
                                label: const Text('SMS Link', style: TextStyle(fontSize: 11)),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),

          // Submitting Overlay Shield
          if (_submitting)
            Container(
              color: Colors.black.withValues(alpha: 0.7),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                  decoration: BoxDecoration(
                    color: const Color(0xFF07193F),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xFF00D4FF), width: 1.5),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      SizedBox(
                        width: 44,
                        height: 44,
                        child: CircularProgressIndicator(
                          strokeWidth: 3.5,
                          color: Color(0xFF00D4FF),
                        ),
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Transmitting Emergency Priority...',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Directing closest EMS unit to your GPS position',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _IntakeData {
  final String emergencyType;
  final String ageBand;
  final String? contactPhone;
  final String? manualAddress;
  final String? notes;
  final int priority;

  const _IntakeData({
    required this.emergencyType,
    this.ageBand = 'unknown',
    this.contactPhone,
    this.manualAddress,
    this.notes,
    this.priority = 2,
  });
}

class _EmergencyIntakeSheet extends StatefulWidget {
  final String? defaultPhone;
  final String? defaultAgeBand;
  final String? bloodGroup;
  final String? allergies;
  final String? conditions;
  final String initialType;
  final int initialPriority;
  final String currentAddress;

  const _EmergencyIntakeSheet({
    this.defaultPhone,
    this.defaultAgeBand,
    this.bloodGroup,
    this.allergies,
    this.conditions,
    required this.initialType,
    required this.initialPriority,
    required this.currentAddress,
  });

  @override
  State<_EmergencyIntakeSheet> createState() => _EmergencyIntakeSheetState();
}

class _EmergencyIntakeSheetState extends State<_EmergencyIntakeSheet> {
  late final TextEditingController _phoneController;
  final _addressController = TextEditingController();
  final _notesController = TextEditingController();
  late String _selectedType;
  late int _priority;
  late String _selectedAgeBand;

  static const List<Map<String, dynamic>> _types = [
    {'label': 'Cardiac', 'icon': Icons.favorite_rounded, 'color': Color(0xFFE53935)},
    {'label': 'Respiratory', 'icon': Icons.air_rounded, 'color': Color(0xFF00ACC1)},
    {'label': 'Trauma', 'icon': Icons.healing_rounded, 'color': Color(0xFFD81B60)},
    {'label': 'Stroke', 'icon': Icons.psychology_rounded, 'color': Color(0xFF8E24AA)},
    {'label': 'Accident', 'icon': Icons.car_crash_rounded, 'color': Color(0xFFFB8C00)},
    {'label': 'Obstetric', 'icon': Icons.pregnant_woman_rounded, 'color': Color(0xFFEC407A)},
    {'label': 'Allergy', 'icon': Icons.vaccines_rounded, 'color': Color(0xFFFFB300)},
    {'label': 'Other', 'icon': Icons.medical_services_rounded, 'color': Color(0xFF1E88E5)},
  ];

  static const List<String> _ageBands = [
    'unknown',
    '0-1',
    '2-12',
    '13-17',
    '18-39',
    '40-64',
    '65+'
  ];

  @override
  void initState() {
    super.initState();
    _selectedType = widget.initialType;
    _priority = widget.initialPriority;
    _phoneController = TextEditingController(text: widget.defaultPhone ?? '');
    _selectedAgeBand = (widget.defaultAgeBand != null && _ageBands.contains(widget.defaultAgeBand))
        ? widget.defaultAgeBand!
        : '18-39';
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _addressController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _confirm() {
    HapticFeedback.heavyImpact();
    Navigator.of(context).pop(
      _IntakeData(
        emergencyType: _selectedType,
        ageBand: _selectedAgeBand,
        contactPhone: _phoneController.text.trim().isNotEmpty ? _phoneController.text.trim() : null,
        manualAddress: _addressController.text.trim().isNotEmpty ? _addressController.text.trim() : null,
        notes: _notesController.text.trim().isNotEmpty ? _notesController.text.trim() : null,
        priority: _priority,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF07193F),
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(
          top: BorderSide(color: Color(0xFF00D4FF), width: 1.5),
        ),
      ),
      padding: EdgeInsets.fromLTRB(20, 14, 20, 20 + bottomInset),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 4.5,
                decoration: BoxDecoration(
                  color: Colors.white30,
                  borderRadius: BorderRadius.circular(2.5),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Modal Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.red.shade900.withValues(alpha: 0.5),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.emergency_rounded, color: Colors.redAccent, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'Confirm Emergency Dispatch',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      Text(
                        'An ambulance will be dispatched to your location',
                        style: TextStyle(color: Colors.white60, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Verified GPS Address Card
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF0D2559),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFF1E3A8A)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.location_on_rounded, color: Color(0xFF00D4FF), size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'VERIFIED DISPATCH ADDRESS',
                          style: TextStyle(
                            color: Color(0xFF81D4FA),
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          widget.currentAddress.isNotEmpty
                              ? widget.currentAddress
                              : 'Precise GPS Pinpoint',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Emergency Type Selector
            const Text(
              'EMERGENCY TYPE',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 10,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.8,
              ),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: _types.map((t) {
                final label = t['label'] as String;
                final isSel = label == _selectedType;
                final color = t['color'] as Color;
                return ChoiceChip(
                  avatar: Icon(t['icon'] as IconData, size: 16, color: isSel ? Colors.white : color),
                  label: Text(label),
                  selected: isSel,
                  selectedColor: color,
                  backgroundColor: const Color(0xFF0D2559),
                  labelStyle: TextStyle(
                    color: isSel ? Colors.white : Colors.white70,
                    fontWeight: isSel ? FontWeight.bold : FontWeight.normal,
                    fontSize: 11,
                  ),
                  onSelected: (val) {
                    if (val) {
                      HapticFeedback.selectionClick();
                      setState(() => _selectedType = label);
                    }
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 14),

            // Entrance / Floor / Room #
            TextField(
              controller: _addressController,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF0D2559),
                labelText: 'Building, Floor, Apartment or Gate Code (Optional)',
                labelStyle: const TextStyle(color: Colors.white60, fontSize: 12),
                hintText: 'e.g. 3rd Floor, Flat 4B, Blue gate',
                hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
                prefixIcon: const Icon(Icons.door_front_door_outlined, color: Color(0xFF00D4FF), size: 18),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 10),

            // Contact Phone Number
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF0D2559),
                labelText: 'Callback Phone Number for Paramedics',
                labelStyle: const TextStyle(color: Colors.white60, fontSize: 12),
                prefixIcon: const Icon(Icons.phone_outlined, color: Color(0xFF00D4FF), size: 18),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 10),

            // Notes / Symptoms
            TextField(
              controller: _notesController,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              maxLines: 2,
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF0D2559),
                labelText: 'Patient condition / instructions (Optional)',
                labelStyle: const TextStyle(color: Colors.white60, fontSize: 12),
                hintText: 'e.g. Patient is conscious but having acute chest pressure',
                hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
                prefixIcon: const Icon(Icons.notes_rounded, color: Color(0xFF00D4FF), size: 18),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),

            if (widget.bloodGroup != null || widget.allergies != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.red.shade900.withValues(alpha: 0.25),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.red.shade400.withValues(alpha: 0.5)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.shield_outlined, color: Colors.redAccent, size: 16),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Attached from Medical ID: Blood ${widget.bloodGroup ?? "N/A"}${widget.allergies != null ? " • Allergies: " + widget.allergies! : ""}',
                        style: const TextStyle(color: Colors.white70, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 20),

            // DISPATCH CONFIRMATION ACTION BUTTON
            SizedBox(
              height: 54,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFD32F2F),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: const BorderSide(color: Color(0xFFFF5252), width: 1.5),
                  ),
                ),
                onPressed: _confirm,
                icon: const Icon(Icons.emergency_rounded, size: 22),
                label: const Text(
                  'CONFIRM & DISPATCH AMBULANCE',
                  style: TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.1,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
