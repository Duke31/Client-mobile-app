import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../maps/mapbox_geocoding.dart';
import '../maps/mapbox_map_view.dart';
import '../services/emergency_service.dart';
import '../services/location_service.dart';
import 'submitted_screen.dart';

class RequestScreen extends StatefulWidget {
  const RequestScreen({super.key});

  @override
  State<RequestScreen> createState() => _RequestScreenState();
}

class _RequestScreenState extends State<RequestScreen> {
  final _location = const LocationService();
  final _geocoding = MapboxGeocoding();

  bool _loadingLocation = true;
  bool _submitting = false;
  String? _error;
  LocationFix? _fix;
  String _address = '';

  @override
  void initState() {
    super.initState();
    _loadLocation();
  }

  @override
  void dispose() {
    _geocoding.dispose();
    super.dispose();
  }

  Future<void> _loadLocation() async {
    setState(() {
      _loadingLocation = true;
      _error = null;
    });
    try {
      final fix = await _location.current();
      final address = await _geocoding.reverseGeocode(
        latitude: fix.latitude,
        longitude: fix.longitude,
      );
      if (!mounted) return;
      setState(() {
        _fix = fix;
        _address = address;
        _loadingLocation = false;
      });
    } on LocationException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        _loadingLocation = false;
      });
    } on Object catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loadingLocation = false;
      });
    }
  }

  Future<void> _submit() async {
    final fix = _fix;
    if (fix == null || _submitting) return;

    setState(() => _submitting = true);
    try {
      final service = EmergencyService(
        supabase: Supabase.instance.client,
        geocoding: _geocoding,
      );
      await service.createRequest(
        latitude: fix.latitude,
        longitude: fix.longitude,
      );
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => SubmittedScreen(
            latitude: fix.latitude,
            longitude: fix.longitude,
            address: _address,
          ),
        ),
      );
    } on Object catch (e) {
      if (!mounted) return;
      setState(() {
        _submitting = false;
        _error = 'Could not submit request: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Confirm location')),
      body: Column(
        children: <Widget>[
          Expanded(child: _buildMap()),
          _buildSheet(context),
        ],
      ),
    );
  }

  Widget _buildMap() {
    final fix = _fix;
    if (_loadingLocation) {
      return const Center(child: CircularProgressIndicator());
    }
    if (fix == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(_error ?? 'Location unavailable'),
        ),
      );
    }
    return MapboxMapView.patientLocation(
      latitude: fix.latitude,
      longitude: fix.longitude,
    );
  }

  Widget _buildSheet(BuildContext context) {
    return Material(
      elevation: 8,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                'Dispatch address',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 6),
              Text(
                _address.isEmpty ? 'Resolving address…' : _address,
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              if (_error != null) ...<Widget>[
                const SizedBox(height: 8),
                Text(
                  _error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              ],
              const SizedBox(height: 16),
              Row(
                children: <Widget>[
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _loadingLocation ? null : _loadLocation,
                      child: const Text('Refresh GPS'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: FilledButton(
                      onPressed:
                          _fix == null || _submitting ? null : _submit,
                      child: _submitting
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text('Send emergency request'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
