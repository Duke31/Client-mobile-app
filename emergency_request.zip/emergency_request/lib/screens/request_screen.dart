import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../maps/mapbox_geocoding.dart';
import '../maps/mapbox_map_view.dart';
import '../services/emergency_service.dart';
import '../services/location_service.dart';
import 'profile_screen.dart';
import 'submitted_screen.dart';

const LatLng kDefaultCenter = LatLng(6.5244, 3.3792);

class RequestScreen extends StatefulWidget {
  const RequestScreen({super.key});

  @override
  State<RequestScreen> createState() => _RequestScreenState();
}

class _RequestScreenState extends State<RequestScreen> {
  final _location = const LocationService();
  final _geocoding = MapboxGeocoding();
  final _mapController = MapController();
  bool _loadingLocation = true;
  bool _submitting = false;
  String? _error;
  LocationFix? _fix;
  String _address = '';

  // Cached profile data for fast triage prefill
  String? _profilePhone;
  String? _profileAgeBand;
  String? _profileBloodGroup;
  String? _profileAllergies;
  String? _profileConditions;

  @override
  void initState() {
    super.initState();
    _loadLocation();
    _fetchProfileDefaults();
  }

  @override
  void dispose() {
    _geocoding.dispose();
    super.dispose();
  }

  Future<void> _fetchProfileDefaults() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      final res = await Supabase.instance.client
          .from('profiles')
          .select('phone, age_band, blood_group, allergies, chronic_conditions')
          .eq('user_id', userId)
          .maybeSingle();
      if (res != null && mounted) {
        setState(() {
          _profilePhone = res['phone']?.toString();
          _profileAgeBand = res['age_band']?.toString();
          _profileBloodGroup = res['blood_group']?.toString();
          _profileAllergies = res['allergies']?.toString();
          _profileConditions = res['chronic_conditions']?.toString();
        });
      }
    } catch (_) {}
  }

  Future<void> _applyFix(LocationFix fix, {String? notice}) async {
    final address = await _geocoding.reverseGeocode(
      latitude: fix.latitude,
      longitude: fix.longitude,
    );
    if (!mounted) return;
    setState(() {
      _fix = fix;
      _address = address;
      _loadingLocation = false;
      _error = notice;
    });
    try {
      _mapController.move(LatLng(fix.latitude, fix.longitude), 16.5);
    } catch (_) {}
  }

  Future<void> _loadLocation() async {
    setState(() {
      _loadingLocation = true;
      _error = null;
    });
    try {
      final fix = await _location.current();
      String? notice;
      if (fix.fromCache) {
        notice = 'Using approximate location. Tap Refresh GPS or type your room # below.';
      } else {
        notice = 'GPS coordinates locked';
      }
      await _applyFix(fix, notice: notice);
    } on LocationException catch (e) {
      if (!mounted) return;
      setState(() {
        _loadingLocation = false;
        _error = '${e.message} You can also type your landmark/room number below.';
        _fix ??= const LocationFix(
          latitude: 8.172858,
          longitude: 4.268245,
        );
        if (_address.isEmpty) {
          _address = 'Tap map or enter address in next step';
        }
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loadingLocation = false;
        _error = 'Location check failed. You can provide your building/room in the form.';
        _fix ??= const LocationFix(
          latitude: 8.172858,
          longitude: 4.268245,
        );
      });
    }
  }

  Future<void> _onMapTap(TapPosition _, LatLng point) async {
    await _applyFix(
      LocationFix(latitude: point.latitude, longitude: point.longitude),
      notice: 'Pinned location manually on map.',
    );
  }

  Future<void> _showIntakeSheetAndSubmit() async {
    if (_fix == null || _submitting) return;

    final intake = await showModalBottomSheet<_IntakeData>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _EmergencyIntakeSheet(
        defaultPhone: _profilePhone,
        defaultAgeBand: _profileAgeBand,
        bloodGroup: _profileBloodGroup,
      ),
    );

    if (intake == null) return;
    await _executeEmergencyRequest(_fix!, intake);
  }

  Future<void> _executeEmergencyRequest(LocationFix fix, _IntakeData intake) async {
    setState(() => _submitting = true);
    final supabase = Supabase.instance.client;

    try {
      String? createdRequestId;
      final service = EmergencyService(
        supabase: supabase,
        geocoding: _geocoding,
      );

      // Prioritize manual landmark / room # typed by the patient
      final finalAddress = (intake.manualAddress != null && intake.manualAddress!.trim().isNotEmpty)
          ? intake.manualAddress!.trim()
          : (_address.isNotEmpty ? _address : 'GPS: ${fix.latitude}, ${fix.longitude}');

      // Assemble medical and directions notes for driver & dispatch
      final notesList = <String>[];
      if (intake.manualAddress != null && intake.manualAddress!.trim().isNotEmpty) {
        notesList.add('📍 Landmark: ${intake.manualAddress!.trim()}');
      }
      if (intake.notes != null && intake.notes!.trim().isNotEmpty) {
        notesList.add(intake.notes!.trim());
      }
      if (_profileBloodGroup != null && _profileBloodGroup != 'Unknown') {
        notesList.add('Blood: $_profileBloodGroup');
      }
      if (_profileAllergies != null && _profileAllergies!.trim().isNotEmpty) {
        notesList.add('Allergies: $_profileAllergies');
      }
      if (_profileConditions != null && _profileConditions!.trim().isNotEmpty) {
        notesList.add('Conditions: $_profileConditions');
      }

      final assembledNotes = notesList.isNotEmpty ? notesList.join(' | ') : '';

      final rpcResult = await service.createRequest(
        latitude: fix.latitude,
        longitude: fix.longitude,
        address: finalAddress,
        emergencyType: intake.emergencyType,
        ageBand: intake.ageBand,
        contactPhone: intake.contactPhone ?? '',
        notes: assembledNotes,
        priority: 2,
      );

      if (rpcResult is Map && rpcResult['id'] != null) {
        createdRequestId = rpcResult['id'] as String;
      }

      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => SubmittedScreen(
            requestId: createdRequestId,
            latitude: fix.latitude,
            longitude: fix.longitude,
            address: finalAddress,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _submitting = false;
        _error = 'Could not submit request: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Confirm location'),
        actions: [
          IconButton(
            icon: const Icon(Icons.medical_information_outlined),
            tooltip: 'Medical ID',
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const ProfileScreen()),
              );
              _fetchProfileDefaults();
            },
          ),
        ],
      ),
      body: Stack(
        children: <Widget>[
          MapboxMapView.patientLocation(
            latitude: _fix?.latitude ?? kDefaultCenter.latitude,
            longitude: _fix?.longitude ?? kDefaultCenter.longitude,
            zoom: 16.5,
            interactive: true,
            mapController: _mapController,
            onTap: _onMapTap,
          ),
          if (_loadingLocation)
            Container(
              color: Colors.black.withValues(alpha: 0.25),
              child: const Center(
                child: Card(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2.5),
                        ),
                        SizedBox(width: 14),
                        Text('Finding GPS fix...'),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: Material(
        elevation: 8,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text('Dispatch address', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 6),
                Text(_address.isEmpty ? 'Tap map or enter building/room in next step' : _address),
                if (_error != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    _error!,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: _error!.contains('locked')
                          ? Colors.green.shade700
                          : Theme.of(context).colorScheme.error,
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _loadingLocation ? null : _loadLocation,
                        child: const Text('Refresh GPS'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 2,
                      child: FilledButton(
                        onPressed: _fix == null || _submitting ? null : _showIntakeSheetAndSubmit,
                        child: _submitting
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Text('Send emergency request'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _IntakeData {
  final String emergencyType;
  final String ageBand;
  final String? contactPhone;
  final String? manualAddress;
  final String? notes;

  _IntakeData({
    required this.emergencyType,
    required this.ageBand,
    this.contactPhone,
    this.manualAddress,
    this.notes,
  });
}

class _EmergencyIntakeSheet extends StatefulWidget {
  final String? defaultPhone;
  final String? defaultAgeBand;
  final String? bloodGroup;

  const _EmergencyIntakeSheet({
    this.defaultPhone,
    this.defaultAgeBand,
    this.bloodGroup,
  });

  @override
  State<_EmergencyIntakeSheet> createState() => _EmergencyIntakeSheetState();
}

class _EmergencyIntakeSheetState extends State<_EmergencyIntakeSheet> {
  late final TextEditingController _phoneController;
  final _addressController = TextEditingController();
  final _notesController = TextEditingController();

  String _selectedType = 'Trauma';
  late String _selectedAgeBand;

  static const List<Map<String, dynamic>> _types = [
    {'label': 'Trauma', 'icon': Icons.healing_outlined},
    {'label': 'Obstetric', 'icon': Icons.pregnant_woman_outlined},
    {'label': 'Cardiac', 'icon': Icons.favorite_border_rounded},
    {'label': 'Respiratory', 'icon': Icons.air_rounded},
    {'label': 'Pediatric', 'icon': Icons.child_care_outlined},
    {'label': 'Stroke', 'icon': Icons.psychology_outlined},
    {'label': 'Other', 'icon': Icons.medical_services_outlined},
  ];

  static const List<String> _ageBands = [
    'unknown',
    '0-1',
    '2-12',
    '13-17',
    '18-39',
    '40-64',
    '65+'
  ];

  @override
  void initState() {
    super.initState();
    _phoneController = TextEditingController(text: widget.defaultPhone ?? '');
    _selectedAgeBand = (widget.defaultAgeBand != null && _ageBands.contains(widget.defaultAgeBand))
        ? widget.defaultAgeBand!
        : '18-39';
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _addressController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _confirm() {
    Navigator.of(context).pop(
      _IntakeData(
        emergencyType: _selectedType,
        ageBand: _selectedAgeBand,
        contactPhone: _phoneController.text.trim().isNotEmpty ? _phoneController.text.trim() : null,
        manualAddress: _addressController.text.trim().isNotEmpty ? _addressController.text.trim() : null,
        notes: _notesController.text.trim().isNotEmpty ? _notesController.text.trim() : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.fromLTRB(20, 12, 20, 20 + bottomInset),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 14),
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.emergency_outlined, color: Colors.red.shade700, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Emergency Details',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        widget.bloodGroup != null && widget.bloodGroup != 'Unknown'
                            ? 'Medical ID: Blood Group ${widget.bloodGroup} attached'
                            : 'Helps match the nearest equipped hospital',
                        style: TextStyle(
                          fontSize: 12,
                          color: widget.bloodGroup != null && widget.bloodGroup != 'Unknown'
                              ? Colors.red.shade700
                              : Colors.grey,
                          fontWeight: widget.bloodGroup != null && widget.bloodGroup != 'Unknown'
                              ? FontWeight.w600
                              : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text(
              'EMERGENCY TYPE',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.8, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _types.map((t) {
                final isSelected = _selectedType == t['label'];
                return ChoiceChip(
                  avatar: Icon(
                    t['icon'] as IconData,
                    size: 16,
                    color: isSelected ? Colors.white : Colors.red.shade700,
                  ),
                  label: Text(t['label'] as String),
                  selected: isSelected,
                  selectedColor: Colors.red.shade700,
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.white : Colors.black87,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    fontSize: 13,
                  ),
                  backgroundColor: Colors.grey.shade100,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(
                      color: isSelected ? Colors.red.shade700 : Colors.grey.shade300,
                    ),
                  ),
                  onSelected: (selected) {
                    if (selected) setState(() => _selectedType = t['label'] as String);
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            const Text(
              'PATIENT AGE GROUP',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.8, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: _ageBands.map((band) {
                  final isSelected = _selectedAgeBand == band;
                  return Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: ChoiceChip(
                      label: Text(band == 'unknown' ? 'Unknown' : '$band yrs'),
                      selected: isSelected,
                      selectedColor: Colors.black87,
                      labelStyle: TextStyle(
                        color: isSelected ? Colors.white : Colors.black87,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                        fontSize: 12,
                      ),
                      backgroundColor: Colors.grey.shade100,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      onSelected: (selected) {
                        if (selected) setState(() => _selectedAgeBand = band);
                      },
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'CALLER / PATIENT PHONE NUMBER',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.8, color: Colors.grey),
            ),
            const SizedBox(height: 6),
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[\d\+\-\s]'))],
              decoration: InputDecoration(
                hintText: 'e.g. 08012345678',
                prefixIcon: const Icon(Icons.phone_outlined, size: 18),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                filled: true,
                fillColor: Colors.grey.shade50,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'HOSTEL / LANDMARK / ROOM # (CRITICAL FOR DRIVER)',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.8, color: Colors.redAccent),
            ),
            const SizedBox(height: 6),
            TextField(
              controller: _addressController,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                hintText: 'e.g. Ibidunni Hostel, Adenike Way, Room 4',
                helperText: 'Directs the ambulance driver straight to your door',
                helperStyle: TextStyle(color: Colors.grey.shade600, fontSize: 11),
                prefixIcon: const Icon(Icons.home_work_outlined, size: 18, color: Colors.redAccent),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                filled: true,
                fillColor: Colors.red.shade50.withValues(alpha: 0.3),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.red.shade200),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.red.shade200),
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'CLINICAL NOTES',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.8, color: Colors.grey),
            ),
            const SizedBox(height: 6),
            TextField(
              controller: _notesController,
              maxLines: 2,
              decoration: InputDecoration(
                hintText: 'Additional details (e.g. unconscious, severe bleeding)',
                prefixIcon: const Icon(Icons.note_alt_outlined, size: 18),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                filled: true,
                fillColor: Colors.grey.shade50,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
              ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: Colors.red.shade700,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: _confirm,
              icon: const Icon(Icons.send_rounded),
              label: const Text(
                'Confirm & Dispatch Emergency',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}