Future<void> _submit() async {
  ...
  await service.createRequest(latitude: fix.latitude, longitude: fix.longitude);
  ...
  Navigator.of(context).pushReplacement(
    MaterialPageRoute<void>(
      builder: (_) => SubmittedScreen(
        latitude: fix.latitude,
        longitude: fix.longitude,
        address: _address,
      ),
    ),
  );
}