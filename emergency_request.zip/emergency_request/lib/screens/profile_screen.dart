import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'auth_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _supabase = Supabase.instance.client;
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _allergiesController = TextEditingController();
  final _conditionsController = TextEditingController();
  final _kinNameController = TextEditingController();
  final _kinPhoneController = TextEditingController();

  String _selectedBloodGroup = 'Unknown';
  String _selectedAgeBand = '18-39';
  bool _isLoading = true;
  bool _isSaving = false;
  String _currentRole = 'client';

  static const List<String> _bloodGroups = [
    'Unknown',
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    'O+',
    'O-',
  ];

  static const List<String> _ageBands = [
    '0-1',
    '2-12',
    '13-17',
    '18-39',
    '40-64',
    '65+',
  ];

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _allergiesController.dispose();
    _conditionsController.dispose();
    _kinNameController.dispose();
    _kinPhoneController.dispose();
    super.dispose();
  }

  Future<void> _loadProfile() async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) {
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    try {
      final res = await _supabase
          .from('profiles')
          .select('*')
          .eq('user_id', userId)
          .maybeSingle();

      if (res != null && mounted) {
        setState(() {
          _currentRole = res['role']?.toString() ?? 'client';

          _nameController.text = res['display_name']?.toString() ??
                                 res['full_name']?.toString() ??
                                 res['name']?.toString() ??
                                 '';
          _phoneController.text = res['phone']?.toString() ??
                                  res['phone_number']?.toString() ??
                                  '';
          _allergiesController.text = res['allergies']?.toString() ?? '';
          _conditionsController.text = res['chronic_conditions']?.toString() ?? '';
          _kinNameController.text = res['next_of_kin_name']?.toString() ?? '';
          _kinPhoneController.text = res['next_of_kin_phone']?.toString() ?? '';

          final bg = res['blood_group']?.toString();
          if (bg != null && _bloodGroups.contains(bg)) {
            _selectedBloodGroup = bg;
          }

          final ab = res['age_band']?.toString();
          if (ab != null && _ageBands.contains(ab)) {
            _selectedAgeBand = ab;
          }
        });
      }
    } catch (e) {
      debugPrint('Error loading profile: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _saveProfile() async {
    if (!_formKey.currentState!.validate()) return;

    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return;

    setState(() => _isSaving = true);

    try {
      final name = _nameController.text.trim();
      final phone = _phoneController.text.trim();

      // Satisfies display_name NOT NULL constraint and preserves user role
      final payload = <String, dynamic>{
        'user_id': userId,
        'role': _currentRole,
        'display_name': name,
        'full_name': name,
        'phone': phone.isNotEmpty ? phone : null,
        'blood_group': _selectedBloodGroup != 'Unknown' ? _selectedBloodGroup : null,
        'age_band': _selectedAgeBand,
        'allergies': _allergiesController.text.trim().isNotEmpty ? _allergiesController.text.trim() : null,
        'chronic_conditions': _conditionsController.text.trim().isNotEmpty ? _conditionsController.text.trim() : null,
        'next_of_kin_name': _kinNameController.text.trim().isNotEmpty ? _kinNameController.text.trim() : null,
        'next_of_kin_phone': _kinPhoneController.text.trim().isNotEmpty ? _kinPhoneController.text.trim() : null,
      };

      await _supabase.from('profiles').upsert(payload, onConflict: 'user_id');

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Medical ID saved successfully!'),
          backgroundColor: Colors.teal,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to save Medical ID: $e'),
          backgroundColor: Colors.red.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Future<void> _signOut() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Sign Out'),
        content: const Text('Are you sure you want to sign out of your emergency portal?'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await _supabase.auth.signOut();
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute<void>(builder: (_) => const AuthScreen()),
        (route) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final userEmail = _supabase.auth.currentUser?.email ?? 'Client';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Emergency Medical ID'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout_rounded),
            tooltip: 'Sign Out',
            onPressed: _signOut,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.red.shade50,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.red.shade200),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.red.shade100,
                                shape: BoxShape.circle,
                              ),
                              child: Icon(Icons.health_and_safety_rounded, color: Colors.red.shade800, size: 28),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    userEmail,
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                  const SizedBox(height: 2),
                                  const Text(
                                    'This data will be auto-attached to emergency dispatches to inform doctors and paramedics.',
                                    style: TextStyle(fontSize: 12, color: Colors.black54),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      const Text(
                        'PERSONAL & CONTACT',
                        style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.8, color: Colors.grey),
                      ),
                      const SizedBox(height: 8),

                      TextFormField(
                        controller: _nameController,
                        decoration: InputDecoration(
                          labelText: 'Full Name',
                          prefixIcon: const Icon(Icons.person_outline),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'Name is required' : null,
                      ),
                      const SizedBox(height: 12),

                      TextFormField(
                        controller: _phoneController,
                        keyboardType: TextInputType.phone,
                        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[\d\+\-\s]'))],
                        decoration: InputDecoration(
                          labelText: 'Emergency Contact Phone',
                          prefixIcon: const Icon(Icons.phone_outlined),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'Phone number is required' : null,
                      ),

                      const SizedBox(height: 24),

                      const Text(
                        'CLINICAL PROFILE',
                        style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.8, color: Colors.grey),
                      ),
                      const SizedBox(height: 8),

                      Row(
                        children: [
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: _selectedBloodGroup,
                              decoration: InputDecoration(
                                labelText: 'Blood Group',
                                prefixIcon: const Icon(Icons.bloodtype_outlined, color: Colors.red),
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                              ),
                              items: _bloodGroups.map((bg) {
                                return DropdownMenuItem(value: bg, child: Text(bg));
                              }).toList(),
                              onChanged: (val) {
                                if (val != null) setState(() => _selectedBloodGroup = val);
                              },
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: _selectedAgeBand,
                              decoration: InputDecoration(
                                labelText: 'Age Group',
                                prefixIcon: const Icon(Icons.calendar_today_outlined),
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                              ),
                              items: _ageBands.map((ab) {
                                return DropdownMenuItem(value: ab, child: Text('$ab yrs'));
                              }).toList(),
                              onChanged: (val) {
                                if (val != null) setState(() => _selectedAgeBand = val);
                              },
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 14),

                      TextFormField(
                        controller: _allergiesController,
                        decoration: InputDecoration(
                          labelText: 'Known Allergies (Optional)',
                          hintText: 'e.g. Penicillin, Peanuts, Latex',
                          prefixIcon: const Icon(Icons.warning_amber_rounded),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                      ),

                      const SizedBox(height: 14),

                      TextFormField(
                        controller: _conditionsController,
                        decoration: InputDecoration(
                          labelText: 'Chronic Conditions (Optional)',
                          hintText: 'e.g. Asthma, Hypertension, Diabetes',
                          prefixIcon: const Icon(Icons.medical_information_outlined),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                      ),

                      const SizedBox(height: 24),

                      const Text(
                        'EMERGENCY NEXT OF KIN',
                        style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 0.8, color: Colors.grey),
                      ),
                      const SizedBox(height: 8),

                      TextFormField(
                        controller: _kinNameController,
                        decoration: InputDecoration(
                          labelText: 'Next of Kin Name',
                          hintText: 'e.g. Jane Doe (Spouse)',
                          prefixIcon: const Icon(Icons.people_outline),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                      ),
                      const SizedBox(height: 12),

                      TextFormField(
                        controller: _kinPhoneController,
                        keyboardType: TextInputType.phone,
                        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[\d\+\-\s]'))],
                        decoration: InputDecoration(
                          labelText: 'Next of Kin Phone',
                          prefixIcon: const Icon(Icons.phone_in_talk_outlined),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                      ),

                      const SizedBox(height: 28),

                      FilledButton.icon(
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          backgroundColor: Colors.red.shade700,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: _isSaving ? null : _saveProfile,
                        icon: _isSaving
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : const Icon(Icons.check_circle_outline),
                        label: Text(
                          _isSaving ? 'Saving...' : 'Save Medical ID',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}