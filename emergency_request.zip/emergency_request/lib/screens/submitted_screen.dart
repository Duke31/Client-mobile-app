import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'request_screen.dart';

class SubmittedScreen extends StatefulWidget {
  final String? requestId;
  final double? latitude;
  final double? longitude;
  final String? address;
  final String? patientAddress;

  const SubmittedScreen({
    super.key,
    this.requestId,
    this.latitude,
    this.longitude,
    this.address,
    this.patientAddress,
  });

  @override
  State<SubmittedScreen> createState() => _SubmittedScreenState();
}

class _SubmittedScreenState extends State<SubmittedScreen> {
  final SupabaseClient _supabase = Supabase.instance.client;

  String? _requestId;
  bool _isCancelling = false;
  String _currentStatus = 'Requested';

  String? _hospitalName;
  String? _hospitalAddress;
  String? _driverName;
  String? _vehicleLabel;
  String? _driverPhone;

  Timer? _pollTimer;
  Timer? _autoCloseTimer;
  StreamSubscription<List<Map<String, dynamic>>>? _realtimeSub;

  String? get _resolvedAddress => widget.address ?? widget.patientAddress;

  bool get _isCompleted {
    final s = _currentStatus.toLowerCase();
    return s.contains('complete');
  }

  bool get _isCancelled {
    final s = _currentStatus.toLowerCase();
    return s.contains('cancel') || s.contains('fail');
  }

  bool get _canClientCancel {
    final s = _currentStatus.toLowerCase();
    return s == 'requested' || s == 'matching';
  }

  @override
  void initState() {
    super.initState();
    _requestId = widget.requestId;

    if (_requestId != null && _requestId!.isNotEmpty) {
      _startStatusMonitoring(_requestId!);
    } else {
      _fetchActiveRequestId();
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _autoCloseTimer?.cancel();
    _realtimeSub?.cancel();
    super.dispose();
  }

  void _stopMonitoring() {
    _pollTimer?.cancel();
    _pollTimer = null;
    _realtimeSub?.cancel();
    _realtimeSub = null;
  }

  void _startStatusMonitoring(String reqId) {
    _refreshStatus(reqId);

    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _refreshStatus(reqId);
    });

    _realtimeSub?.cancel();
    try {
      _realtimeSub = _supabase
          .from('emergency_requests')
          .stream(primaryKey: ['id'])
          .eq('id', reqId)
          .listen((data) {
            if (data.isNotEmpty && mounted) {
              final newStatus = data.first['status']?.toString();
              if (newStatus != null && newStatus != _currentStatus) {
                _handleStatusChange(newStatus);
              }
              _refreshStatus(reqId);
            }
          }, onError: (_) {});
    } catch (_) {}
  }

  void _handleStatusChange(String newStatus) {
    setState(() {
      _currentStatus = newStatus;
    });

    if (_isCompleted || _isCancelled) {
      _stopMonitoring();

      if (_isCompleted) {
        _autoCloseTimer?.cancel();
        _autoCloseTimer = Timer(const Duration(seconds: 4), () {
          if (mounted) {
            _returnHome();
          }
        });
      }
    }
  }

  Future<void> _refreshStatus(String reqId) async {
    try {
      final req = await _supabase
          .from('emergency_requests')
          .select('id, status, hospital_id, driver_id, contact_phone')
          .eq('id', reqId)
          .maybeSingle();

      if (req == null || !mounted) return;

      final newStatus = req['status']?.toString();
      if (newStatus != null && newStatus != _currentStatus) {
        _handleStatusChange(newStatus);
      }

      final hospitalId = req['hospital_id']?.toString();
      final driverId = req['driver_id']?.toString();

      String? hName = _hospitalName;
      String? hAddr = _hospitalAddress;
      String? dName = _driverName;
      String? vLabel = _vehicleLabel;
      String? dPhone = _driverPhone;

      // Hospital lookup
      if (hospitalId != null && hospitalId.isNotEmpty && (hName == null || hAddr == null)) {
        try {
          final hRes = await _supabase
              .from('hospitals')
              .select('*')
              .eq('id', hospitalId)
              .maybeSingle();
          if (hRes != null) {
            hName = hRes['name']?.toString() ?? hRes['hospital_name']?.toString();
            hAddr = hRes['address']?.toString() ?? hRes['location']?.toString();
          }
        } catch (e) {
          debugPrint('Error loading hospital: $e');
        }
      }

      // Driver lookup
      if (driverId != null && driverId.isNotEmpty && (dName == null || vLabel == null || dPhone == null)) {
        try {
          final dRes = await _supabase
              .from('drivers')
              .select('*')
              .eq('id', driverId)
              .maybeSingle();

          if (dRes != null) {
            dName = dRes['display_name']?.toString() ??
                    dRes['full_name']?.toString() ??
                    dRes['name']?.toString() ??
                    'Assigned Responder';

            vLabel = dRes['vehicle_label']?.toString() ??
                     dRes['vehicle_plate']?.toString() ??
                     dRes['plate_number']?.toString() ??
                     dRes['vehicle_info']?.toString() ??
                     dRes['call_sign']?.toString();

            dPhone = dRes['phone']?.toString() ??
                     dRes['phone_number']?.toString() ??
                     dRes['mobile']?.toString() ??
                     dRes['contact_phone']?.toString();
          }
        } catch (e) {
          debugPrint('Error loading driver: $e');
        }
      }

      if (mounted) {
        setState(() {
          _hospitalName = hName;
          _hospitalAddress = hAddr;
          _driverName = dName;
          _vehicleLabel = vLabel;
          _driverPhone = dPhone;
        });
      }
    } catch (e) {
      debugPrint('Status poll error: $e');
    }
  }

  Future<void> _fetchActiveRequestId() async {
    try {
      final res = await _supabase
          .from('emergency_requests')
          .select('id, status')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (res != null && mounted) {
        final id = res['id']?.toString();
        setState(() {
          _requestId = id;
          if (res['status'] != null) {
            _currentStatus = res['status'].toString();
          }
        });
        if (id != null) {
          _startStatusMonitoring(id);
        }
      }
    } catch (e) {
      debugPrint('Error finding active ticket: $e');
    }
  }

  Future<void> _confirmAndCancelRequest() async {
    if (!_canClientCancel) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('A vehicle or hospital has already been assigned. Please contact dispatch to cancel.'),
          backgroundColor: Colors.amber,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final bool? shouldCancel = await showDialog<bool>(
      context: context,
      barrierDismissible: !_isCancelling,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
              SizedBox(width: 8),
              Text('Cancel Request?'),
            ],
          ),
          content: const Text(
            'Are you sure you want to cancel this emergency request? '
            'This will stop hospital notification and dispatch coordination.',
            style: TextStyle(fontSize: 14, height: 1.4),
          ),
          actionsPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Keep Active'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                foregroundColor: Colors.white,
              ),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Yes, Cancel Request'),
            ),
          ],
        );
      },
    );

    if (shouldCancel == true && mounted) {
      await _executeCancelRpc();
    }
  }

  Future<void> _executeCancelRpc() async {
    final idToCancel = _requestId;
    if (idToCancel == null || idToCancel.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Cannot locate request ticket.'),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() => _isCancelling = true);

    try {
      // Matches: request_id uuid, new_state emergency_status, actor_role text
      await _supabase.rpc('transition_emergency_state', params: {
        'request_id': idToCancel,
        'new_state': 'Cancelled / failed',
        'actor_role': 'client',
      });

      if (!mounted) return;
      _returnHome();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Emergency request has been cancelled.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } on PostgrestException catch (e) {
      if (!mounted) return;
      setState(() => _isCancelling = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cancel failed: ${e.message}'),
          backgroundColor: Colors.red.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isCancelling = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _returnHome() {
    _autoCloseTimer?.cancel();
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const RequestScreen()),
      (route) => false,
    );
  }

  String get _headlineText {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return 'Request Cancelled';
    if (s.contains('complete')) return 'Emergency Handled';
    if (s.contains('arrived') || s.contains('intake')) return 'Arrived at Hospital';
    if (s.contains('patient picked')) return 'Patient Picked Up';
    if (s.contains('driver') || s.contains('assign')) return 'Driver Dispatched';
    if (s.contains('en route')) return 'Responder En Route';
    if (s.contains('hospital') || s.contains('confirm')) return 'Hospital Confirmed';
    return 'Help is being notified';
  }

  String get _descriptionText {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return 'This request was cancelled.';
    if (s.contains('complete')) return 'The emergency cycle has concluded safely. Returning to home...';
    if (s.contains('arrived') || s.contains('intake')) return 'Patient has arrived at hospital intake.';
    if (s.contains('patient picked')) return 'Patient is safely on board, navigating to confirmed hospital.';
    if (s.contains('en route')) return 'The assigned emergency transport is navigating to your location.';
    if (s.contains('driver') || s.contains('assign')) return 'A responder has been assigned and dispatched to your GPS coordinates.';
    if (s.contains('hospital') || s.contains('confirm')) return 'A partner hospital has confirmed bed capacity and is awaiting arrival.';
    return 'Your dispatch request is being broadcast to nearby verified hospitals and response teams.';
  }

  IconData get _statusIcon {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return Icons.cancel_outlined;
    if (s.contains('complete')) return Icons.check_circle_outline;
    if (s.contains('arrived')) return Icons.domain_verification_outlined;
    if (s.contains('driver') || s.contains('route') || s.contains('patient')) return Icons.directions_car_outlined;
    if (s.contains('hospital')) return Icons.local_hospital_outlined;
    return Icons.notifications_active_outlined;
  }

  Color get _statusColor {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return Colors.red;
    if (s.contains('complete')) return Colors.green;
    if (s.contains('hospital') || s.contains('driver') || s.contains('route') || s.contains('arrived')) {
      return Colors.teal;
    }
    return Colors.amber;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final displayId = _requestId;
    final shortId = (displayId != null && displayId.length > 8)
        ? displayId.substring(0, 8).toUpperCase()
        : (displayId?.toUpperCase() ?? 'Connecting...');

    final color = _statusColor;
    final isTerminal = _isCompleted || _isCancelled;

    return WillPopScope(
      onWillPop: () async {
        if (isTerminal) {
          _returnHome();
          return false;
        }

        final confirmExit = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Leave Screen?'),
            content: const Text(
              'Your request is active. Leaving this screen will not cancel dispatch coordination.',
            ),
            actions: [
              TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Stay')),
              TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Leave')),
            ],
          ),
        );
        if (confirmExit == true) {
          _returnHome();
        }
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Emergency Status'),
          centerTitle: true,
          automaticallyImplyLeading: false,
          actions: isTerminal
              ? [
                  IconButton(
                    icon: const Icon(Icons.close_rounded),
                    onPressed: _returnHome,
                  ),
                ]
              : null,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 12),

                Center(
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    padding: const EdgeInsets.all(26),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color.withOpacity(0.1),
                      border: Border.all(color: color.withOpacity(0.4), width: 2.5),
                    ),
                    child: Icon(
                      _statusIcon,
                      size: 52,
                      color: color is MaterialColor ? color.shade800 : color,
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                Text(
                  _headlineText,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),

                const SizedBox(height: 8),

                Text(
                  _descriptionText,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.grey.shade600,
                    height: 1.4,
                  ),
                ),

                const SizedBox(height: 24),

                // RECEIVING HOSPITAL CARD
                if (_hospitalName != null) ...[
                  Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.teal.shade50,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.teal.shade200),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.teal.shade100,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.local_hospital_rounded, color: Colors.teal.shade900, size: 24),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'RECEIVING HOSPITAL',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.8,
                                  color: Colors.teal,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _hospitalName!,
                                style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                              if (_hospitalAddress != null && _hospitalAddress!.isNotEmpty) ...[
                                const SizedBox(height: 3),
                                Text(
                                  _hospitalAddress!,
                                  style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                // ASSIGNED RESPONDER CARD
                if (_driverName != null || _vehicleLabel != null) ...[
                  Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.blue.shade200),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.blue.shade100,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.directions_car_rounded, color: Colors.blue.shade900, size: 24),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'ASSIGNED RESPONDER',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.8,
                                  color: Colors.blue,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _driverName ?? 'Assigned Responder',
                                style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                              if (_vehicleLabel != null && _vehicleLabel!.isNotEmpty) ...[
                                const SizedBox(height: 3),
                                Row(
                                  children: [
                                    Icon(Icons.badge_outlined, size: 14, color: Colors.blue.shade800),
                                    const SizedBox(width: 4),
                                    Text(
                                      _vehicleLabel!,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.blue.shade900,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                              if (_driverPhone != null && _driverPhone!.isNotEmpty) ...[
                                const SizedBox(height: 6),
                                InkWell(
                                  onTap: () {
                                    Clipboard.setData(ClipboardData(text: _driverPhone!));
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text('Phone number copied'),
                                        duration: Duration(seconds: 1),
                                      ),
                                    );
                                  },
                                  child: Row(
                                    children: [
                                      Icon(Icons.phone_outlined, size: 14, color: Colors.blue.shade800),
                                      const SizedBox(width: 4),
                                      Text(
                                        _driverPhone!,
                                        style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.blue.shade900,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      const Icon(Icons.copy_rounded, size: 12, color: Colors.blue),
                                    ],
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                // TICKET DETAILS CONTAINER
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Request Reference', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                          InkWell(
                            onTap: displayId != null
                                ? () {
                                    Clipboard.setData(ClipboardData(text: displayId));
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Copied to clipboard'), duration: Duration(seconds: 1)),
                                    );
                                  }
                                : null,
                            child: Row(
                              children: [
                                Text('#$shortId', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                                if (displayId != null) ...[
                                  const SizedBox(width: 4),
                                  Icon(Icons.copy_rounded, size: 14, color: Colors.grey.shade600),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Current Lifecycle State', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: color.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: color.withOpacity(0.35)),
                            ),
                            child: Text(
                              _currentStatus,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: color is MaterialColor ? color.shade800 : color,
                              ),
                            ),
                          ),
                        ],
                      ),
                      if (_resolvedAddress != null || widget.latitude != null) ...[
                        const Divider(height: 20),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Location', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                            const SizedBox(width: 16),
                            Flexible(
                              child: Text(
                                _resolvedAddress ?? '${widget.latitude?.toStringAsFixed(5)}, ${widget.longitude?.toStringAsFixed(5)}',
                                textAlign: TextAlign.right,
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),

                const SizedBox(height: 28),

                if (_isCompleted) ...[
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      backgroundColor: Colors.green.shade700,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _returnHome,
                    icon: const Icon(Icons.home_outlined),
                    label: const Text(
                      'Return to Home',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ] else if (_isCancelled) ...[
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      backgroundColor: Colors.black87,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _returnHome,
                    icon: const Icon(Icons.home_outlined),
                    label: const Text(
                      'Return to Home',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ] else if (!_canClientCancel) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.amber.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.amber.shade300),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, size: 18, color: Colors.amber.shade900),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '$_currentStatus: Response is in progress. Please contact dispatch if you need to cancel.',
                            style: TextStyle(fontSize: 12, color: Colors.amber.shade900),
                          ),
                        ),
                      ],
                    ),
                  ),
                ] else ...[
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      foregroundColor: Colors.red.shade700,
                      side: BorderSide(color: Colors.red.shade300, width: 1.5),
                      backgroundColor: Colors.red.shade50,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _isCancelling ? null : _confirmAndCancelRequest,
                    icon: _isCancelling
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.red),
                          )
                        : const Icon(Icons.close_rounded, size: 20),
                    label: Text(
                      _isCancelling ? 'Cancelling...' : 'Cancel Emergency Request',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],

                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }
}