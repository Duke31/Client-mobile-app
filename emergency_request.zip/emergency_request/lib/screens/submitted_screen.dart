import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/app_theme.dart';
import 'home_screen.dart';
import 'request_screen.dart';
import 'live_ambulance_tracking_screen.dart';

class SubmittedScreen extends StatefulWidget {
  final String? requestId;
  final double? latitude;
  final double? longitude;
  final String? address;
  final String? patientAddress;

  const SubmittedScreen({
    super.key,
    this.requestId,
    this.latitude,
    this.longitude,
    this.address,
    this.patientAddress,
  });

  @override
  State<SubmittedScreen> createState() => _SubmittedScreenState();
}

class _SubmittedScreenState extends State<SubmittedScreen>
    with SingleTickerProviderStateMixin {
  final SupabaseClient _supabase = Supabase.instance.client;
  String? _requestId;
  bool _isCancelling = false;
  String _currentStatus = 'Requested';
  String _actorRole = 'client';

  String? _hospitalName;
  String? _hospitalAddress;
  String? _hospitalPhone;
  String? _driverName;
  String? _vehicleLabel;
  String? _driverPhone;

  Timer? _pollTimer;
  Timer? _autoCloseTimer;
  StreamSubscription<List<Map<String, dynamic>>>? _realtimeSub;

  late final AnimationController _radarController;
  late final Animation<double> _radarScale;
  late final Animation<double> _radarOpacity;

  String? get _resolvedAddress => widget.address ?? widget.patientAddress;

  // 6 Defined Solace Emergency Phases
  static const List<Map<String, String>> _lifecyclePhases = [
    {
      'title': 'Triaged',
      'sub': 'Beacon received by Ops desk',
    },
    {
      'title': 'Hospital ER',
      'sub': 'Trauma bay & bed reserved',
    },
    {
      'title': 'Ambulance Assigned',
      'sub': 'Paramedic crew mobilized',
    },
    {
      'title': 'En Route',
      'sub': 'Navigating to your GPS',
    },
    {
      'title': 'In Transit',
      'sub': 'Patient heading to ER',
    },
    {
      'title': 'ER Intake',
      'sub': 'Arrival at hospital',
    },
  ];

  int get _currentPhaseIndex {
    final s = _currentStatus.toLowerCase();
    if (s.contains('complete') || s.contains('intake') || s.contains('arrived / intake')) {
      return 5;
    }
    if (s.contains('picked') || s.contains('en route to hospital')) {
      return 4;
    }
    if (s.contains('en route to patient') || s.contains('en route')) {
      return 3;
    }
    if (s.contains('driver assigned') || _driverName != null) {
      return 2;
    }
    if (s.contains('hospital confirmed') || _hospitalName != null) {
      return 1;
    }
    return 0;
  }

  bool get _isCompleted {
    final s = _currentStatus.toLowerCase();
    return s.contains('complete');
  }

  bool get _isCancelled {
    final s = _currentStatus.toLowerCase();
    return s.contains('cancel') || s.contains('fail');
  }

  bool get _canClientCancel {
    final s = _currentStatus.toLowerCase();
    return s == 'requested' || s == 'matching';
  }

  bool get _canTrackLive {
    final s = _currentStatus.toLowerCase();
    return s.contains('driver') ||
        s.contains('en route') ||
        s.contains('picked') ||
        s.contains('arrived') ||
        _driverName != null;
  }

  @override
  void initState() {
    super.initState();
    _requestId = widget.requestId;

    _radarController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();

    _radarScale = Tween<double>(begin: 1.0, end: 1.5).animate(
      CurvedAnimation(parent: _radarController, curve: Curves.easeOutQuad),
    );

    _radarOpacity = Tween<double>(begin: 0.65, end: 0.0).animate(
      CurvedAnimation(parent: _radarController, curve: Curves.easeOutQuad),
    );

    _fetchUserRole();

    if (_requestId != null && _requestId!.isNotEmpty) {
      _startStatusMonitoring(_requestId!);
    } else {
      _fetchActiveRequestId();
    }
  }

  @override
  void dispose() {
    _radarController.dispose();
    _pollTimer?.cancel();
    _autoCloseTimer?.cancel();
    _realtimeSub?.cancel();
    super.dispose();
  }

  Future<void> _fetchUserRole() async {
    final uid = _supabase.auth.currentUser?.id;
    if (uid == null) return;
    try {
      final res = await _supabase
          .from('profiles')
          .select('role')
          .eq('user_id', uid)
          .maybeSingle();
      if (res != null && res['role'] != null && mounted) {
        setState(() {
          _actorRole = res['role'].toString();
        });
      }
    } catch (_) {}
  }

  void _stopMonitoring() {
    _pollTimer?.cancel();
    _pollTimer = null;
    _realtimeSub?.cancel();
    _realtimeSub = null;
  }

  void _startStatusMonitoring(String reqId) {
    _refreshStatus(reqId);
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _refreshStatus(reqId);
    });

    _realtimeSub?.cancel();
    try {
      _realtimeSub = _supabase
          .from('emergency_requests')
          .stream(primaryKey: ['id'])
          .eq('id', reqId)
          .listen((data) {
            if (data.isNotEmpty && mounted) {
              final newStatus = data.first['status']?.toString();
              if (newStatus != null && newStatus != _currentStatus) {
                _handleStatusChange(newStatus);
              }
              _refreshStatus(reqId);
            }
          }, onError: (_) {});
    } catch (_) {}
  }

  void _handleStatusChange(String newStatus) {
    setState(() {
      _currentStatus = newStatus;
    });

    if (_isCompleted || _isCancelled) {
      _stopMonitoring();
      if (_isCompleted) {
        _autoCloseTimer?.cancel();
        _autoCloseTimer = Timer(const Duration(seconds: 5), () {
          if (mounted) {
            _returnHome();
          }
        });
      }
    }
  }

  Future<void> _refreshStatus(String reqId) async {
    try {
      // 1. Join query directly pulls hospital and driver in 1 roundtrip
      final req = await _supabase
          .from('emergency_requests')
          .select('*, hospital:hospitals(*), driver:drivers(*)')
          .eq('id', reqId)
          .maybeSingle();

      if (req == null || !mounted) return;

      final newStatus = req['status']?.toString();
      if (newStatus != null && newStatus != _currentStatus) {
        _handleStatusChange(newStatus);
      }

      String? hName = _hospitalName;
      String? hAddr = _hospitalAddress;
      String? hPhone = _hospitalPhone;
      String? dName = _driverName;
      String? vLabel = _vehicleLabel;
      String? dPhone = _driverPhone;

      // Extract hospital from join
      if (req['hospital'] is Map) {
        final h = req['hospital'] as Map;
        hName = h['name']?.toString() ?? h['hospital_name']?.toString() ?? hName;
        hAddr = h['address']?.toString() ?? h['location']?.toString() ?? hAddr;
        hPhone = h['intake_phone']?.toString() ??
            h['phone']?.toString() ??
            h['emergency_phone']?.toString() ??
            hPhone;
      }

      // Extract driver from join
      if (req['driver'] is Map) {
        final d = req['driver'] as Map;
        dName = d['display_name']?.toString() ??
            d['full_name']?.toString() ??
            d['name']?.toString() ??
            dName;
        vLabel = d['vehicle_label']?.toString() ??
            d['vehicle_plate']?.toString() ??
            d['plate_number']?.toString() ??
            d['call_sign']?.toString() ??
            vLabel;
        dPhone = d['phone']?.toString() ??
            d['phone_number']?.toString() ??
            d['mobile']?.toString() ??
            d['contact_phone']?.toString() ??
            dPhone;
      }

      // Fallback manual query if IDs exist but join wasn't expanded
      final hospitalId = req['hospital_id']?.toString();
      final driverId = req['driver_id']?.toString();

      if (hName == null && hospitalId != null && hospitalId.isNotEmpty) {
        try {
          final hRes = await _supabase
              .from('hospitals')
              .select('*')
              .eq('id', hospitalId)
              .maybeSingle();
          if (hRes != null) {
            hName = hRes['name']?.toString() ?? hRes['hospital_name']?.toString();
            hAddr = hRes['address']?.toString() ?? hRes['location']?.toString();
            hPhone = hRes['intake_phone']?.toString() ??
                hRes['phone']?.toString() ??
                hRes['emergency_phone']?.toString();
          }
        } catch (_) {}
      }

      if (dName == null && driverId != null && driverId.isNotEmpty) {
        try {
          final dRes = await _supabase
              .from('drivers')
              .select('*')
              .eq('id', driverId)
              .maybeSingle();
          if (dRes != null) {
            dName = dRes['display_name']?.toString() ??
                dRes['full_name']?.toString() ??
                dRes['name']?.toString();
            vLabel = dRes['vehicle_label']?.toString() ??
                dRes['vehicle_plate']?.toString() ??
                dRes['plate_number']?.toString() ??
                dRes['call_sign']?.toString();
            dPhone = dRes['phone']?.toString() ??
                dRes['phone_number']?.toString() ??
                dRes['mobile']?.toString() ??
                dRes['contact_phone']?.toString();
          }
        } catch (_) {}
      }

      if (mounted) {
        setState(() {
          _hospitalName = hName;
          _hospitalAddress = hAddr;
          _hospitalPhone = hPhone;
          _driverName = dName;
          _vehicleLabel = vLabel;
          _driverPhone = dPhone;
        });
      }
    } catch (e) {
      debugPrint('Status poll error: $e');
    }
  }

  Future<void> _fetchActiveRequestId() async {
    try {
      final uid = _supabase.auth.currentUser?.id;
      var q = _supabase
          .from('emergency_requests')
          .select('id, status')
          .not('status', 'in', '(completed,cancelled,failed,Completed,Cancelled / failed)');
      if (uid != null) {
        q = q.or('client_user_id.eq.,reported_by_user_id.eq.');
      }
      final res = await q.order('created_at', ascending: false).limit(1).maybeSingle();

      if (res != null && mounted) {
        final id = res['id']?.toString();
        setState(() {
          _requestId = id;
          if (res['status'] != null) {
            _currentStatus = res['status'].toString();
          }
        });
        if (id != null) {
          _startStatusMonitoring(id);
        }
      }
    } catch (_) {}
  }

  Future<void> _confirmAndCancelRequest() async {
    if (!_canClientCancel) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('A vehicle or hospital is already assigned. Please contact central dispatch to cancel.'),
          backgroundColor: Colors.amber,
        ),
      );
      return;
    }

    final bool? shouldCancel = await showDialog<bool>(
      context: context,
      barrierDismissible: !_isCancelling,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF07193F),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: Color(0xFF1E3A8A)),
          ),
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
              SizedBox(width: 8),
              Text(
                'Cancel Request?',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          content: const Text(
            'Are you sure you want to cancel this emergency request? '
            'This will stop ambulance deployment and hospital bed coordination.',
            style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.4),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Keep Active', style: TextStyle(color: Color(0xFF00D4FF))),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFD32F2F),
                foregroundColor: Colors.white,
              ),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Yes, Cancel Request'),
            ),
          ],
        );
      },
    );

    if (shouldCancel == true && mounted) {
      await _executeCancelRpc();
    }
  }

  Future<void> _executeCancelRpc() async {
    final idToCancel = _requestId;
    if (idToCancel == null || idToCancel.isEmpty) return;

    setState(() => _isCancelling = true);
    try {
      await _supabase.rpc('transition_emergency_state', params: {
        'request_id': idToCancel,
        'new_state': 'Cancelled / failed',
        'actor_role': _actorRole,
      });
      if (!mounted) return;
      _returnHome();
    } catch (e) {
      if (!mounted) return;
      setState(() => _isCancelling = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cancel error: $e'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  void _openLiveTracking() {
    final id = _requestId;
    if (id == null || id.isEmpty) return;
    final lat = widget.latitude ?? 6.5244;
    final lng = widget.longitude ?? 3.3792;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => LiveAmbulanceTrackingScreen(
          requestId: id,
          patientLocation: LatLng(lat, lng),
          patientAddress: _resolvedAddress,
        ),
      ),
    );
  }

  void _returnHome() {
    _autoCloseTimer?.cancel();
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const HomeScreen()),
      (route) => false,
    );
  }

  // Reliable Phone Call with Intent & Fallback
  Future<void> _makeCall(String? phone) async {
    if (phone == null || phone.trim().isEmpty) return;
    final clean = phone.trim().replaceAll(RegExp(r'[^0-9+]'), '');
    final uri = Uri.parse('tel:$clean');

    try {
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched) {
        await launchUrl(uri);
      }
    } catch (e) {
      Clipboard.setData(ClipboardData(text: clean));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Copied $clean to dialer'),
            backgroundColor: const Color(0xFF00E676),
            action: SnackBarAction(
              label: 'Copy Done',
              textColor: Colors.black,
              onPressed: () {},
            ),
          ),
        );
      }
    }
  }

  // Reliable SMS with Intent & Fallback
  Future<void> _sendSms(String? phone) async {
    if (phone == null || phone.trim().isEmpty) return;
    final clean = phone.trim().replaceAll(RegExp(r'[^0-9+]'), '');
    final uri = Uri(
      scheme: 'sms',
      path: clean,
      queryParameters: {
        'body': 'Emergency update (Ref: #$_shortId): Patient is waiting at ${_resolvedAddress ?? "our GPS location"}.'
      },
    );

    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      Clipboard.setData(ClipboardData(text: clean));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Copied $clean for SMS')),
        );
      }
    }
  }

  // Direct WhatsApp for driver
  Future<void> _sendWhatsAppDriver(String? phone) async {
    if (phone == null || phone.trim().isEmpty) return;
    final clean = phone.trim().replaceAll(RegExp(r'[^0-9]'), '');
    final text = Uri.encodeComponent(
      'Emergency update (Ref: #$_shortId): We are waiting at ${_resolvedAddress ?? "our GPS location"}.',
    );
    final uri = Uri.parse('https://wa.me/$clean?text=$text');
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  String get _shortId {
    final id = _requestId;
    if (id != null && id.length > 8) {
      return id.substring(0, 8).toUpperCase();
    }
    return id?.toUpperCase() ?? 'ACTIVE';
  }

  String get _headlineText {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return 'Request Cancelled';
    if (s.contains('complete')) return 'Emergency Handled Successfully';
    if (s.contains('arrived / intake') || s.contains('intake')) return 'Arrived at Emergency Room';
    if (s.contains('picked') || s.contains('en route to hospital')) return 'Patient En Route to Hospital ER';
    if (s.contains('arrived')) return 'Ambulance At Your Location';
    if (s.contains('en route')) return 'Ambulance En Route To You';
    if (s.contains('driver assigned') || _driverName != null) return 'Ambulance Driver Assigned';
    if (s.contains('hospital confirmed') || _hospitalName != null) return 'Receiving Hospital Confirmed';
    return 'Dispatching Nearest Ambulance';
  }

  String get _descriptionText {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return 'This emergency run was cancelled.';
    if (s.contains('complete')) return 'The patient has been transferred safely into hospital emergency care.';
    if (s.contains('arrived / intake')) return 'Ambulance has arrived at the receiving emergency department for immediate intake.';
    if (s.contains('picked') || s.contains('en route to hospital')) {
      return 'Patient is safely on board the ambulance and heading directly to ${_hospitalName ?? "the confirmed hospital"}.';
    }
    if (s.contains('arrived')) {
      return 'Paramedic crew has arrived at your compound/street. Please look out for the unit.';
    }
    if (s.contains('en route')) {
      return 'Assigned paramedic response crew is navigating directly to your GPS coordinates.';
    }
    if (s.contains('driver assigned') || _driverName != null) {
      return 'Ambulance unit ${_vehicleLabel ?? "Solace-Alpha"} with ${_driverName ?? "responder"} has accepted your emergency run.';
    }
    if (s.contains('hospital confirmed') || _hospitalName != null) {
      return 'Trauma resuscitation bay reserved at ${_hospitalName!}. Assigning nearest mobile response ambulance.';
    }
    return 'Emergency beacon broadcasted. Central Ops desk is triaging closest ambulance and reserving ER trauma bed.';
  }

  @override
  Widget build(BuildContext context) {
    final isTerminal = _isCompleted || _isCancelled;
    final activePhase = _currentPhaseIndex;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? AppTheme.darkBg : AppTheme.lightBg;
    final cardColor = isDark ? AppTheme.darkCard : Colors.white;
    final cardBorder = isDark ? AppTheme.darkCardBorder : const Color(0xFFCBD5E1);
    final textPrimary = isDark ? Colors.white : const Color(0xFF0F172A);
    final textSecondary = isDark ? const Color(0xFF81D4FA) : const Color(0xFF0284C7);
    final textMuted = isDark ? Colors.white60 : const Color(0xFF64748B);

    return PopScope(
      canPop: isTerminal,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          _returnHome();
        }
      },
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: cardColor,
          elevation: isDark ? 0 : 0.5,
          leadingWidth: 44,
          leading: Padding(
            padding: const EdgeInsets.only(left: 12.0),
            child: Image.asset(
              'assets/images/solace_icon.png',
              height: 28,
              width: 28,
              errorBuilder: (_, __, ___) => const Icon(
                Icons.emergency_rounded,
                color: Color(0xFF00D4FF),
                size: 26,
              ),
            ),
          ),
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'SOLACE RAPID DISPATCH',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: textPrimary,
                  fontWeight: FontWeight.w900,
                  fontSize: 14.5,
                  letterSpacing: 1.0,
                ),
              ),
              Text(
                'Live Emergency Mission Desk',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: textSecondary,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          actions: [
            Container(
              margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF0D2559) : const Color(0xFFE0F2FE),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: isDark ? const Color(0xFF00D4FF) : const Color(0xFF0284C7), width: 0.8),
              ),
              child: Text(
                '#$_shortId',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF00D4FF),
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.8,
                ),
              ),
            ),
          ],
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // 1. TACTICAL RADAR BEACON VISUAL
                Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      if (!_isCancelled)
                        AnimatedBuilder(
                          animation: _radarController,
                          builder: (context, child) {
                            return Transform.scale(
                              scale: _radarScale.value,
                              child: Container(
                                width: 110,
                                height: 110,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: (_canTrackLive
                                          ? const Color(0xFF00D4FF)
                                          : const Color(0xFFFF334B))
                                      .withValues(alpha: _radarOpacity.value),
                                ),
                              ),
                            );
                          },
                        ),
                      Container(
                        width: 82,
                        height: 82,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF07193F),
                          border: Border.all(
                            color: _canTrackLive
                                ? const Color(0xFF00D4FF)
                                : const Color(0xFFFF334B),
                            width: 2.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: (_canTrackLive
                                      ? const Color(0xFF00D4FF)
                                      : const Color(0xFFFF334B))
                                  .withValues(alpha: 0.35),
                              blurRadius: 14,
                            ),
                          ],
                        ),
                        child: Icon(
                          _canTrackLive
                              ? Icons.directions_car_rounded
                              : (_isCancelled
                                  ? Icons.cancel_outlined
                                  : Icons.sensors_rounded),
                          size: 38,
                          color: _canTrackLive
                              ? const Color(0xFF00D4FF)
                              : (_isCancelled ? Colors.redAccent : const Color(0xFFFF334B)),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 14),

                // Headline
                Text(
                  _headlineText,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),

                // Description
                Text(
                  _descriptionText,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),

                const SizedBox(height: 18),

                // 2. LIVE INTERACTIVE MULTI-PHASE MILESTONE STEPPER (MATCHING TO COMPLETED)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: cardColor,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: cardBorder),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.linear_scale_rounded, color: Color(0xFF00D4FF), size: 16),
                          const SizedBox(width: 6),
                          const Text(
                            'EMERGENCY DISPATCH PHASES',
                            style: TextStyle(
                              color: Color(0xFF81D4FA),
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.8,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            'PHASE ${activePhase + 1} OF 6',
                            style: const TextStyle(
                              color: Color(0xFF00E676),
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      // Stepper items list
                      Column(
                        children: List.generate(_lifecyclePhases.length, (idx) {
                          final phase = _lifecyclePhases[idx];
                          final isPassed = idx < activePhase;
                          final isCurrent = idx == activePhase && !_isCancelled;
                          final isPending = idx > activePhase || _isCancelled;

                          return Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Left timeline indicator
                              Column(
                                children: [
                                  Container(
                                    width: 22,
                                    height: 22,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: isPassed
                                          ? const Color(0xFF00E676)
                                          : (isCurrent
                                              ? const Color(0xFF00D4FF)
                                              : Colors.white12),
                                      border: Border.all(
                                        color: isCurrent
                                            ? Colors.white
                                            : Colors.transparent,
                                        width: 1.8,
                                      ),
                                    ),
                                    child: Center(
                                      child: isPassed
                                          ? const Icon(Icons.check, size: 14, color: Colors.black)
                                          : isCurrent
                                              ? const SizedBox(
                                                  width: 8,
                                                  height: 8,
                                                  child: CircularProgressIndicator(
                                                    strokeWidth: 2,
                                                    color: Colors.black,
                                                  ),
                                                )
                                              : Text(
                                                  '${idx + 1}',
                                                  style: const TextStyle(
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.white38,
                                                  ),
                                                ),
                                    ),
                                  ),
                                  if (idx < _lifecyclePhases.length - 1)
                                    Container(
                                      width: 2,
                                      height: 22,
                                      color: isPassed
                                          ? const Color(0xFF00E676)
                                          : Colors.white12,
                                    ),
                                ],
                              ),
                              const SizedBox(width: 12),

                              // Right phase details
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 2, bottom: 8),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        phase['title']!,
                                        style: TextStyle(
                                          color: isCurrent
                                              ? Colors.white
                                              : (isPassed
                                                  ? const Color(0xFF80D8FF)
                                                  : Colors.white38),
                                          fontSize: 12.5,
                                          fontWeight: isCurrent ? FontWeight.bold : FontWeight.w500,
                                        ),
                                      ),
                                      Text(
                                        phase['sub']!,
                                        style: TextStyle(
                                          color: isCurrent ? const Color(0xFF00E676) : Colors.white38,
                                          fontSize: 10,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          );
                        }),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 14),

                // 3. ASSIGNED RESPONDER CARD (With Fully Interactive Phone & Live Map)
                Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A224E),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _driverName != null ? const Color(0xFF00D4FF) : const Color(0xFF1E3A8A),
                      width: _driverName != null ? 1.6 : 1.0,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.3),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: const Color(0xFF00D4FF).withValues(alpha: 0.15),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.directions_car_rounded,
                              color: Color(0xFF00D4FF),
                              size: 24,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'ASSIGNED AMBULANCE RESPONDER',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Color(0xFF81D4FA),
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  _driverName ?? 'Locating Closest Paramedic Team...',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 15.5,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                if (_vehicleLabel != null && _vehicleLabel!.isNotEmpty) ...[
                                  const SizedBox(height: 3),
                                  Row(
                                    children: [
                                      const Icon(Icons.badge_outlined, size: 14, color: Color(0xFF00D4FF)),
                                      const SizedBox(width: 4),
                                      Expanded(
                                        child: Text(
                                          _vehicleLabel!,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: Color(0xFF80D8FF),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),

                      // Driver Phone & Interactive Call/SMS Actions
                      if (_driverPhone != null && _driverPhone!.isNotEmpty) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: const Color(0xFF07193F),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFF00E676).withValues(alpha: 0.4)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.phone_in_talk_rounded, size: 16, color: Color(0xFF00E676)),
                                  const SizedBox(width: 6),
                                  Text(
                                    _driverPhone!,
                                    style: const TextStyle(
                                      color: Color(0xFF00E676),
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  const Spacer(),
                                  const Text(
                                    'Direct Line',
                                    style: TextStyle(color: Colors.white38, fontSize: 10),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),

                              // Interactive Action Row: CALL, SMS, WHATSAPP, COPY
                              Row(
                                children: [
                                  Expanded(
                                    child: FilledButton.icon(
                                      style: FilledButton.styleFrom(
                                        backgroundColor: const Color(0xFF00E676),
                                        foregroundColor: Colors.black,
                                        padding: const EdgeInsets.symmetric(vertical: 10),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                      ),
                                      onPressed: () => _makeCall(_driverPhone),
                                      icon: const Icon(Icons.call_rounded, size: 16),
                                      label: const Text('CALL DRIVER', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: OutlinedButton.icon(
                                      style: OutlinedButton.styleFrom(
                                        foregroundColor: const Color(0xFF00D4FF),
                                        side: const BorderSide(color: Color(0xFF00D4FF)),
                                        padding: const EdgeInsets.symmetric(vertical: 10),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                      ),
                                      onPressed: () => _sendSms(_driverPhone),
                                      icon: const Icon(Icons.sms_rounded, size: 16),
                                      label: const Text('SMS ROUTE', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  IconButton(
                                    style: IconButton.styleFrom(
                                      backgroundColor: const Color(0xFF25D366).withValues(alpha: 0.2),
                                      padding: const EdgeInsets.all(8),
                                    ),
                                    icon: const Icon(Icons.chat_bubble_rounded, size: 18, color: Color(0xFF25D366)),
                                    tooltip: 'WhatsApp Driver',
                                    onPressed: () => _sendWhatsAppDriver(_driverPhone),
                                  ),
                                  const SizedBox(width: 4),
                                  IconButton(
                                    style: IconButton.styleFrom(
                                      backgroundColor: Colors.white12,
                                      padding: const EdgeInsets.all(8),
                                    ),
                                    icon: const Icon(Icons.copy_rounded, size: 16, color: Colors.white70),
                                    tooltip: 'Copy Number',
                                    onPressed: () {
                                      Clipboard.setData(ClipboardData(text: _driverPhone!));
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Driver phone copied to clipboard')),
                                      );
                                    },
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Call or SMS driver to guide street turns & estate gate access',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 10.5, color: Colors.white54),
                        ),
                      ],

                      if (_canTrackLive && !isTerminal) ...[
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 46,
                          child: FilledButton.icon(
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF00D4FF),
                              foregroundColor: Colors.black,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            onPressed: _openLiveTracking,
                            icon: const Icon(Icons.radar_rounded, size: 20),
                            label: const Text(
                              'TRACK AMBULANCE RADAR LIVE',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),

                // 4. THE HOSPITAL CARD (ALWAYS VISIBLE & PROMINENT)
                Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF072740),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _hospitalName != null ? const Color(0xFF00ACC1) : const Color(0xFF1E3A8A),
                      width: _hospitalName != null ? 1.5 : 1.0,
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFF00ACC1).withValues(alpha: 0.18),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.local_hospital_rounded,
                          color: Color(0xFF00ACC1),
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _hospitalName != null
                                  ? 'RECEIVING HOSPITAL (ASSIGNED)'
                                  : 'RECEIVING HOSPITAL (TRIAGE IN PROGRESS)',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: _hospitalName != null ? const Color(0xFF80DEEA) : const Color(0xFF81D4FA),
                                fontSize: 10.5,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.8,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              _hospitalName ?? 'Matching Closest Verified Trauma ER...',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              _hospitalAddress ?? 'Triage desk securing facility with open ICU & resuscitation bed',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 11.5,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _hospitalName != null
                                  ? '🟢 Trauma Bay Alerted & Bed Reserved'
                                  : '⏳ Auto-Allocating Emergency Trauma Center',
                              style: TextStyle(
                                color: _hospitalName != null ? const Color(0xFF00E676) : Colors.amberAccent,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (_hospitalPhone != null && _hospitalPhone!.isNotEmpty)
                        IconButton(
                          style: IconButton.styleFrom(
                            backgroundColor: const Color(0xFF00ACC1).withValues(alpha: 0.2),
                            padding: const EdgeInsets.all(8),
                          ),
                          icon: const Icon(Icons.phone_in_talk_rounded, color: Color(0xFF00ACC1), size: 18),
                          tooltip: 'Call Hospital ER',
                          onPressed: () => _makeCall(_hospitalPhone),
                        ),
                    ],
                  ),
                ),

                // 5. CENTRAL DISPATCH DESK & PICKUP DESTINATION
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF07193F),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF1E3A8A)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.shield_rounded, color: Color(0xFF00E676), size: 16),
                          const SizedBox(width: 8),
                          const Expanded(
                            child: Text(
                              'SOLACE CENTRAL DISPATCH DESK • ACTIVE',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Color(0xFF00E676),
                                fontSize: 9.5,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                          Text(
                            'REF: #$_shortId',
                            style: const TextStyle(color: Colors.white54, fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.location_on_rounded, color: Color(0xFF00D4FF), size: 16),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _resolvedAddress ?? 'GPS Destination Verified',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 14),

                // 6. SOLELY QUICK FIRST AID TIPS (FOR PATIENT & BYSTANDERS)
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF07193F),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF00D4FF).withValues(alpha: 0.3)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: const [
                          Icon(Icons.medical_services_rounded, color: Color(0xFF00D4FF), size: 18),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'QUICK FIRST AID (WHILE WAITING FOR AMBULANCE)',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.6,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _buildAidTip(
                        icon: Icons.air_rounded,
                        title: 'Airway & Recovery Position',
                        body: 'Keep airway open. If patient is breathing but drowsy or unconscious, gently roll them onto their side (Recovery Position). Never leave them face-down.',
                      ),
                      const SizedBox(height: 8),
                      _buildAidTip(
                        icon: Icons.healing_rounded,
                        title: 'Severe Bleeding Control',
                        body: 'Press a clean cloth or towel firmly and directly over the wound. Maintain continuous pressure with your hands. Do not remove soaked cloth; add more on top.',
                      ),
                      const SizedBox(height: 8),
                      _buildAidTip(
                        icon: Icons.favorite_rounded,
                        title: 'Chest Pain / Heart Distress',
                        body: 'Keep patient resting seated or half-upright. Loosen tight collar and chest clothing. Keep them calm and prevent any physical walking or exertion.',
                      ),
                      const SizedBox(height: 8),
                      _buildAidTip(
                        icon: Icons.warning_amber_rounded,
                        title: 'Crash / Spine Injury — Do Not Move',
                        body: 'Do NOT move or drag an accident patient unless there is immediate fire or explosion hazard. Support head and neck firmly in the position found.',
                      ),
                      const SizedBox(height: 8),
                      _buildAidTip(
                        icon: Icons.no_drinks_rounded,
                        title: 'No Food, Water, or Oral Meds',
                        body: 'Do NOT give water, food, or pills to an injured, drowsy, or seizing patient. Doing so can cause fatal airway choking and aspiration.',
                      ),
                      const SizedBox(height: 8),
                      _buildAidTip(
                        icon: Icons.record_voice_over_rounded,
                        title: 'Continuous Reassurance',
                        body: 'Speak calmly to the patient. Tell them Solace ambulance paramedics are en route. Continuously monitor their breathing until the crew arrives.',
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 18),

                // 7. EMERGENCY CANCELLATION (If still eligible)
                if (_canClientCancel && !isTerminal)
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.redAccent,
                      side: const BorderSide(color: Colors.redAccent, width: 1.2),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: _isCancelling ? null : _confirmAndCancelRequest,
                    icon: _isCancelling
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.redAccent,
                            ),
                          )
                        : const Icon(Icons.close_rounded, size: 18),
                    label: Text(
                      _isCancelling ? 'Cancelling Request...' : 'Cancel Emergency Request',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                  ),

                if (isTerminal)
                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF0D2559),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: _returnHome,
                    child: const Text('Return to Home Screen'),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAidTip({
    required IconData icon,
    required String title,
    required String body,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFF00D4FF), size: 16),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11.5,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 1),
              Text(
                body,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 10.5,
                  height: 1.35,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
