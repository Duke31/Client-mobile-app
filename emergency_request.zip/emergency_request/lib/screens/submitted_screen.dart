import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SubmittedScreen extends StatefulWidget {
  final String? requestId;
  final double? latitude;
  final double? longitude;
  final String? address;
  final String? patientAddress;

  const SubmittedScreen({
    super.key,
    this.requestId,
    this.latitude,
    this.longitude,
    this.address,
    this.patientAddress,
  });

  @override
  State<SubmittedScreen> createState() => _SubmittedScreenState();
}

class _SubmittedScreenState extends State<SubmittedScreen> {
  final SupabaseClient _supabase = Supabase.instance.client;

  String? _requestId;
  bool _isCancelling = false;
  String _currentStatus = 'Requested';
  StreamSubscription<List<Map<String, dynamic>>>? _realtimeSub;

  String? get _resolvedAddress => widget.address ?? widget.patientAddress;

  // The client can only cancel while still in initial unassigned phases
  bool get _canClientCancel {
    final s = _currentStatus.toLowerCase();
    return s == 'requested' || s == 'matching';
  }

  @override
  void initState() {
    super.initState();
    _requestId = widget.requestId;
    if (_requestId != null && _requestId!.isNotEmpty) {
      _listenToRequestStatus(_requestId!);
    } else {
      _fetchActiveRequestId();
    }
  }

  @override
  void dispose() {
    _realtimeSub?.cancel();
    super.dispose();
  }

  /// Listens to live status changes made by Dispatcher / Admin
  void _listenToRequestStatus(String reqId) {
    _realtimeSub?.cancel();
    _realtimeSub = _supabase
        .from('emergency_requests')
        .stream(primaryKey: ['id'])
        .eq('id', reqId)
        .listen((data) {
          if (data.isNotEmpty && mounted) {
            final latest = data.first;
            setState(() {
              _currentStatus = latest['status']?.toString() ?? _currentStatus;
            });
          }
        });
  }

  Future<void> _fetchActiveRequestId() async {
    try {
      final res = await _supabase
          .from('emergency_requests')
          .select('id, status')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (res != null && mounted) {
        final id = res['id']?.toString();
        setState(() {
          _requestId = id;
          if (res['status'] != null) {
            _currentStatus = res['status'].toString();
          }
        });
        if (id != null) {
          _listenToRequestStatus(id);
        }
      }
    } catch (e) {
      debugPrint('Error fetching active ticket: $e');
    }
  }

  Future<void> _confirmAndCancelRequest() async {
    if (!_canClientCancel) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('A vehicle or hospital has already been assigned. Please contact dispatch to cancel.'),
          backgroundColor: Colors.amber,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final bool? shouldCancel = await showDialog<bool>(
      context: context,
      barrierDismissible: !_isCancelling,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
              SizedBox(width: 8),
              Text('Cancel Request?'),
            ],
          ),
          content: const Text(
            'Are you sure you want to cancel this emergency request? '
            'This will stop hospital notification and dispatch coordination.',
            style: TextStyle(fontSize: 14, height: 1.4),
          ),
          actionsPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Keep Active'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                foregroundColor: Colors.white,
              ),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Yes, Cancel Request'),
            ),
          ],
        );
      },
    );

    if (shouldCancel == true && mounted) {
      await _executeCancelRpc();
    }
  }

  Future<void> _executeCancelRpc() async {
    final idToCancel = _requestId;
    if (idToCancel == null || idToCancel.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Cannot locate request ticket.'),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() => _isCancelling = true);

    try {
      // 1. Try standard parameter signature
      try {
        await _supabase.rpc('transition_emergency_state', params: {
          'request_id': idToCancel,
          'new_state': 'Cancelled / failed',
          'actor_role': 'client',
        });
      } catch (_) {
        // 2. Try p_ prefixed signature
        await _supabase.rpc('transition_emergency_state', params: {
          'p_request_id': idToCancel,
          'p_new_state': 'Cancelled',
          'p_actor_role': 'client',
        });
      }

      if (!mounted) return;

      // Close this screen immediately and return to the main/home view
      Navigator.of(context).pop();

      // Show confirmation on the returned screen
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Emergency request has been cancelled.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } on PostgrestException catch (e) {
      if (!mounted) return;
      setState(() => _isCancelling = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cancel failed: ${e.message}'),
          backgroundColor: Colors.red.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isCancelling = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final displayId = _requestId;
    final shortId = (displayId != null && displayId.length > 8)
        ? displayId.substring(0, 8).toUpperCase()
        : (displayId?.toUpperCase() ?? 'Connecting...');

    return WillPopScope(
      onWillPop: () async {
        final confirmExit = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Leave Screen?'),
            content: const Text(
              'Your request is active. Leaving this screen will not cancel dispatch coordination.',
            ),
            actions: [
              TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Stay')),
              TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Leave')),
            ],
          ),
        );
        return confirmExit ?? false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Emergency Status'),
          centerTitle: true,
          automaticallyImplyLeading: false,
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Spacer(flex: 1),

                // Pulsing indicator icon
                Center(
                  child: Container(
                    padding: const EdgeInsets.all(28),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.amber.shade50,
                      border: Border.all(color: Colors.amber.shade400, width: 2.5),
                    ),
                    child: Icon(
                      Icons.notifications_active_outlined,
                      size: 56,
                      color: Colors.amber.shade800,
                    ),
                  ),
                ),

                const SizedBox(height: 28),

                Text(
                  'Help is being notified',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),

                const SizedBox(height: 10),

                Text(
                  'Your dispatch request is being broadcast to nearby verified hospitals and response teams.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.grey.shade600,
                    height: 1.4,
                  ),
                ),

                const SizedBox(height: 32),

                // Request Information Card
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Request Reference', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                          InkWell(
                            onTap: displayId != null
                                ? () {
                                    Clipboard.setData(ClipboardData(text: displayId));
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Copied to clipboard'), duration: Duration(seconds: 1)),
                                    );
                                  }
                                : null,
                            child: Row(
                              children: [
                                Text('#$shortId', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                                if (displayId != null) ...[
                                  const SizedBox(width: 4),
                                  Icon(Icons.copy_rounded, size: 14, color: Colors.grey.shade600),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Current Lifecycle State', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.blue.shade50,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: Colors.blue.shade200),
                            ),
                            child: Text(
                              _currentStatus,
                              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.blue.shade800),
                            ),
                          ),
                        ],
                      ),
                      if (_resolvedAddress != null || widget.latitude != null) ...[
                        const Divider(height: 20),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Location', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                            const SizedBox(width: 16),
                            Flexible(
                              child: Text(
                                _resolvedAddress ?? '${widget.latitude?.toStringAsFixed(5)}, ${widget.longitude?.toStringAsFixed(5)}',
                                textAlign: TextAlign.right,
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),

                const Spacer(flex: 2),

                // Cancellation Action
                if (!_canClientCancel)
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.amber.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.amber.shade300),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, size: 18, color: Colors.amber.shade900),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '$_currentStatus: Response is in progress. Please contact dispatch if you need to cancel.',
                            style: TextStyle(fontSize: 12, color: Colors.amber.shade900),
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      foregroundColor: Colors.red.shade700,
                      side: BorderSide(color: Colors.red.shade300, width: 1.5),
                      backgroundColor: Colors.red.shade50,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _isCancelling ? null : _confirmAndCancelRequest,
                    icon: _isCancelling
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.red),
                          )
                        : const Icon(Icons.close_rounded, size: 20),
                    label: Text(
                      _isCancelling ? 'Cancelling...' : 'Cancel Emergency Request',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                  ),

                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}