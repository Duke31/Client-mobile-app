import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'request_screen.dart';
import 'live_ambulance_tracking_screen.dart';

class SubmittedScreen extends StatefulWidget {
  final String? requestId;
  final double? latitude;
  final double? longitude;
  final String? address;
  final String? patientAddress;

  const SubmittedScreen({
    super.key,
    this.requestId,
    this.latitude,
    this.longitude,
    this.address,
    this.patientAddress,
  });

  @override
  State<SubmittedScreen> createState() => _SubmittedScreenState();
}

class _SubmittedScreenState extends State<SubmittedScreen>
    with SingleTickerProviderStateMixin {
  final SupabaseClient _supabase = Supabase.instance.client;
  String? _requestId;
  bool _isCancelling = false;
  String _currentStatus = 'Requested';
  String _actorRole = 'client';

  String? _hospitalName;
  String? _hospitalAddress;
  String? _hospitalPhone;
  String? _driverName;
  String? _vehicleLabel;
  String? _driverPhone;

  Timer? _pollTimer;
  Timer? _autoCloseTimer;
  StreamSubscription<List<Map<String, dynamic>>>? _realtimeSub;

  late final AnimationController _radarController;
  late final Animation<double> _radarScale;
  late final Animation<double> _radarOpacity;

  String? get _resolvedAddress => widget.address ?? widget.patientAddress;

  bool get _isCompleted {
    final s = _currentStatus.toLowerCase();
    return s.contains('complete');
  }

  bool get _isCancelled {
    final s = _currentStatus.toLowerCase();
    return s.contains('cancel') || s.contains('fail');
  }

  bool get _canClientCancel {
    final s = _currentStatus.toLowerCase();
    return s == 'requested' || s == 'matching';
  }

  bool get _canTrackLive {
    final s = _currentStatus.toLowerCase();
    return s.contains('driver') ||
        s.contains('en route') ||
        s.contains('picked') ||
        s.contains('arrived') ||
        _driverName != null;
  }

  @override
  void initState() {
    super.initState();
    _requestId = widget.requestId;

    _radarController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();

    _radarScale = Tween<double>(begin: 1.0, end: 1.5).animate(
      CurvedAnimation(parent: _radarController, curve: Curves.easeOutQuad),
    );

    _radarOpacity = Tween<double>(begin: 0.65, end: 0.0).animate(
      CurvedAnimation(parent: _radarController, curve: Curves.easeOutQuad),
    );

    _fetchUserRole();

    if (_requestId != null && _requestId!.isNotEmpty) {
      _startStatusMonitoring(_requestId!);
    } else {
      _fetchActiveRequestId();
    }
  }

  @override
  void dispose() {
    _radarController.dispose();
    _pollTimer?.cancel();
    _autoCloseTimer?.cancel();
    _realtimeSub?.cancel();
    super.dispose();
  }

  Future<void> _fetchUserRole() async {
    final uid = _supabase.auth.currentUser?.id;
    if (uid == null) return;
    try {
      final res = await _supabase
          .from('profiles')
          .select('role')
          .eq('user_id', uid)
          .maybeSingle();
      if (res != null && res['role'] != null && mounted) {
        setState(() {
          _actorRole = res['role'].toString();
        });
      }
    } catch (_) {}
  }

  void _stopMonitoring() {
    _pollTimer?.cancel();
    _pollTimer = null;
    _realtimeSub?.cancel();
    _realtimeSub = null;
  }

  void _startStatusMonitoring(String reqId) {
    _refreshStatus(reqId);
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _refreshStatus(reqId);
    });

    _realtimeSub?.cancel();
    try {
      _realtimeSub = _supabase
          .from('emergency_requests')
          .stream(primaryKey: ['id'])
          .eq('id', reqId)
          .listen((data) {
            if (data.isNotEmpty && mounted) {
              final newStatus = data.first['status']?.toString();
              if (newStatus != null && newStatus != _currentStatus) {
                _handleStatusChange(newStatus);
              }
              _refreshStatus(reqId);
            }
          }, onError: (_) {});
    } catch (_) {}
  }

  void _handleStatusChange(String newStatus) {
    setState(() {
      _currentStatus = newStatus;
    });

    if (_isCompleted || _isCancelled) {
      _stopMonitoring();
      if (_isCompleted) {
        _autoCloseTimer?.cancel();
        _autoCloseTimer = Timer(const Duration(seconds: 4), () {
          if (mounted) {
            _returnHome();
          }
        });
      }
    }
  }

  Future<void> _refreshStatus(String reqId) async {
    try {
      final req = await _supabase
          .from('emergency_requests')
          .select('id, status, hospital_id, driver_id, contact_phone')
          .eq('id', reqId)
          .maybeSingle();

      if (req == null || !mounted) return;

      final newStatus = req['status']?.toString();
      if (newStatus != null && newStatus != _currentStatus) {
        _handleStatusChange(newStatus);
      }

      final hospitalId = req['hospital_id']?.toString();
      final driverId = req['driver_id']?.toString();

      String? hName = _hospitalName;
      String? hAddr = _hospitalAddress;
      String? hPhone = _hospitalPhone;
      String? dName = _driverName;
      String? vLabel = _vehicleLabel;
      String? dPhone = _driverPhone;

      // Hospital lookup
      if (hospitalId != null && hospitalId.isNotEmpty) {
        try {
          final hRes = await _supabase
              .from('hospitals')
              .select('*')
              .eq('id', hospitalId)
              .maybeSingle();
          if (hRes != null) {
            hName = hRes['name']?.toString() ?? hRes['hospital_name']?.toString();
            hAddr = hRes['address']?.toString() ?? hRes['location']?.toString();
            hPhone = hRes['intake_phone']?.toString() ??
                hRes['phone']?.toString() ??
                hRes['emergency_phone']?.toString();
          }
        } catch (e) {
          debugPrint('Error loading hospital: $e');
        }
      }

      // Driver lookup
      if (driverId != null && driverId.isNotEmpty) {
        try {
          final dRes = await _supabase
              .from('drivers')
              .select('*')
              .eq('id', driverId)
              .maybeSingle();
          if (dRes != null) {
            dName = dRes['display_name']?.toString() ??
                dRes['full_name']?.toString() ??
                dRes['name']?.toString() ??
                'Assigned Responder';
            vLabel = dRes['vehicle_label']?.toString() ??
                dRes['vehicle_plate']?.toString() ??
                dRes['plate_number']?.toString() ??
                dRes['call_sign']?.toString() ??
                'Ambulance Unit Solace-Alpha';
            dPhone = dRes['phone']?.toString() ??
                dRes['phone_number']?.toString() ??
                dRes['mobile']?.toString() ??
                dRes['contact_phone']?.toString();
          }
        } catch (e) {
          debugPrint('Error loading driver: $e');
        }
      }

      if (mounted) {
        setState(() {
          _hospitalName = hName;
          _hospitalAddress = hAddr;
          _hospitalPhone = hPhone;
          _driverName = dName;
          _vehicleLabel = vLabel;
          _driverPhone = dPhone;
        });
      }
    } catch (e) {
      debugPrint('Status poll error: $e');
    }
  }

  Future<void> _fetchActiveRequestId() async {
    try {
      final res = await _supabase
          .from('emergency_requests')
          .select('id, status')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (res != null && mounted) {
        final id = res['id']?.toString();
        setState(() {
          _requestId = id;
          if (res['status'] != null) {
            _currentStatus = res['status'].toString();
          }
        });
        if (id != null) {
          _startStatusMonitoring(id);
        }
      }
    } catch (_) {}
  }

  Future<void> _confirmAndCancelRequest() async {
    if (!_canClientCancel) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('A vehicle or hospital is already assigned. Please contact central dispatch to cancel.'),
          backgroundColor: Colors.amber,
        ),
      );
      return;
    }

    final bool? shouldCancel = await showDialog<bool>(
      context: context,
      barrierDismissible: !_isCancelling,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF07193F),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: Color(0xFF1E3A8A)),
          ),
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
              SizedBox(width: 8),
              Text(
                'Cancel Request?',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          content: const Text(
            'Are you sure you want to cancel this emergency request? '
            'This will stop ambulance deployment and hospital bed coordination.',
            style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.4),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Keep Active', style: TextStyle(color: Color(0xFF00D4FF))),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFD32F2F),
                foregroundColor: Colors.white,
              ),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Yes, Cancel Request'),
            ),
          ],
        );
      },
    );

    if (shouldCancel == true && mounted) {
      await _executeCancelRpc();
    }
  }

  Future<void> _executeCancelRpc() async {
    final idToCancel = _requestId;
    if (idToCancel == null || idToCancel.isEmpty) return;

    setState(() => _isCancelling = true);
    try {
      await _supabase.rpc('transition_emergency_state', params: {
        'request_id': idToCancel,
        'new_state': 'Cancelled / failed',
        'actor_role': _actorRole,
      });
      if (!mounted) return;
      _returnHome();
    } catch (e) {
      if (!mounted) return;
      setState(() => _isCancelling = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cancel error: $e'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  void _openLiveTracking() {
    final id = _requestId;
    if (id == null || id.isEmpty) return;
    final lat = widget.latitude ?? 6.5244;
    final lng = widget.longitude ?? 3.3792;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => LiveAmbulanceTrackingScreen(
          requestId: id,
          patientLocation: LatLng(lat, lng),
          patientAddress: _resolvedAddress,
        ),
      ),
    );
  }

  void _returnHome() {
    _autoCloseTimer?.cancel();
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const RequestScreen()),
      (route) => false,
    );
  }

  Future<void> _makeCall(String? phone) async {
    if (phone == null || phone.trim().isEmpty) return;
    final uri = Uri.parse('tel:${phone.trim()}');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _sendSms(String? phone) async {
    if (phone == null || phone.trim().isEmpty) return;
    final uri = Uri(
      scheme: 'sms',
      path: phone.trim(),
      queryParameters: {
        'body': 'Emergency update regarding Solace Request #${_shortId}: '
            'Patient is waiting at ${_resolvedAddress ?? "our location"}.'
      },
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  String get _shortId {
    final id = _requestId;
    if (id != null && id.length > 8) {
      return id.substring(0, 8).toUpperCase();
    }
    return id?.toUpperCase() ?? 'ACTIVE';
  }

  String get _headlineText {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return 'Request Cancelled';
    if (s.contains('complete')) return 'Emergency Handled';
    if (s.contains('arrived')) return 'Ambulance At Your Location';
    if (s.contains('picked')) return 'Patient On Board Ambulance';
    if (s.contains('driver') || s.contains('en route')) return 'Ambulance En Route To You';
    return 'Dispatching Nearest Ambulance';
  }

  String get _descriptionText {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return 'This emergency run was cancelled.';
    if (s.contains('complete')) return 'The emergency cycle concluded safely.';
    if (s.contains('arrived')) {
      return 'Paramedic crew has arrived at your compound/street. Please look out for the unit.';
    }
    if (s.contains('picked')) {
      return 'Patient is safely on board and en route to the confirmed emergency trauma hospital.';
    }
    if (s.contains('driver') || s.contains('en route')) {
      return 'Assigned paramedic response crew is navigating directly to your GPS coordinates.';
    }
    return 'Your emergency beacon is broadcast to Solace fleet. Locating nearest response ambulance and reserving ER bed.';
  }

  @override
  Widget build(BuildContext context) {
    final isTerminal = _isCompleted || _isCancelled;

    return PopScope(
      canPop: isTerminal,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          _returnHome();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF061536),
        appBar: AppBar(
          backgroundColor: const Color(0xFF07193F),
          elevation: 0,
          leadingWidth: 44,
          leading: Padding(
            padding: const EdgeInsets.only(left: 12.0),
            child: Image.asset(
              'assets/images/solace_icon.png',
              height: 28,
              width: 28,
              errorBuilder: (_, __, ___) => const Icon(
                Icons.emergency_rounded,
                color: Color(0xFF00D4FF),
                size: 26,
              ),
            ),
          ),
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: const [
              Text(
                'SOLACE RAPID DISPATCH',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 14.5,
                  letterSpacing: 1.0,
                ),
              ),
              Text(
                'Live Emergency Mission Desk',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Color(0xFF81D4FA),
                  fontSize: 9.5,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          actions: [
            Container(
              margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFF0D2559),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF00D4FF), width: 0.8),
              ),
              child: Text(
                '#$_shortId',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF00D4FF),
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.8,
                ),
              ),
            ),
          ],
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // 1. TACTICAL RADAR BEACON VISUAL
                Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      if (!_isCancelled)
                        AnimatedBuilder(
                          animation: _radarController,
                          builder: (context, child) {
                            return Transform.scale(
                              scale: _radarScale.value,
                              child: Container(
                                width: 110,
                                height: 110,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: (_canTrackLive
                                          ? const Color(0xFF00D4FF)
                                          : const Color(0xFFFF334B))
                                      .withValues(alpha: _radarOpacity.value),
                                ),
                              ),
                            );
                          },
                        ),
                      Container(
                        width: 82,
                        height: 82,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF07193F),
                          border: Border.all(
                            color: _canTrackLive
                                ? const Color(0xFF00D4FF)
                                : const Color(0xFFFF334B),
                            width: 2.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: (_canTrackLive
                                      ? const Color(0xFF00D4FF)
                                      : const Color(0xFFFF334B))
                                  .withValues(alpha: 0.35),
                              blurRadius: 14,
                            ),
                          ],
                        ),
                        child: Icon(
                          _canTrackLive
                              ? Icons.directions_car_rounded
                              : (_isCancelled
                                  ? Icons.cancel_outlined
                                  : Icons.sensors_rounded),
                          size: 38,
                          color: _canTrackLive
                              ? const Color(0xFF00D4FF)
                              : (_isCancelled ? Colors.redAccent : const Color(0xFFFF334B)),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Headline
                Text(
                  _headlineText,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),

                // Description
                Text(
                  _descriptionText,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),

                const SizedBox(height: 18),

                // 2. ASSIGNED RESPONDER CARD (Prominent End-to-End Transmission)
                if (_driverName != null || _vehicleLabel != null) ...[
                  Container(
                    margin: const EdgeInsets.only(bottom: 14),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0A224E),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF00D4FF), width: 1.6),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF00D4FF).withValues(alpha: 0.15),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: const Color(0xFF00D4FF).withValues(alpha: 0.15),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.directions_car_rounded,
                                color: Color(0xFF00D4FF),
                                size: 24,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'ASSIGNED RESPONDER',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: Color(0xFF81D4FA),
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.8,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    _driverName ?? 'Assigned Emergency Responder',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 15.5,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  if (_vehicleLabel != null && _vehicleLabel!.isNotEmpty) ...[
                                    const SizedBox(height: 3),
                                    Row(
                                      children: [
                                        const Icon(Icons.badge_outlined, size: 14, color: Color(0xFF00D4FF)),
                                        const SizedBox(width: 4),
                                        Expanded(
                                          child: Text(
                                            _vehicleLabel!,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                              color: Color(0xFF80D8FF),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                  if (_driverPhone != null && _driverPhone!.isNotEmpty) ...[
                                    const SizedBox(height: 8),
                                    Row(
                                      children: [
                                        InkWell(
                                          onTap: () => _makeCall(_driverPhone),
                                          borderRadius: BorderRadius.circular(8),
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFF00E676).withValues(alpha: 0.2),
                                              borderRadius: BorderRadius.circular(8),
                                              border: Border.all(color: const Color(0xFF00E676), width: 1),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                const Icon(Icons.phone_rounded, size: 14, color: Color(0xFF00E676)),
                                                const SizedBox(width: 6),
                                                Text(
                                                  _driverPhone!,
                                                  style: const TextStyle(
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.bold,
                                                    color: Color(0xFF00E676),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        IconButton(
                                          style: IconButton.styleFrom(
                                            backgroundColor: const Color(0xFF00D4FF).withValues(alpha: 0.15),
                                            padding: const EdgeInsets.all(6),
                                          ),
                                          icon: const Icon(Icons.sms_rounded, size: 16, color: Color(0xFF00D4FF)),
                                          tooltip: 'SMS Driver for street directions',
                                          onPressed: () => _sendSms(_driverPhone),
                                        ),
                                        const SizedBox(width: 4),
                                        IconButton(
                                          style: IconButton.styleFrom(
                                            padding: const EdgeInsets.all(6),
                                          ),
                                          icon: const Icon(Icons.copy_rounded, size: 14, color: Colors.white60),
                                          tooltip: 'Copy Driver Phone',
                                          onPressed: () {
                                            Clipboard.setData(ClipboardData(text: _driverPhone!));
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(
                                                content: Text('Driver phone copied to clipboard'),
                                                duration: Duration(seconds: 1),
                                              ),
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    const Text(
                                      'Call or SMS driver to guide street turns & gate access',
                                      style: TextStyle(fontSize: 10.5, color: Colors.white54),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ],
                        ),

                        if (_canTrackLive && !isTerminal) ...[
                          const SizedBox(height: 14),
                          SizedBox(
                            height: 46,
                            child: FilledButton.icon(
                              style: FilledButton.styleFrom(
                                backgroundColor: const Color(0xFF00D4FF),
                                foregroundColor: Colors.black,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              onPressed: _openLiveTracking,
                              icon: const Icon(Icons.radar_rounded, size: 20),
                              label: const Text(
                                'TRACK AMBULANCE RADAR LIVE',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 13,
                                  letterSpacing: 0.8,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ] else ...[
                  // Ambulance search state card
                  Container(
                    margin: const EdgeInsets.only(bottom: 14),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF07193F),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFF1E3A8A)),
                    ),
                    child: Row(
                      children: const [
                        SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFF334B)),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'AMBULANCE DISPATCH DESK',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF81D4FA)),
                              ),
                              SizedBox(height: 2),
                              Text(
                                'Central desk locating and assigning closest Solace ICU ambulance...',
                                style: TextStyle(fontSize: 12, color: Colors.white70),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                // 3. RECEIVING HOSPITAL CARD (Prominent End-to-End Transmission)
                if (_hospitalName != null) ...[
                  Container(
                    margin: const EdgeInsets.only(bottom: 14),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF072740),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF00ACC1), width: 1.4),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: const Color(0xFF00ACC1).withValues(alpha: 0.18),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.local_hospital_rounded,
                            color: Color(0xFF00ACC1),
                            size: 24,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'RECEIVING HOSPITAL (ASSIGNED)',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Color(0xFF80DEEA),
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.8,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                _hospitalName!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if (_hospitalAddress != null && _hospitalAddress!.isNotEmpty) ...[
                                const SizedBox(height: 3),
                                Text(
                                  _hospitalAddress!,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontSize: 11.5,
                                  ),
                                ),
                              ],
                              const SizedBox(height: 4),
                              const Text(
                                '🟢 Trauma Bay Alerted & Bed Reserved',
                                style: TextStyle(
                                  color: Color(0xFF00E676),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (_hospitalPhone != null && _hospitalPhone!.isNotEmpty)
                          IconButton(
                            style: IconButton.styleFrom(
                              backgroundColor: const Color(0xFF00ACC1).withValues(alpha: 0.2),
                              padding: const EdgeInsets.all(8),
                            ),
                            icon: const Icon(Icons.phone_in_talk_rounded, color: Color(0xFF00ACC1), size: 18),
                            tooltip: 'Call Hospital ER',
                            onPressed: () => _makeCall(_hospitalPhone),
                          ),
                      ],
                    ),
                  ),
                ] else ...[
                  // Hospital triage matching card
                  Container(
                    margin: const EdgeInsets.only(bottom: 14),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF07193F),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFF1E3A8A)),
                    ),
                    child: Row(
                      children: const [
                        SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF00D4FF)),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'RECEIVING HOSPITAL DESK',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF81D4FA)),
                              ),
                              SizedBox(height: 2),
                              Text(
                                'Central triage matching nearest verified emergency trauma hospital...',
                                style: TextStyle(fontSize: 12, color: Colors.white70),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                // 4. CENTRAL DISPATCH DESK & PICKUP LOCATION
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF07193F),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF1E3A8A)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.shield_rounded, color: Color(0xFF00E676), size: 16),
                          const SizedBox(width: 8),
                          const Expanded(
                            child: Text(
                              'SOLACE CENTRAL DISPATCH DESK • ACTIVE',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Color(0xFF00E676),
                                fontSize: 9.5,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                          Text(
                            'REF: #$_shortId',
                            style: const TextStyle(color: Colors.white54, fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.location_on_rounded, color: Color(0xFF00D4FF), size: 16),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _resolvedAddress ?? 'GPS Destination Verified',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 14),

                // 5. SOLELY QUICK FIRST AID TIPS (FOR PATIENT & BYSTANDERS)
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF07193F),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF00D4FF).withValues(alpha: 0.3)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: const [
                          Icon(Icons.medical_services_rounded, color: Color(0xFF00D4FF), size: 18),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'QUICK FIRST AID (WHILE WAITING FOR AMBULANCE)',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.6,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      _buildAidTip(
                        icon: Icons.air_rounded,
                        title: 'Airway & Recovery Position',
                        body: 'Keep airway open. If patient is breathing but drowsy or unconscious, gently roll them onto their side (Recovery Position). Never leave them face-down.',
                      ),
                      const SizedBox(height: 8),
                      _buildAidTip(
                        icon: Icons.healing_rounded,
                        title: 'Severe Bleeding Control',
                        body: 'Press a clean cloth or towel firmly and directly over the wound. Maintain continuous pressure with your hands. Do not remove soaked cloth; add more on top.',
                      ),
                      const SizedBox(height: 8),
                      _buildAidTip(
                        icon: Icons.favorite_rounded,
                        title: 'Chest Pain / Heart Distress',
                        body: 'Keep patient resting seated or half-upright. Loosen tight collar and chest clothing. Keep them calm and prevent any physical walking or exertion.',
                      ),
                      const SizedBox(height: 8),
                      _buildAidTip(
                        icon: Icons.warning_amber_rounded,
                        title: 'Crash / Spine Injury — Do Not Move',
                        body: 'Do NOT move or drag an accident patient unless there is immediate fire or explosion hazard. Support head and neck firmly in the position found.',
                      ),
                      const SizedBox(height: 8),
                      _buildAidTip(
                        icon: Icons.no_drinks_rounded,
                        title: 'No Food, Water, or Oral Meds',
                        body: 'Do NOT give water, food, or pills to an injured, drowsy, or seizing patient. Doing so can cause fatal airway choking and aspiration.',
                      ),
                      const SizedBox(height: 8),
                      _buildAidTip(
                        icon: Icons.record_voice_over_rounded,
                        title: 'Continuous Reassurance',
                        body: 'Speak calmly to the patient. Tell them Solace ambulance paramedics are en route. Continuously monitor their breathing until the crew arrives.',
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 18),

                // 6. EMERGENCY CANCELLATION (If still eligible)
                if (_canClientCancel && !isTerminal)
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.redAccent,
                      side: const BorderSide(color: Colors.redAccent, width: 1.2),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: _isCancelling ? null : _confirmAndCancelRequest,
                    icon: _isCancelling
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.redAccent,
                            ),
                          )
                        : const Icon(Icons.close_rounded, size: 18),
                    label: Text(
                      _isCancelling ? 'Cancelling Request...' : 'Cancel Emergency Request',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                  ),

                if (isTerminal)
                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF0D2559),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: _returnHome,
                    child: const Text('Return to Home Screen'),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAidTip({
    required IconData icon,
    required String title,
    required String body,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFF00D4FF), size: 16),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11.5,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 1),
              Text(
                body,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 10.5,
                  height: 1.35,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
