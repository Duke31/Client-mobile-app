import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'request_screen.dart';
import 'live_ambulance_tracking_screen.dart';

class SubmittedScreen extends StatefulWidget {
  final String? requestId;
  final double? latitude;
  final double? longitude;
  final String? address;
  final String? patientAddress;

  const SubmittedScreen({
    super.key,
    this.requestId,
    this.latitude,
    this.longitude,
    this.address,
    this.patientAddress,
  });

  @override
  State<SubmittedScreen> createState() => _SubmittedScreenState();
}

class _SubmittedScreenState extends State<SubmittedScreen>
    with SingleTickerProviderStateMixin {
  final SupabaseClient _supabase = Supabase.instance.client;
  String? _requestId;
  bool _isCancelling = false;
  String _currentStatus = 'Requested';
  String _actorRole = 'client';

  String? _hospitalName;
  String? _hospitalAddress;
  String? _driverName;
  String? _vehicleLabel;
  String? _driverPhone;

  Timer? _pollTimer;
  Timer? _autoCloseTimer;
  StreamSubscription<List<Map<String, dynamic>>>? _realtimeSub;

  late final AnimationController _radarController;
  late final Animation<double> _radarScale;
  late final Animation<double> _radarOpacity;

  String? get _resolvedAddress => widget.address ?? widget.patientAddress;

  bool get _isCompleted {
    final s = _currentStatus.toLowerCase();
    return s.contains('complete');
  }

  bool get _isCancelled {
    final s = _currentStatus.toLowerCase();
    return s.contains('cancel') || s.contains('fail');
  }

  bool get _canClientCancel {
    final s = _currentStatus.toLowerCase();
    return s == 'requested' || s == 'matching';
  }

  bool get _canTrackLive {
    final s = _currentStatus.toLowerCase();
    return s.contains('driver') ||
        s.contains('en route') ||
        s.contains('picked') ||
        s.contains('arrived') ||
        _driverName != null;
  }

  @override
  void initState() {
    super.initState();
    _requestId = widget.requestId;

    _radarController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat();

    _radarScale = Tween<double>(begin: 1.0, end: 1.5).animate(
      CurvedAnimation(parent: _radarController, curve: Curves.easeOutQuad),
    );

    _radarOpacity = Tween<double>(begin: 0.6, end: 0.0).animate(
      CurvedAnimation(parent: _radarController, curve: Curves.easeOutQuad),
    );

    _fetchUserRole();

    if (_requestId != null && _requestId!.isNotEmpty) {
      _startStatusMonitoring(_requestId!);
    } else {
      _fetchActiveRequestId();
    }
  }

  @override
  void dispose() {
    _radarController.dispose();
    _pollTimer?.cancel();
    _autoCloseTimer?.cancel();
    _realtimeSub?.cancel();
    super.dispose();
  }

  Future<void> _fetchUserRole() async {
    final uid = _supabase.auth.currentUser?.id;
    if (uid == null) return;
    try {
      final res = await _supabase
          .from('profiles')
          .select('role')
          .eq('user_id', uid)
          .maybeSingle();
      if (res != null && res['role'] != null && mounted) {
        setState(() {
          _actorRole = res['role'].toString();
        });
      }
    } catch (_) {}
  }

  void _stopMonitoring() {
    _pollTimer?.cancel();
    _pollTimer = null;
    _realtimeSub?.cancel();
    _realtimeSub = null;
  }

  void _startStatusMonitoring(String reqId) {
    _refreshStatus(reqId);
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _refreshStatus(reqId);
    });

    _realtimeSub?.cancel();
    try {
      _realtimeSub = _supabase
          .from('emergency_requests')
          .stream(primaryKey: ['id'])
          .eq('id', reqId)
          .listen((data) {
            if (data.isNotEmpty && mounted) {
              final newStatus = data.first['status']?.toString();
              if (newStatus != null && newStatus != _currentStatus) {
                _handleStatusChange(newStatus);
              }
              _refreshStatus(reqId);
            }
          }, onError: (_) {});
    } catch (_) {}
  }

  void _handleStatusChange(String newStatus) {
    setState(() {
      _currentStatus = newStatus;
    });

    if (_isCompleted || _isCancelled) {
      _stopMonitoring();
      if (_isCompleted) {
        _autoCloseTimer?.cancel();
        _autoCloseTimer = Timer(const Duration(seconds: 4), () {
          if (mounted) {
            _returnHome();
          }
        });
      }
    }
  }

  Future<void> _refreshStatus(String reqId) async {
    try {
      final req = await _supabase
          .from('emergency_requests')
          .select('id, status, hospital_id, driver_id, contact_phone')
          .eq('id', reqId)
          .maybeSingle();

      if (req == null || !mounted) return;

      final newStatus = req['status']?.toString();
      if (newStatus != null && newStatus != _currentStatus) {
        _handleStatusChange(newStatus);
      }

      final hospitalId = req['hospital_id']?.toString();
      final driverId = req['driver_id']?.toString();

      String? hName;
      String? hAddr;
      String? dName;
      String? vLabel;
      String? dPhone;

      if (hospitalId != null && hospitalId.isNotEmpty) {
        try {
          final hRes = await _supabase
              .from('hospitals')
              .select('name, address')
              .eq('id', hospitalId)
              .maybeSingle();
          if (hRes != null) {
            hName = hRes['name']?.toString();
            hAddr = hRes['address']?.toString();
          }
        } catch (_) {}
      }

      if (driverId != null && driverId.isNotEmpty) {
        try {
          final dRes = await _supabase
              .from('drivers')
              .select('full_name, vehicle_label, phone_number')
              .eq('id', driverId)
              .maybeSingle();
          if (dRes != null) {
            dName = dRes['full_name']?.toString() ?? 'Assigned Medic';
            vLabel = dRes['vehicle_label']?.toString() ?? 'Ambulance Unit';
            dPhone = dRes['phone_number']?.toString();
          }
        } catch (_) {}
      }

      if (mounted) {
        setState(() {
          _hospitalName = hName;
          _hospitalAddress = hAddr;
          _driverName = dName;
          _vehicleLabel = vLabel;
          _driverPhone = dPhone;
        });
      }
    } catch (_) {}
  }

  Future<void> _fetchActiveRequestId() async {
    try {
      final res = await _supabase
          .from('emergency_requests')
          .select('id, status')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (res != null && mounted) {
        final id = res['id']?.toString();
        setState(() {
          _requestId = id;
          if (res['status'] != null) {
            _currentStatus = res['status'].toString();
          }
        });
        if (id != null) {
          _startStatusMonitoring(id);
        }
      }
    } catch (_) {}
  }

  Future<void> _confirmAndCancelRequest() async {
    if (!_canClientCancel) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('A vehicle has already been dispatched. Contact dispatch directly to cancel.'),
          backgroundColor: Colors.amber,
        ),
      );
      return;
    }

    final bool? shouldCancel = await showDialog<bool>(
      context: context,
      barrierDismissible: !_isCancelling,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          backgroundColor: const Color(0xFF07193F),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: Color(0xFF1E3A8A)),
          ),
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
              SizedBox(width: 8),
              Text('Cancel Request?', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ],
          ),
          content: const Text(
            'Are you sure you want to cancel this emergency request? '
            'This will stop ambulance dispatch and emergency team coordination.',
            style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.4),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Keep Active', style: TextStyle(color: Color(0xFF00D4FF))),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFD32F2F),
                foregroundColor: Colors.white,
              ),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Yes, Cancel Request'),
            ),
          ],
        );
      },
    );

    if (shouldCancel == true && mounted) {
      await _executeCancelRpc();
    }
  }

  Future<void> _executeCancelRpc() async {
    final idToCancel = _requestId;
    if (idToCancel == null || idToCancel.isEmpty) return;

    setState(() => _isCancelling = true);
    try {
      await _supabase.rpc('transition_emergency_state', params: {
        'request_id': idToCancel,
        'new_state': 'Cancelled / failed',
        'actor_role': _actorRole,
      });
      if (!mounted) return;
      _returnHome();
    } catch (e) {
      if (!mounted) return;
      setState(() => _isCancelling = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cancel error: $e'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  void _openLiveTracking() {
    final id = _requestId;
    if (id == null || id.isEmpty) return;
    final lat = widget.latitude ?? 6.5244;
    final lng = widget.longitude ?? 3.3792;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => LiveAmbulanceTrackingScreen(
          requestId: id,
          patientLocation: LatLng(lat, lng),
          patientAddress: _resolvedAddress,
        ),
      ),
    );
  }

  void _returnHome() {
    _autoCloseTimer?.cancel();
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const RequestScreen()),
      (route) => false,
    );
  }

  Future<void> _callDriver() async {
    final phone = _driverPhone;
    if (phone == null || phone.isEmpty) return;
    final uri = Uri.parse('tel:$phone');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  String get _headlineText {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return 'Request Cancelled';
    if (s.contains('complete')) return 'Emergency Handled';
    if (s.contains('arrived')) return 'Ambulance At Your Location';
    if (s.contains('picked')) return 'Patient On Board';
    if (s.contains('driver') || s.contains('en route')) return 'Ambulance En Route';
    return 'Dispatching Nearest EMS Unit';
  }

  String get _descriptionText {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return 'This emergency request has been cancelled.';
    if (s.contains('complete')) return 'The emergency cycle has concluded safely.';
    if (s.contains('arrived')) return 'Paramedic crew has arrived at your pinpointed GPS location.';
    if (s.contains('picked')) return 'Patient is on board and navigating safely.';
    if (s.contains('driver') || s.contains('en route')) {
      return 'An emergency response unit is navigating directly to your GPS coordinates.';
    }
    return 'Your emergency has been received. Locating and alerting the nearest available Solace ambulance.';
  }

  @override
  Widget build(BuildContext context) {
    final displayId = _requestId;
    final shortId = (displayId != null && displayId.length > 8)
        ? displayId.substring(0, 8).toUpperCase()
        : (displayId?.toUpperCase() ?? 'PENDING');
    final isTerminal = _isCompleted || _isCancelled;

    return PopScope(
      canPop: isTerminal,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          _returnHome();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF061536),
        appBar: AppBar(
          backgroundColor: const Color(0xFF07193F),
          elevation: 0,
          leadingWidth: 44,
          leading: Padding(
            padding: const EdgeInsets.only(left: 12.0),
            child: Image.asset(
              'assets/images/solace_icon.png',
              height: 28,
              width: 28,
              errorBuilder: (_, __, ___) => const Icon(
                Icons.emergency_rounded,
                color: Color(0xFF00D4FF),
                size: 26,
              ),
            ),
          ),
          title: const Text(
            'SOLACE EMERGENCY',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: 15.5,
              letterSpacing: 1.1,
            ),
          ),
          actions: [
            Container(
              margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFF0D2559),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF00D4FF), width: 0.8),
              ),
              child: Text(
                '#$shortId',
                style: const TextStyle(
                  color: Color(0xFF00D4FF),
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.8,
                ),
              ),
            ),
          ],
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // 1. DYNAMIC PULSING STATUS / RADAR CARD
                Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Animated pulse ring
                      if (!_isCancelled)
                        AnimatedBuilder(
                          animation: _radarController,
                          builder: (context, child) {
                            return Transform.scale(
                              scale: _radarScale.value,
                              child: Container(
                                width: 120,
                                height: 120,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: (_canTrackLive
                                          ? const Color(0xFF00D4FF)
                                          : const Color(0xFFFF334B))
                                      .withValues(alpha: _radarOpacity.value),
                                ),
                              ),
                            );
                          },
                        ),

                      Container(
                        width: 90,
                        height: 90,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF07193F),
                          border: Border.all(
                            color: _canTrackLive
                                ? const Color(0xFF00D4FF)
                                : const Color(0xFFFF334B),
                            width: 2.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: (_canTrackLive
                                      ? const Color(0xFF00D4FF)
                                      : const Color(0xFFFF334B))
                                  .withValues(alpha: 0.3),
                              blurRadius: 16,
                            ),
                          ],
                        ),
                        child: Icon(
                          _canTrackLive
                              ? Icons.directions_car_rounded
                              : (_isCancelled
                                  ? Icons.cancel_outlined
                                  : Icons.sensors_rounded),
                          size: 44,
                          color: _canTrackLive
                              ? const Color(0xFF00D4FF)
                              : (_isCancelled ? Colors.redAccent : const Color(0xFFFF334B)),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Headline
                Text(
                  _headlineText,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 6),

                // Description
                Text(
                  _descriptionText,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12.5,
                    height: 1.4,
                  ),
                ),

                const SizedBox(height: 24),

                // 2. LIVE AMBULANCE TRACKER CARD (If responder assigned)
                if (_canTrackLive && !isTerminal) ...[
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          const Color(0xFF0D2559),
                          const Color(0xFF07193F),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF00D4FF), width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF00D4FF).withValues(alpha: 0.15),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: const Color(0xFF00D4FF).withValues(alpha: 0.15),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.airport_shuttle_rounded,
                                color: Color(0xFF00D4FF),
                                size: 24,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _vehicleLabel ?? 'Ambulance Response Unit',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    'Driver: ${_driverName ?? "Assigned Paramedic"}',
                                    style: const TextStyle(
                                      color: Color(0xFF81D4FA),
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            if (_driverPhone != null && _driverPhone!.isNotEmpty)
                              IconButton.filled(
                                style: IconButton.filled(
                                  backgroundColor: const Color(0xFF00E676).withValues(alpha: 0.2),
                                ),
                                icon: const Icon(Icons.phone_rounded, color: Color(0xFF00E676)),
                                tooltip: 'Call Driver',
                                onPressed: _callDriver,
                              ),
                          ],
                        ),
                        const SizedBox(height: 14),

                        // Large Track Live Button
                        SizedBox(
                          width: double.infinity,
                          height: 48,
                          child: FilledButton.icon(
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF00D4FF),
                              foregroundColor: Colors.black,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            onPressed: _openLiveTracking,
                            icon: const Icon(Icons.radar_rounded, size: 20),
                            label: const Text(
                              'OPEN LIVE RADAR TRACKER',
                              style: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                // 3. PICKUP LOCATION CARD
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF07193F),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF1E3A8A)),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF00D4FF).withValues(alpha: 0.15),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.location_on_rounded,
                          color: Color(0xFF00D4FF),
                          size: 18,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'VERIFIED DISPATCH DESTINATION',
                              style: TextStyle(
                                color: Color(0xFF81D4FA),
                                fontSize: 9.5,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.8,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _resolvedAddress ?? 'GPS Pinpoint Verified',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 14),

                // 4. EMERGENCY PROTOCOL ADVICE CARD
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF07193F),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Row(
                        children: [
                          Icon(Icons.shield_outlined, color: Color(0xFF00D4FF), size: 16),
                          SizedBox(width: 8),
                          Text(
                            'WHILE AWAITING CREW ARRIVAL',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Text(
                        '• Keep this app and phone line open for dispatch calls.\n'
                        '• Paramedics are navigating directly to your GPS coordinates.\n'
                        '• If safe, turn on exterior lights or unlock the front door.\n'
                        '• Have patient medication and medical ID ready for the crew.',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 11.5,
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // 5. CANCEL BUTTON (If eligible)
                if (_canClientCancel && !isTerminal)
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.redAccent,
                      side: const BorderSide(color: Colors.redAccent, width: 1.2),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: _isCancelling ? null : _confirmAndCancelRequest,
                    icon: _isCancelling
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.redAccent,
                            ),
                          )
                        : const Icon(Icons.close_rounded, size: 18),
                    label: Text(
                      _isCancelling ? 'Cancelling Request...' : 'Cancel Emergency Request',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                  ),

                if (isTerminal)
                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF0D2559),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: _returnHome,
                    child: const Text('Return to Home Screen'),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
