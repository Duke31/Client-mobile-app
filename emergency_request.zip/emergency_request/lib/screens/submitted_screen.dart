import 'package:flutter/material.dart';

import '../maps/mapbox_map_view.dart';

class SubmittedScreen extends StatelessWidget {
  const SubmittedScreen({
    super.key,
    required this.latitude,
    required this.longitude,
    required this.address,
  });

  final double latitude;
  final double longitude;
  final String address;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Request sent')),
      body: Column(
        children: <Widget>[
          Expanded(
            child: MapboxMapView.patientLocation(
              latitude: latitude,
              longitude: longitude,
              interactive: false,
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(
                    'Help is being notified',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(address),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () {
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    },
                    child: const Text('Back to home'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
