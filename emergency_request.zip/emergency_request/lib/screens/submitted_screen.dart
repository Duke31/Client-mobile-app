import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SubmittedScreen extends StatefulWidget {
  final String? requestId;
  final double? latitude;
  final double? longitude;
  final String? address;
  final String? patientAddress;

  const SubmittedScreen({
    super.key,
    this.requestId,
    this.latitude,
    this.longitude,
    this.address,
    this.patientAddress,
  });

  @override
  State<SubmittedScreen> createState() => _SubmittedScreenState();
}

class _SubmittedScreenState extends State<SubmittedScreen> {
  final SupabaseClient _supabase = Supabase.instance.client;

  String? _requestId;
  bool _isCancelling = false;
  String _currentStatus = 'Requested';

  Timer? _pollTimer;
  StreamSubscription<List<Map<String, dynamic>>>? _realtimeSub;

  String? get _resolvedAddress => widget.address ?? widget.patientAddress;

  bool get _canClientCancel {
    final s = _currentStatus.toLowerCase();
    return s == 'requested' || s == 'matching';
  }

  @override
  void initState() {
    super.initState();
    _requestId = widget.requestId;

    if (_requestId != null && _requestId!.isNotEmpty) {
      _startStatusMonitoring(_requestId!);
    } else {
      _fetchActiveRequestId();
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _realtimeSub?.cancel();
    super.dispose();
  }

  void _startStatusMonitoring(String reqId) {
    // 1. Initial immediate poll
    _refreshStatus(reqId);

    // 2. Poll every 3 seconds (reliable across all mobile networks)
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _refreshStatus(reqId);
    });

    // 3. Optional realtime stream if supabase_realtime is enabled
    _realtimeSub?.cancel();
    try {
      _realtimeSub = _supabase
          .from('emergency_requests')
          .stream(primaryKey: ['id'])
          .eq('id', reqId)
          .listen((data) {
            if (data.isNotEmpty && mounted) {
              final newStatus = data.first['status']?.toString();
              if (newStatus != null && newStatus != _currentStatus) {
                setState(() => _currentStatus = newStatus);
              }
            }
          }, onError: (e) {
            debugPrint('Realtime stream inactive (falling back to polling): $e');
          });
    } catch (_) {}
  }

  Future<void> _refreshStatus(String reqId) async {
    try {
      final res = await _supabase
          .from('emergency_requests')
          .select('id, status')
          .eq('id', reqId)
          .maybeSingle();

      if (res != null && mounted) {
        final newStatus = res['status']?.toString();
        if (newStatus != null && newStatus != _currentStatus) {
          setState(() {
            _currentStatus = newStatus;
          });
        }
      }
    } catch (e) {
      debugPrint('Status poll error: $e');
    }
  }

  Future<void> _fetchActiveRequestId() async {
    try {
      final res = await _supabase
          .from('emergency_requests')
          .select('id, status')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (res != null && mounted) {
        final id = res['id']?.toString();
        setState(() {
          _requestId = id;
          if (res['status'] != null) {
            _currentStatus = res['status'].toString();
          }
        });
        if (id != null) {
          _startStatusMonitoring(id);
        }
      }
    } catch (e) {
      debugPrint('Error finding active ticket: $e');
    }
  }

  Future<void> _confirmAndCancelRequest() async {
    if (!_canClientCancel) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('A vehicle or hospital has already been assigned. Please contact dispatch to cancel.'),
          backgroundColor: Colors.amber,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final bool? shouldCancel = await showDialog<bool>(
      context: context,
      barrierDismissible: !_isCancelling,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
              SizedBox(width: 8),
              Text('Cancel Request?'),
            ],
          ),
          content: const Text(
            'Are you sure you want to cancel this emergency request? '
            'This will stop hospital notification and dispatch coordination.',
            style: TextStyle(fontSize: 14, height: 1.4),
          ),
          actionsPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Keep Active'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                foregroundColor: Colors.white,
              ),
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Yes, Cancel Request'),
            ),
          ],
        );
      },
    );

    if (shouldCancel == true && mounted) {
      await _executeCancelRpc();
    }
  }

  Future<void> _executeCancelRpc() async {
    final idToCancel = _requestId;
    if (idToCancel == null || idToCancel.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Cannot locate request ticket.'),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() => _isCancelling = true);

    try {
      try {
        await _supabase.rpc('transition_emergency_state', params: {
          'request_id': idToCancel,
          'new_state': 'Cancelled / failed',
          'actor_role': 'client',
        });
      } catch (_) {
        await _supabase.rpc('transition_emergency_state', params: {
          'p_request_id': idToCancel,
          'p_new_state': 'Cancelled',
          'p_actor_role': 'client',
        });
      }

      if (!mounted) return;
      Navigator.of(context).pop();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Emergency request has been cancelled.'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } on PostgrestException catch (e) {
      if (!mounted) return;
      setState(() => _isCancelling = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cancel failed: ${e.message}'),
          backgroundColor: Colors.red.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isCancelling = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red.shade800,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  // Dynamic UI helpers for each lifecycle state
  String get _headlineText {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return 'Request Cancelled';
    if (s.contains('hospital') || s.contains('confirm')) return 'Hospital Confirmed';
    if (s.contains('driver') || s.contains('assign')) return 'Driver Assigned';
    if (s.contains('patient picked')) return 'Patient Picked Up';
    if (s.contains('en route')) return 'Responder En Route';
    if (s.contains('arrived') || s.contains('intake')) return 'Arrived at Hospital';
    if (s.contains('complete')) return 'Emergency Handled';
    return 'Help is being notified';
  }

  String get _descriptionText {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return 'This request was cancelled.';
    if (s.contains('hospital') || s.contains('confirm')) {
      return 'A partner hospital has accepted your request and is preparing intake.';
    }
    if (s.contains('driver') || s.contains('assign')) {
      return 'A medical transport driver has been assigned and dispatched.';
    }
    if (s.contains('patient picked')) {
      return 'Patient is safely on board and heading to the confirmed hospital.';
    }
    if (s.contains('en route')) {
      return 'The assigned emergency transport is currently navigating to your location.';
    }
    if (s.contains('arrived') || s.contains('intake')) {
      return 'Patient has arrived at the hospital intake department.';
    }
    if (s.contains('complete')) return 'The emergency cycle has concluded.';
    return 'Your dispatch request is being broadcast to nearby verified hospitals and response teams.';
  }

  IconData get _statusIcon {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return Icons.cancel_outlined;
    if (s.contains('hospital')) return Icons.local_hospital_outlined;
    if (s.contains('driver') || s.contains('route')) return Icons.directions_car_outlined;
    if (s.contains('arrived')) return Icons.domain_verification_outlined;
    if (s.contains('complete')) return Icons.check_circle_outline;
    return Icons.notifications_active_outlined;
  }

  Color get _statusColor {
    final s = _currentStatus.toLowerCase();
    if (s.contains('cancel')) return Colors.red;
    if (s.contains('hospital') || s.contains('driver') || s.contains('route')) return Colors.teal;
    if (s.contains('complete') || s.contains('arrived')) return Colors.green;
    return Colors.amber;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final displayId = _requestId;
    final shortId = (displayId != null && displayId.length > 8)
        ? displayId.substring(0, 8).toUpperCase()
        : (displayId?.toUpperCase() ?? 'Connecting...');

    final color = _statusColor;

    return WillPopScope(
      onWillPop: () async {
        final confirmExit = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Leave Screen?'),
            content: const Text(
              'Your request is active. Leaving this screen will not cancel dispatch coordination.',
            ),
            actions: [
              TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Stay')),
              TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Leave')),
            ],
          ),
        );
        return confirmExit ?? false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Emergency Status'),
          centerTitle: true,
          automaticallyImplyLeading: false,
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Spacer(flex: 1),

                // Dynamic Status Icon
                Center(
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    padding: const EdgeInsets.all(28),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color.withOpacity(0.1),
                      border: Border.all(color: color.withOpacity(0.4), width: 2.5),
                    ),
                    child: Icon(
                      _statusIcon,
                      size: 56,
                      color: color is MaterialColor ? color.shade800 : color,
                    ),
                  ),
                ),

                const SizedBox(height: 28),

                Text(
                  _headlineText,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),

                const SizedBox(height: 10),

                Text(
                  _descriptionText,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.grey.shade600,
                    height: 1.4,
                  ),
                ),

                const SizedBox(height: 32),

                // Request Information Card
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Request Reference', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                          InkWell(
                            onTap: displayId != null
                                ? () {
                                    Clipboard.setData(ClipboardData(text: displayId));
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Copied to clipboard'), duration: Duration(seconds: 1)),
                                    );
                                  }
                                : null,
                            child: Row(
                              children: [
                                Text('#$shortId', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                                if (displayId != null) ...[
                                  const SizedBox(width: 4),
                                  Icon(Icons.copy_rounded, size: 14, color: Colors.grey.shade600),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Current Lifecycle State', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: color.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: color.withOpacity(0.35)),
                            ),
                            child: Text(
                              _currentStatus,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: color is MaterialColor ? color.shade800 : color,
                              ),
                            ),
                          ),
                        ],
                      ),
                      if (_resolvedAddress != null || widget.latitude != null) ...[
                        const Divider(height: 20),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Location', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                            const SizedBox(width: 16),
                            Flexible(
                              child: Text(
                                _resolvedAddress ?? '${widget.latitude?.toStringAsFixed(5)}, ${widget.longitude?.toStringAsFixed(5)}',
                                textAlign: TextAlign.right,
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),

                const Spacer(flex: 2),

                // Cancellation Action
                if (!_canClientCancel)
                  Container(
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.amber.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.amber.shade300),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, size: 18, color: Colors.amber.shade900),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '$_currentStatus: Response is in progress. Please contact dispatch if you need to cancel.',
                            style: TextStyle(fontSize: 12, color: Colors.amber.shade900),
                          ),
                        ),
                      ],
                    ),
                  )
                else
                  OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      foregroundColor: Colors.red.shade700,
                      side: BorderSide(color: Colors.red.shade300, width: 1.5),
                      backgroundColor: Colors.red.shade50,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _isCancelling ? null : _confirmAndCancelRequest,
                    icon: _isCancelling
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.red),
                          )
                        : const Icon(Icons.close_rounded, size: 20),
                    label: Text(
                      _isCancelling ? 'Cancelling...' : 'Cancel Emergency Request',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                  ),

                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}