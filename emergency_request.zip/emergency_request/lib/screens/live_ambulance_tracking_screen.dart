import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;

class LiveAmbulanceTrackingScreen extends StatefulWidget {
  final String requestId;
  final LatLng patientLocation;
  final String? patientAddress;
  final String? mapboxAccessToken;

  const LiveAmbulanceTrackingScreen({
    super.key,
    required this.requestId,
    required this.patientLocation,
    this.patientAddress,
    this.mapboxAccessToken,
  });

  @override
  State<LiveAmbulanceTrackingScreen> createState() =>
      _LiveAmbulanceTrackingScreenState();
}

class _LiveAmbulanceTrackingScreenState
    extends State<LiveAmbulanceTrackingScreen>
    with SingleTickerProviderStateMixin {
  final MapController _mapController = MapController();
  final SupabaseClient _supabase = Supabase.instance.client;

  RealtimeChannel? _trackingChannel;
  RealtimeChannel? _driverDbChannel;
  Timer? _pollingTimer;

  String? _driverId;
  String? _driverName;
  String? _vehicleLabel;
  double _currentSpeedKmH = 0.0;
  String _missionStatus = "Driver Assigned";

  LatLng? _previousPos;
  LatLng? _targetPos;
  double _vehicleHeading = 0.0;

  late AnimationController _animController;
  late Animation<double> _latAnimation;
  late Animation<double> _lngAnimation;
  late Animation<double> _headingAnimation;

  int? _etaMinutes;
  double? _distanceKm;
  List<LatLng> _routePoints = [];
  Timer? _etaDebounceTimer;
  bool _hasFittedBounds = false;

  @override
  void initState() {
    super.initState();

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    );

    _latAnimation = Tween<double>(
      begin: widget.patientLocation.latitude,
      end: widget.patientLocation.latitude,
    ).animate(_animController);

    _lngAnimation = Tween<double>(
      begin: widget.patientLocation.longitude,
      end: widget.patientLocation.longitude,
    ).animate(_animController);

    _headingAnimation = Tween<double>(begin: 0, end: 0).animate(_animController);

    _loadData();
    _subscribeToBroadcast();

    // Polling fallback every 3 seconds for rock-solid stability on mobile connections
    _pollingTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      _pollDriverLocation();
    });
  }

  @override
  void dispose() {
    _animController.dispose();
    _pollingTimer?.cancel();
    _etaDebounceTimer?.cancel();
    if (_trackingChannel != null) _supabase.removeChannel(_trackingChannel!);
    if (_driverDbChannel != null) _supabase.removeChannel(_driverDbChannel!);
    super.dispose();
  }

  // 1. Initial Load: Fetch request, find driver, fetch driver coordinates
  Future<void> _loadData() async {
    try {
      final req = await _supabase
          .from('emergency_requests')
          .select('status, driver_id')
          .eq('id', widget.requestId)
          .maybeSingle();

      if (req != null && mounted) {
        final status = req['status']?.toString() ?? "Driver Assigned";
        final driverId = req['driver_id']?.toString();

        setState(() {
          _missionStatus = status;
          _driverId = driverId;
        });

        if (driverId != null && driverId.isNotEmpty) {
          _fetchDriverDetails(driverId);
          _listenToDriverDbUpdates(driverId);
        }
      }
    } catch (e) {
      debugPrint("Error loading emergency request data: $e");
    }
  }

  Future<void> _fetchDriverDetails(String driverId) async {
    try {
      final d = await _supabase
          .from('drivers')
          .select('*')
          .eq('id', driverId)
          .maybeSingle();

      if (d != null && mounted) {
        final name = d['display_name']?.toString() ??
            d['full_name']?.toString() ??
            d['name']?.toString() ??
            "Ambulance Unit";

        final vehicle = d['vehicle_label']?.toString() ??
            d['vehicle_plate']?.toString() ??
            "Rapid Response Vehicle";

        final lat = (d['current_lat'] as num?)?.toDouble();
        final lng = (d['current_lng'] as num?)?.toDouble();
        final heading = (d['heading'] as num?)?.toDouble() ?? 0.0;
        final speed = (d['speed'] as num?)?.toDouble() ?? 0.0;

        setState(() {
          _driverName = name;
          _vehicleLabel = vehicle;
        });

        if (lat != null && lng != null) {
          _applyNewDriverPosition(
            newPos: LatLng(lat, lng),
            heading: heading,
            speedMps: speed,
            driverName: name,
            vehicleLabel: vehicle,
          );
        }
      }
    } catch (e) {
      debugPrint("Error loading driver details: $e");
    }
  }

  // 2. Continuous fallback poller
  Future<void> _pollDriverLocation() async {
    if (_driverId == null || _driverId!.isEmpty) {
      _loadData();
      return;
    }

    try {
      final d = await _supabase
          .from('drivers')
          .select('current_lat, current_lng, heading, speed, display_name, vehicle_label')
          .eq('id', _driverId!)
          .maybeSingle();

      if (d != null && mounted) {
        final lat = (d['current_lat'] as num?)?.toDouble();
        final lng = (d['current_lng'] as num?)?.toDouble();
        final heading = (d['heading'] as num?)?.toDouble() ?? _vehicleHeading;
        final speed = (d['speed'] as num?)?.toDouble() ?? 0.0;

        if (lat != null && lng != null) {
          _applyNewDriverPosition(
            newPos: LatLng(lat, lng),
            heading: heading,
            speedMps: speed,
            driverName: d['display_name']?.toString(),
            vehicleLabel: d['vehicle_label']?.toString(),
          );
        }
      }
    } catch (e) {
      debugPrint("Driver poll error: $e");
    }
  }

  // 3. Realtime Broadcast Listener from DriverConsole.tsx
  void _subscribeToBroadcast() {
    _trackingChannel = _supabase
        .channel('request-tracking:${widget.requestId}')
        .onBroadcast(
          event: 'location_update',
          callback: (payload) {
            final lat = (payload['lat'] as num?)?.toDouble();
            final lng = (payload['lng'] as num?)?.toDouble();
            final heading = (payload['heading'] as num?)?.toDouble() ?? _vehicleHeading;
            final speed = (payload['speed'] as num?)?.toDouble() ?? 0.0;
            final driverName = payload['driver_name']?.toString();
            final vehicleLabel = payload['vehicle_label']?.toString();

            if (lat != null && lng != null && mounted) {
              _applyNewDriverPosition(
                newPos: LatLng(lat, lng),
                heading: heading,
                speedMps: speed,
                driverName: driverName,
                vehicleLabel: vehicleLabel,
              );
            }
          },
        )
        .subscribe();
  }

  // 4. Realtime Postgres Changes Listener on Drivers Table
  void _listenToDriverDbUpdates(String driverId) {
    _driverDbChannel = _supabase
        .channel('driver-db-sync:$driverId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'drivers',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: driverId,
          ),
          callback: (payload) {
            final rec = payload.newRecord;
            final lat = (rec['current_lat'] as num?)?.toDouble();
            final lng = (rec['current_lng'] as num?)?.toDouble();
            final heading = (rec['heading'] as num?)?.toDouble() ?? _vehicleHeading;
            final speed = (rec['speed'] as num?)?.toDouble() ?? 0.0;

            if (lat != null && lng != null && mounted) {
              _applyNewDriverPosition(
                newPos: LatLng(lat, lng),
                heading: heading,
                speedMps: speed,
              );
            }
          },
        )
        .subscribe();
  }

  // 5. Smooth animated transition between coordinates
  void _applyNewDriverPosition({
    required LatLng newPos,
    required double heading,
    required double speedMps,
    String? driverName,
    String? vehicleLabel,
  }) {
    final startPos = _targetPos ?? newPos;

    setState(() {
      if (driverName != null) _driverName = driverName;
      if (vehicleLabel != null) _vehicleLabel = vehicleLabel;
      _currentSpeedKmH = (speedMps * 3.6).clamp(0.0, 160.0);
      _targetPos = newPos;
    });

    _latAnimation = Tween<double>(
      begin: startPos.latitude,
      end: newPos.latitude,
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.easeInOut));

    _lngAnimation = Tween<double>(
      begin: startPos.longitude,
      end: newPos.longitude,
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.easeInOut));

    double startHeading = _vehicleHeading;
    double endHeading = heading;
    if ((endHeading - startHeading).abs() > 180) {
      if (endHeading > startHeading) {
        startHeading += 360;
      } else {
        endHeading += 360;
      }
    }

    _headingAnimation = Tween<double>(
      begin: startHeading,
      end: endHeading,
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.easeOut));

    _animController.reset();
    _animController.forward();

    _previousPos = startPos;
    _vehicleHeading = heading % 360;

    // Center map to show both markers on first GPS fix
    if (!_hasFittedBounds) {
      _hasFittedBounds = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _fitMapBounds(newPos, widget.patientLocation);
      });
    }

    // Debounced ETA recalculation
    _etaDebounceTimer?.cancel();
    _etaDebounceTimer = Timer(const Duration(seconds: 3), () {
      _recalculateLiveETA(newPos);
    });
  }

  void _fitMapBounds(LatLng p1, LatLng p2) {
    try {
      final bounds = LatLngBounds.fromPoints([p1, p2]);
      _mapController.fitCamera(
        CameraFit.bounds(
          bounds: bounds,
          padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 120),
        ),
      );
    } catch (_) {}
  }

  // 6. Dynamic ETA Calculation
  Future<void> _recalculateLiveETA(LatLng driverPos) async {
    // 1. Try Mapbox Directions API if access token provided
    if (widget.mapboxAccessToken != null && widget.mapboxAccessToken!.isNotEmpty) {
      try {
        final url = Uri.parse(
          'https://api.mapbox.com/directions/v5/mapbox/driving/'
          '${driverPos.longitude},${driverPos.latitude};'
          '${widget.patientLocation.longitude},${widget.patientLocation.latitude}'
          '?geometries=geojson&overview=full&access_token=${widget.mapboxAccessToken}',
        );

        final res = await http.get(url);
        if (res.statusCode == 200) {
          final data = json.decode(res.body);
          final route = data['routes'][0];
          final durationSec = (route['duration'] as num).toDouble();
          final distanceM = (route['distance'] as num).toDouble();

          final geometry = route['geometry']['coordinates'] as List;
          final polyline = geometry
              .map((c) => LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()))
              .toList();

          if (mounted) {
            setState(() {
              _etaMinutes = (durationSec / 60).ceil();
              _distanceKm = distanceM / 1000;
              _routePoints = polyline;
            });
          }
          return;
        }
      } catch (e) {
        debugPrint("Mapbox Directions API fallback: $e");
      }
    }

    // 2. Haversine distance with realistic 35 km/h urban response speed
    const Distance distance = Distance();
    final meters = distance.as(LengthUnit.Meter, driverPos, widget.patientLocation);
    final km = meters / 1000;
    final minutes = ((km / 35.0) * 60).ceil().clamp(1, 120);

    if (mounted) {
      setState(() {
        _distanceKm = km;
        _etaMinutes = minutes;
        _routePoints = [driverPos, widget.patientLocation];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // 1. Map Renderer
          AnimatedBuilder(
            animation: _animController,
            builder: (context, child) {
              final currentLat = _targetPos != null && _animController.isAnimating
                  ? _latAnimation.value
                  : _targetPos?.latitude ?? widget.patientLocation.latitude;
              final currentLng = _targetPos != null && _animController.isAnimating
                  ? _lngAnimation.value
                  : _targetPos?.longitude ?? widget.patientLocation.longitude;
              final animatedHeading = _animController.isAnimating
                  ? _headingAnimation.value
                  : _vehicleHeading;

              final currentDriverPos = LatLng(currentLat, currentLng);

              return FlutterMap(
                mapController: _mapController,
                options: MapOptions(
                  initialCenter: widget.patientLocation,
                  initialZoom: 15.0,
                ),
                children: [
                  TileLayer(
                    urlTemplate: widget.mapboxAccessToken != null && widget.mapboxAccessToken!.isNotEmpty
                        ? 'https://api.mapbox.com/styles/v1/mapbox/streets-v12/tiles/{z}/{x}/{y}?access_token=${widget.mapboxAccessToken}'
                        : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.emergency.emergency_request',
                  ),

                  // Route Line
                  if (_routePoints.isNotEmpty)
                    PolylineLayer(
                      polylines: [
                        Polyline(
                          points: _routePoints,
                          color: const Color(0xFF2563EB),
                          strokeWidth: 4.5,
                        ),
                      ],
                    ),

                  MarkerLayer(
                    markers: [
                      // Patient Destination Pin
                      Marker(
                        point: widget.patientLocation,
                        width: 50,
                        height: 50,
                        child: const Icon(
                          Icons.location_on_rounded,
                          color: Colors.redAccent,
                          size: 44,
                        ),
                      ),

                      // Animated Ambulance Marker
                      if (_targetPos != null)
                        Marker(
                          point: currentDriverPos,
                          width: 56,
                          height: 56,
                          child: Transform.rotate(
                            angle: (animatedHeading * (math.pi / 180)),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.25),
                                    blurRadius: 8,
                                    offset: const Offset(0, 3),
                                  ),
                                ],
                              ),
                              padding: const EdgeInsets.all(8),
                              child: const Icon(
                                Icons.emergency_rounded,
                                color: Color(0xFFDC2626),
                                size: 30,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              );
            },
          ),

          // 2. Back Button & Status Header
          Positioned(
            top: MediaQuery.of(context).padding.top + 10,
            left: 16,
            right: 16,
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: Colors.white,
                  radius: 20,
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.black87, size: 20),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.12),
                          blurRadius: 10,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        const SizedBox(
                          width: 12,
                          height: 12,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            color: Color(0xFF16A34A),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            _missionStatus.toUpperCase(),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                              letterSpacing: 0.8,
                              color: Color(0xFF0F172A),
                            ),
                          ),
                        ),
                        if (_currentSpeedKmH > 0)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF1F5F9),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              "${_currentSpeedKmH.toStringAsFixed(0)} km/h",
                              style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF475569),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 3. Floating Bottom Arrival Card
          Positioned(
            bottom: 24,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 18,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "ESTIMATED ARRIVAL",
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.9,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _etaMinutes != null ? "$_etaMinutes mins" : "Locating Unit…",
                            style: const TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF0F172A),
                            ),
                          ),
                        ],
                      ),
                      if (_distanceKm != null)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEFF6FF),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: const Color(0xFFBFDBFE)),
                          ),
                          child: Text(
                            "${_distanceKm!.toStringAsFixed(1)} km away",
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF1D4ED8),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const Divider(height: 22),
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 20,
                        backgroundColor: const Color(0xFF046A38).withOpacity(0.12),
                        child: const Icon(
                          Icons.local_shipping_rounded,
                          color: Color(0xFF046A38),
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _driverName ?? "Assigned Ambulance Unit",
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF0F172A),
                              ),
                            ),
                            Text(
                              _vehicleLabel ?? "Rapid Response Vehicle",
                              style: const TextStyle(
                                fontSize: 12,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (_targetPos != null)
                        IconButton(
                          icon: const Icon(Icons.my_location_rounded, color: Color(0xFF2563EB)),
                          onPressed: () {
                            _fitMapBounds(_targetPos!, widget.patientLocation);
                          },
                          tooltip: "Re-center",
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}