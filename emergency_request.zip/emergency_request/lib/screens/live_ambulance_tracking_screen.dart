import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;

class LiveAmbulanceTrackingScreen extends StatefulWidget {
  final String requestId;
  final LatLng patientLocation;
  final String? patientAddress;
  final String? mapboxAccessToken;

  const LiveAmbulanceTrackingScreen({
    super.key,
    required this.requestId,
    required this.patientLocation,
    this.patientAddress,
    this.mapboxAccessToken,
  });

  @override
  State<LiveAmbulanceTrackingScreen> createState() =>
      _LiveAmbulanceTrackingScreenState();
}

class _LiveAmbulanceTrackingScreenState
    extends State<LiveAmbulanceTrackingScreen>
    with SingleTickerProviderStateMixin {
  final MapController _mapController = MapController();
  RealtimeChannel? _trackingChannel;

  String? _driverName;
  String? _vehicleLabel;
  double _currentSpeedKmH = 0.0;
  String _missionStatus = "Ambulance Dispatched";

  LatLng? _previousPos;
  LatLng? _targetPos;
  double _vehicleHeading = 0.0;
  
  late AnimationController _animController;
  late Animation<double> _latAnimation;
  late Animation<double> _lngAnimation;
  late Animation<double> _headingAnimation;

  int? _etaMinutes;
  double? _distanceKm;
  List<LatLng> _routePoints = [];
  Timer? _etaDebounceTimer;

  @override
  void initState() {
    super.initState();

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    );

    _initialLoadDriverPosition();
    _subscribeToDriverTelemetry();
  }

  @override
  void dispose() {
    _animController.dispose();
    _etaDebounceTimer?.cancel();
    if (_trackingChannel != null) {
      Supabase.instance.client.removeChannel(_trackingChannel!);
    }
    super.dispose();
  }

  Future<void> _initialLoadDriverPosition() async {
    try {
      final reqRes = await Supabase.instance.client
          .from('emergency_requests')
          .select('status, driver_id, driver:drivers(display_name, vehicle_label, current_lat, current_lng, heading)')
          .eq('id', widget.requestId)
          .maybeSingle();

      if (reqRes != null && mounted) {
        setState(() {
          _missionStatus = reqRes['status'] ?? "Ambulance Dispatched";
        });

        final driver = reqRes['driver'] as Map<String, dynamic>?;
        if (driver != null) {
          final lat = driver['current_lat'] as num?;
          final lng = driver['current_lng'] as num?;
          final heading = (driver['heading'] as num?)?.toDouble() ?? 0.0;

          if (lat != null && lng != null) {
            final initialPos = LatLng(lat.toDouble(), lng.toDouble());
            setState(() {
              _driverName = driver['display_name'];
              _vehicleLabel = driver['vehicle_label'];
              _previousPos = initialPos;
              _targetPos = initialPos;
              _vehicleHeading = heading;
            });
            _recalculateLiveETA(initialPos);
          }
        }
      }
    } catch (e) {
      debugPrint("Error loading initial driver position: $e");
    }
  }

  void _subscribeToDriverTelemetry() {
    _trackingChannel = Supabase.instance.client
        .channel('request-tracking:${widget.requestId}')
        .onBroadcast(
          event: 'location_update',
          callback: (payload) {
            final lat = (payload['lat'] as num?)?.toDouble();
            final lng = (payload['lng'] as num?)?.toDouble();
            final heading = (payload['heading'] as num?)?.toDouble() ?? _vehicleHeading;
            final speed = (payload['speed'] as num?)?.toDouble() ?? 0.0;
            final driverName = payload['driver_name'] as String?;
            final vehicleLabel = payload['vehicle_label'] as String?;

            if (lat != null && lng != null && mounted) {
              _onNewGpsCoordinate(
                newPos: LatLng(lat, lng),
                heading: heading,
                speedMps: speed,
                driverName: driverName,
                vehicleLabel: vehicleLabel,
              );
            }
          },
        )
        .subscribe();
  }

  void _onNewGpsCoordinate({
    required LatLng newPos,
    required double heading,
    required double speedMps,
    String? driverName,
    String? vehicleLabel,
  }) {
    final startPos = _previousPos ?? newPos;

    setState(() {
      _driverName = driverName ?? _driverName;
      _vehicleLabel = vehicleLabel ?? _vehicleLabel;
      _currentSpeedKmH = (speedMps * 3.6).clamp(0.0, 160.0);
    });

    _latAnimation = Tween<double>(
      begin: startPos.latitude,
      end: newPos.latitude,
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.linear));

    _lngAnimation = Tween<double>(
      begin: startPos.longitude,
      end: newPos.longitude,
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.linear));

    double startHeading = _vehicleHeading;
    double endHeading = heading;
    if ((endHeading - startHeading).abs() > 180) {
      if (endHeading > startHeading) {
        startHeading += 360;
      } else {
        endHeading += 360;
      }
    }

    _headingAnimation = Tween<double>(
      begin: startHeading,
      end: endHeading,
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.easeOut));

    _animController.reset();
    _animController.forward();

    _previousPos = newPos;
    _targetPos = newPos;
    _vehicleHeading = heading % 360;

    _etaDebounceTimer?.cancel();
    _etaDebounceTimer = Timer(const Duration(seconds: 4), () {
      _recalculateLiveETA(newPos);
    });
  }

  Future<void> _recalculateLiveETA(LatLng driverPos) async {
    if (widget.mapboxAccessToken != null && widget.mapboxAccessToken!.isNotEmpty) {
      try {
        final url = Uri.parse(
          'https://api.mapbox.com/directions/v5/mapbox/driving/'
          '${driverPos.longitude},${driverPos.latitude};'
          '${widget.patientLocation.longitude},${widget.patientLocation.latitude}'
          '?geometries=geojson&overview=full&access_token=${widget.mapboxAccessToken}',
        );

        final res = await http.get(url);
        if (res.statusCode == 200) {
          final data = json.decode(res.body);
          final route = data['routes'][0];
          final durationSec = (route['duration'] as num).toDouble();
          final distanceM = (route['distance'] as num).toDouble();

          final geometry = route['geometry']['coordinates'] as List;
          final polyline = geometry
              .map((c) => LatLng(c[1] as double, c[0] as double))
              .toList();

          if (mounted) {
            setState(() {
              _etaMinutes = (durationSec / 60).ceil();
              _distanceKm = distanceM / 1000;
              _routePoints = polyline;
            });
          }
          return;
        }
      } catch (e) {
        debugPrint("Mapbox Directions API error: $e");
      }
    }

    // Fallback: Haversine distance with estimated 40 km/h city driving speed
    const Distance distance = Distance();
    final meters = distance.as(LengthUnit.Meter, driverPos, widget.patientLocation);
    final km = meters / 1000;
    final minutes = ((km / 40.0) * 60).ceil().clamp(1, 120);

    if (mounted) {
      setState(() {
        _distanceKm = km;
        _etaMinutes = minutes;
        _routePoints = [driverPos, widget.patientLocation];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _animController,
            builder: (context, child) {
              final currentLat = _targetPos != null && _animController.isAnimating
                  ? _latAnimation.value
                  : _targetPos?.latitude ?? widget.patientLocation.latitude;
              final currentLng = _targetPos != null && _animController.isAnimating
                  ? _lngAnimation.value
                  : _targetPos?.longitude ?? widget.patientLocation.longitude;
              final animatedHeading = _animController.isAnimating
                  ? _headingAnimation.value
                  : _vehicleHeading;

              final currentDriverPos = LatLng(currentLat, currentLng);

              return FlutterMap(
                mapController: _mapController,
                options: MapOptions(
                  initialCenter: widget.patientLocation,
                  initialZoom: 15.0,
                ),
                children: [
                  TileLayer(
                    urlTemplate: widget.mapboxAccessToken != null && widget.mapboxAccessToken!.isNotEmpty
                        ? 'https://api.mapbox.com/styles/v1/mapbox/streets-v12/tiles/{z}/{x}/{y}?access_token=${widget.mapboxAccessToken}'
                        : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.emergency.client_app',
                  ),

                  if (_routePoints.isNotEmpty)
                    PolylineLayer(
                      polylines: [
                        Polyline(
                          points: _routePoints,
                          color: const Color(0xFF2563EB),
                          strokeWidth: 5.0,
                        ),
                      ],
                    ),

                  MarkerLayer(
                    markers: [
                      // Patient Destination Pin
                      Marker(
                        point: widget.patientLocation,
                        width: 50,
                        height: 50,
                        child: const Icon(
                          Icons.location_on_rounded,
                          color: Colors.redAccent,
                          size: 44,
                        ),
                      ),

                      // Animated Ambulance Marker
                      if (_targetPos != null)
                        Marker(
                          point: currentDriverPos,
                          width: 56,
                          height: 56,
                          child: Transform.rotate(
                            angle: (animatedHeading * (math.pi / 180)),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.25),
                                    blurRadius: 8,
                                    offset: const Offset(0, 3),
                                  ),
                                ],
                              ),
                              padding: const EdgeInsets.all(8),
                              child: const Icon(
                                Icons.emergency_rounded,
                                color: Color(0xFFDC2626),
                                size: 30,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              );
            },
          ),

          // Floating Top Status Bar
          Positioned(
            top: MediaQuery.of(context).padding.top + 12,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.12),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  const SizedBox(
                    width: 12,
                    height: 12,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Color(0xFF16A34A),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _missionStatus.toUpperCase(),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        letterSpacing: 0.8,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                  ),
                  if (_currentSpeedKmH > 0)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF1F5F9),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        "${_currentSpeedKmH.toStringAsFixed(0)} km/h",
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF475569),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),

          // Floating Bottom HUD
          Positioned(
            bottom: 24,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 18,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "ESTIMATED ARRIVAL",
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.9,
                              color: Color(0xFF64748B),
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _etaMinutes != null ? "$_etaMinutes mins" : "Calculating…",
                            style: const TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF0F172A),
                            ),
                          ),
                        ],
                      ),
                      if (_distanceKm != null)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEFF6FF),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: const Color(0xFFBFDBFE)),
                          ),
                          child: Text(
                            "${_distanceKm!.toStringAsFixed(1)} km away",
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF1D4ED8),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const Divider(height: 24),
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 22,
                        backgroundColor: const Color(0xFF046A38).withOpacity(0.12),
                        child: const Icon(
                          Icons.local_shipping_rounded,
                          color: Color(0xFF046A38),
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _driverName ?? "Assigned Ambulance Unit",
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF0F172A),
                              ),
                            ),
                            Text(
                              _vehicleLabel ?? "Emergency Medical Responder",
                              style: const TextStyle(
                                fontSize: 12,
                                color: Color(0xFF64748B),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}